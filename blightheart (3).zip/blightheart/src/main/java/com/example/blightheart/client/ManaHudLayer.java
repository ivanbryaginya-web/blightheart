// Path: src/main/java/com/example/blightheart/client/ManaHudLayer.java
package com.example.blightheart.client;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.magic.ManaData;
import com.example.blightheart.registry.ModAttachments;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

/** Полоска маны в левом верхнем углу экрана. Загружается только на клиенте. */
@EventBusSubscriber(modid = BlightheartMod.MODID, value = Dist.CLIENT)
public final class ManaHudLayer {

    private static final int BAR_WIDTH = 81;
    private static final int BAR_HEIGHT = 5;

    /** Регистрируем слой интерфейса поверх всех остальных. */
    @SubscribeEvent
    public static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(BlightheartMod.id("mana_bar"), (graphics, deltaTracker) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui || mc.player == null || mc.player.isSpectator()) return;

            // Мана на клиенте приходит из ManaSyncPayload и лежит в том же Attachment
            ManaData mana = mc.player.getData(ModAttachments.MANA);
            int x = 6, y = 6;
            int filled = Math.round(BAR_WIDTH * (mana.getCurrentMana() / (float) mana.getMaxMana()));

            graphics.fill(x - 1, y - 1, x + BAR_WIDTH + 1, y + BAR_HEIGHT + 1, 0xAA000000); // фон
            graphics.fill(x, y, x + filled, y + BAR_HEIGHT, 0xFF6A4BFF);                    // мана
            graphics.drawString(mc.font, Component.translatable("hud.blightheart.mana",
                    mana.getCurrentMana(), mana.getMaxMana()), x, y + BAR_HEIGHT + 3, 0xFFFFFF, true);
        });
    }

    private ManaHudLayer() {}
}
