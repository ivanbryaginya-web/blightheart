// Path: src/main/java/com/example/blightheart/registry/ModCreativeTabs.java
package com.example.blightheart.registry;

import com.example.blightheart.BlightheartMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Вкладка творческого режима. */
public final class ModCreativeTabs {

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BlightheartMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = CREATIVE_TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.blightheart"))
                    .icon(() -> ModItems.INFECTION_HEART.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.INFECTION_HEART.get());
                        output.accept(ModItems.INFECTION_MASS.get());
                        output.accept(ModItems.DOME_MEMBRANE.get());
                        output.accept(ModItems.PETRIFIED_FLESH.get());
                        output.accept(ModItems.BLOODBLOOM.get());
                        output.accept(ModItems.EYESTALK.get());
                        output.accept(ModItems.PUSTULE.get());
                        output.accept(ModItems.INFECTED_GRASS_BLOCK.get());
                        output.accept(ModItems.BLIGHTED_GRASS.get());
                        output.accept(ModItems.ROTBLOOM.get());
                        output.accept(ModItems.PULSING_GROWTH.get());
                        output.accept(ModItems.ROTWOOD_LOG.get());
                        output.accept(ModItems.ROTWOOD_PLANKS.get());
                        output.accept(ModItems.HEART_SHARD.get());
                        output.accept(ModItems.BASE_WAND.get());
                        output.accept(ModItems.ARCHMAGE_WAND.get());
                        output.accept(ModItems.MATRIARCH_STAFF.get());
                        output.accept(ModItems.PURIFYING_BLADE.get());
                        output.accept(ModItems.HEALING_RESIN.get());
                        output.accept(ModItems.BLOOD_CALL.get());
                        output.accept(ModItems.MATRIARCH_CORE.get());
                        output.accept(ModItems.CHITIN_PLATE.get());
                        output.accept(ModItems.MATRIARCH_SCALE.get());
                        output.accept(ModItems.CHITIN_HELMET.get());
                        output.accept(ModItems.CHITIN_CHESTPLATE.get());
                        output.accept(ModItems.CHITIN_LEGGINGS.get());
                        output.accept(ModItems.CHITIN_BOOTS.get());
                        output.accept(ModItems.MATRIARCH_HELMET.get());
                        output.accept(ModItems.MATRIARCH_CHESTPLATE.get());
                        output.accept(ModItems.MATRIARCH_LEGGINGS.get());
                        output.accept(ModItems.MATRIARCH_BOOTS.get());
                        output.accept(ModItems.SPAWNLING_SPAWN_EGG.get());
                        output.accept(ModItems.HEART_GUARDIAN_SPAWN_EGG.get());
                        output.accept(ModItems.SPITTER_SPAWN_EGG.get());
                        output.accept(ModItems.BLOATER_SPAWN_EGG.get());
                        output.accept(ModItems.BLIGHT_MATRIARCH_SPAWN_EGG.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
