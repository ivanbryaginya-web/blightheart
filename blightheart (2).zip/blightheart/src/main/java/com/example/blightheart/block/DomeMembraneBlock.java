// Path: src/main/java/com/example/blightheart/block/DomeMembraneBlock.java
package com.example.blightheart.block;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Мембрана купола. Ведёт себя как заражённая масса (иссушает, гниёт волной после гибели Сердца),
 * но сама не растёт и полупрозрачна — сквозь неё видно, что творится внутри.
 */
public class DomeMembraneBlock extends InfectionMassBlock {

    public DomeMembraneBlock(Properties properties) {
        super(properties);
    }

    /** Купол строит только Сердце — мембрана сама не распространяется. */
    @Override
    protected boolean canSpread() {
        return false;
    }

    /** Как у стекла: не рисуем грани между двумя соседними блоками мембраны — купол выглядит цельным. */
    @Override
    public boolean skipRendering(BlockState state, BlockState adjacent, Direction direction) {
        return adjacent.is(this) || super.skipRendering(state, adjacent, direction);
    }
}
