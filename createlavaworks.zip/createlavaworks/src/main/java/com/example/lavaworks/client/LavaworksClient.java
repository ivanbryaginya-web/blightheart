// Path: src/main/java/com/example/lavaworks/client/LavaworksClient.java
package com.example.lavaworks.client;

import com.example.lavaworks.LavaworksMod;
import com.example.lavaworks.registry.ModBlockEntities;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Клиентская точка входа: загружается только на клиенте, на сервере не существует. */
@Mod(value = LavaworksMod.MODID, dist = Dist.CLIENT)
public class LavaworksClient {

    public LavaworksClient(IEventBus modEventBus) {
        modEventBus.addListener(LavaworksClient::registerRenderers);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.LAVA_ENGINE.get(), HalfShaftRenderer::new);
        event.registerBlockEntityRenderer(ModBlockEntities.KINETIC_LAMP.get(), HalfShaftRenderer::new);
    }
}
