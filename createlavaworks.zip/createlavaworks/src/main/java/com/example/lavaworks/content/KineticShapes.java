// Path: src/main/java/com/example/lavaworks/content/KineticShapes.java
package com.example.lavaworks.content;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.EnumMap;
import java.util.Map;

/**
 * Форма механизмов: корпус 16×16×12, а со стороны вала — вырез глубиной 4 пикселя,
 * в котором виден вращающийся вал. Формы посчитаны заранее для всех 6 направлений.
 */
public final class KineticShapes {

    private static final Map<Direction, VoxelShape> SHAPES = new EnumMap<>(Direction.class);

    static {
        SHAPES.put(Direction.NORTH, Block.box(0, 0, 4, 16, 16, 16));
        SHAPES.put(Direction.SOUTH, Block.box(0, 0, 0, 16, 16, 12));
        SHAPES.put(Direction.WEST, Block.box(4, 0, 0, 16, 16, 16));
        SHAPES.put(Direction.EAST, Block.box(0, 0, 0, 12, 16, 16));
        SHAPES.put(Direction.DOWN, Block.box(0, 4, 0, 16, 16, 16));
        SHAPES.put(Direction.UP, Block.box(0, 0, 0, 16, 12, 16));
    }

    /** Форма для блока, вал которого смотрит в сторону facing. */
    public static VoxelShape forFacing(Direction facing) {
        return SHAPES.get(facing);
    }

    private KineticShapes() {}
}
