// Path: src/main/java/com/example/lavaworks/registry/ModItems.java
package com.example.lavaworks.registry;

import com.example.lavaworks.LavaworksMod;
import net.minecraft.world.item.BlockItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Предметы-блоки, чтобы механизмы можно было держать в руке и ставить. */
public final class ModItems {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(LavaworksMod.MODID);

    public static final DeferredItem<BlockItem> LAVA_ENGINE = ITEMS.registerSimpleBlockItem(ModBlocks.LAVA_ENGINE);
    public static final DeferredItem<BlockItem> KINETIC_LAMP = ITEMS.registerSimpleBlockItem(ModBlocks.KINETIC_LAMP);

    private ModItems() {}
}
