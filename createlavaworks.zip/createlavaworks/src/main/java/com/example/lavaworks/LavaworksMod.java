// Path: src/main/java/com/example/lavaworks/LavaworksMod.java
package com.example.lavaworks;

import com.example.lavaworks.registry.ModBlockEntities;
import com.example.lavaworks.registry.ModBlocks;
import com.example.lavaworks.registry.ModCreativeTabs;
import com.example.lavaworks.registry.ModItems;
import com.example.lavaworks.registry.ModStress;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import org.slf4j.Logger;

/**
 * Главный класс аддона "Create: Lavaworks".
 * Добавляет в Create два механизма: Лавовый двигатель (источник вращения)
 * и Кинетическую лампу (потребитель вращения).
 */
@Mod(LavaworksMod.MODID)
public class LavaworksMod {

    public static final String MODID = "createlavaworks";
    public static final Logger LOGGER = LogUtils.getLogger();

    public LavaworksMod(IEventBus modEventBus, ModContainer modContainer) {
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITY_TYPES.register(modEventBus);
        ModCreativeTabs.CREATIVE_TABS.register(modEventBus);

        modEventBus.addListener(LavaworksMod::commonSetup);
    }

    /** Блоки к этому моменту уже зарегистрированы — можно сообщить Create их нагрузку и мощность. */
    private static void commonSetup(FMLCommonSetupEvent event) {
        ModStress.register();
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
