// Path: src/main/java/com/example/lavaworks/content/KineticLampBlock.java
package com.example.lavaworks.content;

import com.example.lavaworks.registry.ModBlockEntities;
import com.simibubi.create.content.kinetics.base.DirectionalKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Кинетическая лампа: подключается валом к сети Create и светится, пока вращается.
 * Если сеть перегружена (красные частицы), лампа гаснет.
 */
public class KineticLampBlock extends DirectionalKineticBlock implements IBE<KineticLampBlockEntity> {

    /** Горит ли лампа. От него зависит яркость (см. ModBlocks) и модель. */
    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    public KineticLampBlock(Properties properties) {
        super(properties);
        registerDefaultState(defaultBlockState().setValue(LIT, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LIT);
        super.createBlockStateDefinition(builder); // добавит FACING
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return KineticShapes.forFacing(state.getValue(FACING));
    }

    /** Ставится валом к соседнему кинетическому блоку, как и двигатель. */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Direction preferred = getPreferredFacing(context);
        if ((context.getPlayer() != null && context.getPlayer().isShiftKeyDown()) || preferred == null)
            return super.getStateForPlacement(context);
        return defaultBlockState().setValue(FACING, preferred);
    }

    @Override
    public boolean hasShaftTowards(LevelReader level, BlockPos pos, BlockState state, Direction face) {
        return face == state.getValue(FACING);
    }

    @Override
    public Direction.Axis getRotationAxis(BlockState state) {
        return state.getValue(FACING).getAxis();
    }

    @Override
    public Class<KineticLampBlockEntity> getBlockEntityClass() {
        return KineticLampBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends KineticLampBlockEntity> getBlockEntityType() {
        return ModBlockEntities.KINETIC_LAMP.get();
    }
}
