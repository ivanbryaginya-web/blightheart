// Path: src/main/java/com/example/lavaworks/registry/ModStress.java
package com.example.lavaworks.registry;

import com.example.lavaworks.content.LavaEngineBlockEntity;
import com.simibubi.create.api.stress.BlockStressValues;

/**
 * Значения нагрузки (stress) для системы Create.
 * Все значения указываются "на 1 об/мин": Create сам умножает их на текущую скорость.
 */
public final class ModStress {

    /** Мощность двигателя: 32 SU на 1 об/мин. На максимуме (64 об/мин) это 2048 SU. */
    public static final double LAVA_ENGINE_CAPACITY = 32.0;
    /** Нагрузка лампы: 2 SU на 1 об/мин (как у лёгких механизмов Create). */
    public static final double KINETIC_LAMP_IMPACT = 2.0;

    public static void register() {
        BlockStressValues.CAPACITIES.register(ModBlocks.LAVA_ENGINE.get(), () -> LAVA_ENGINE_CAPACITY);
        // Только для подсказки "Генерирует скорость" — реальная скорость зависит от количества лавы
        BlockStressValues.RPM.register(ModBlocks.LAVA_ENGINE.get(),
                new BlockStressValues.GeneratedRpm(LavaEngineBlockEntity.MAX_RPM, true));

        BlockStressValues.IMPACTS.register(ModBlocks.KINETIC_LAMP.get(), () -> KINETIC_LAMP_IMPACT);
    }

    private ModStress() {}
}
