// Path: src/main/java/com/example/lavaworks/content/LavaEngineBlock.java
package com.example.lavaworks.content;

import com.example.lavaworks.registry.ModBlockEntities;
import com.simibubi.create.content.kinetics.base.DirectionalKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Лавовый двигатель — источник вращения для Create.
 * Вал выходит с одной стороны (FACING), остальные 5 сторон проверяются на источники лавы.
 * Устроен так же, как Творческий мотор Create, но скорость зависит от лавы вокруг.
 */
public class LavaEngineBlock extends DirectionalKineticBlock implements IBE<LavaEngineBlockEntity> {

    public LavaEngineBlock(Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return KineticShapes.forFacing(state.getValue(FACING));
    }

    /**
     * При установке вал автоматически поворачивается к соседнему валу/шестерне.
     * С зажатым Shift — ставится "от себя", как обычные блоки Create.
     */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Direction preferred = getPreferredFacing(context);
        if ((context.getPlayer() != null && context.getPlayer().isShiftKeyDown()) || preferred == null)
            return super.getStateForPlacement(context);
        return defaultBlockState().setValue(FACING, preferred);
    }

    // ---- IRotate: как блок соединяется с кинетической сетью ----

    /** Вал есть только с передней стороны. */
    @Override
    public boolean hasShaftTowards(LevelReader level, BlockPos pos, BlockState state, Direction face) {
        return face == state.getValue(FACING);
    }

    /** Ось вращения совпадает с направлением вала. */
    @Override
    public Direction.Axis getRotationAxis(BlockState state) {
        return state.getValue(FACING).getAxis();
    }

    /** Генератор ничего не потребляет — скрываем строку "нагрузка" в подсказке. */
    @Override
    public boolean hideStressImpact() {
        return true;
    }

    @Override
    protected boolean isPathfindable(BlockState state, PathComputationType type) {
        return false;
    }

    /** Клиентские частицы: дымок и искры, пока двигатель работает. */
    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        LavaEngineBlockEntity be = getBlockEntity(level, pos);
        if (be == null || be.getSpeed() == 0 || random.nextInt(3) != 0) return;
        double x = pos.getX() + 0.5D + (random.nextDouble() - 0.5D) * 0.6D;
        double z = pos.getZ() + 0.5D + (random.nextDouble() - 0.5D) * 0.6D;
        level.addParticle(ParticleTypes.SMOKE, x, pos.getY() + 1.0D, z, 0.0D, 0.03D, 0.0D);
        if (random.nextInt(4) == 0)
            level.addParticle(ParticleTypes.LAVA, x, pos.getY() + 1.0D, z, 0.0D, 0.0D, 0.0D);
    }

    // ---- IBE: связь блока с его BlockEntity ----

    @Override
    public Class<LavaEngineBlockEntity> getBlockEntityClass() {
        return LavaEngineBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends LavaEngineBlockEntity> getBlockEntityType() {
        return ModBlockEntities.LAVA_ENGINE.get();
    }
}
