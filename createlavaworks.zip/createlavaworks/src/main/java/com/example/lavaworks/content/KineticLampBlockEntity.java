// Path: src/main/java/com/example/lavaworks/content/KineticLampBlockEntity.java
package com.example.lavaworks.content;

import com.example.lavaworks.registry.ModBlockEntities;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Логика лампы: каждый тик сверяет "должна ли гореть" с текущим состоянием блока.
 * getSpeed() у Create возвращает 0 и при остановке, и при перегрузке сети —
 * поэтому одной проверки хватает на оба случая.
 */
public class KineticLampBlockEntity extends KineticBlockEntity {

    public KineticLampBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.KINETIC_LAMP.get(), pos, state);
    }

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide) return;

        boolean shouldBeLit = getSpeed() != 0;
        BlockState state = getBlockState();
        if (state.getValue(KineticLampBlock.LIT) != shouldBeLit) {
            // Меняем только LIT: ось вращения та же, поэтому Create не разрывает сеть
            level.setBlock(worldPosition, state.setValue(KineticLampBlock.LIT, shouldBeLit), Block.UPDATE_ALL);
        }
    }
}
