// Path: src/main/java/com/example/lavaworks/registry/ModCreativeTabs.java
package com.example.lavaworks.registry;

import com.example.lavaworks.LavaworksMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Вкладка творческого режима аддона. */
public final class ModCreativeTabs {

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LavaworksMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = CREATIVE_TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.createlavaworks"))
                    .icon(() -> ModItems.LAVA_ENGINE.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.LAVA_ENGINE.get());
                        output.accept(ModItems.KINETIC_LAMP.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
