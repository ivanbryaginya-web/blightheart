// Path: src/main/java/com/example/lavaworks/registry/ModBlockEntities.java
package com.example.lavaworks.registry;

import com.example.lavaworks.LavaworksMod;
import com.example.lavaworks.content.KineticLampBlockEntity;
import com.example.lavaworks.content.LavaEngineBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Типы BlockEntity. У каждого кинетического блока Create есть BlockEntity — он хранит скорость и сеть. */
public final class ModBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, LavaworksMod.MODID);

    @SuppressWarnings("DataFlowIssue") // build(null): DataFixer модам не нужен
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<LavaEngineBlockEntity>> LAVA_ENGINE =
            BLOCK_ENTITY_TYPES.register("lava_engine", () -> BlockEntityType.Builder
                    .of(LavaEngineBlockEntity::new, ModBlocks.LAVA_ENGINE.get())
                    .build(null));

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KineticLampBlockEntity>> KINETIC_LAMP =
            BLOCK_ENTITY_TYPES.register("kinetic_lamp", () -> BlockEntityType.Builder
                    .of(KineticLampBlockEntity::new, ModBlocks.KINETIC_LAMP.get())
                    .build(null));

    private ModBlockEntities() {}
}
