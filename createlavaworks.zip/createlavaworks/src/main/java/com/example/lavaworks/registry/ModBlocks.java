// Path: src/main/java/com/example/lavaworks/registry/ModBlocks.java
package com.example.lavaworks.registry;

import com.example.lavaworks.LavaworksMod;
import com.example.lavaworks.content.KineticLampBlock;
import com.example.lavaworks.content.LavaEngineBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Регистрация блоков аддона. */
public final class ModBlocks {

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(LavaworksMod.MODID);

    /** Лавовый двигатель: крутит вал, если рядом есть источники лавы. */
    public static final DeferredBlock<LavaEngineBlock> LAVA_ENGINE = BLOCKS.register("lava_engine",
            () -> new LavaEngineBlock(machine()
                    .mapColor(MapColor.COLOR_ORANGE)
                    .lightLevel(state -> 6)));

    /** Кинетическая лампа: светится, пока её вращают, и потребляет немного нагрузки. */
    public static final DeferredBlock<KineticLampBlock> KINETIC_LAMP = BLOCKS.register("kinetic_lamp",
            () -> new KineticLampBlock(machine()
                    .mapColor(MapColor.COLOR_YELLOW)
                    .lightLevel(state -> state.getValue(KineticLampBlock.LIT) ? 15 : 0)));

    /**
     * Общие свойства механизмов. noOcclusion() обязателен: модель не на весь блок,
     * и через вырез должен быть виден вращающийся вал.
     */
    private static BlockBehaviour.Properties machine() {
        return BlockBehaviour.Properties.of()
                .strength(2.5F, 6.0F)
                .requiresCorrectToolForDrops()
                .sound(SoundType.WOOD)
                .noOcclusion();
    }

    private ModBlocks() {}
}
