// Path: src/main/java/com/example/lavaworks/content/LavaEngineBlockEntity.java
package com.example.lavaworks.content;

import com.example.lavaworks.registry.ModBlockEntities;
import com.simibubi.create.content.kinetics.base.GeneratingKineticBlockEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import java.util.List;

/**
 * Логика Лавового двигателя.
 * Каждый источник лавы рядом даёт +16 об/мин (максимум 4 источника = 64 об/мин).
 * Мощность (SU) Create считает сам: 32 SU × текущая скорость.
 */
public class LavaEngineBlockEntity extends GeneratingKineticBlockEntity {

    public static final int RPM_PER_LAVA = 16;
    public static final int MAX_LAVA_SOURCES = 4;
    public static final int MAX_RPM = RPM_PER_LAVA * MAX_LAVA_SOURCES;
    /** Проверяем лаву раз в секунду, а не каждый тик, — это экономит производительность. */
    private static final int CHECK_INTERVAL_TICKS = 20;

    private int lavaSources = 0;

    public LavaEngineBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.LAVA_ENGINE.get(), pos, state);
    }

    /** Вызывается, когда блок загрузился в мир: сразу считаем лаву и запускаем вращение. */
    @Override
    public void initialize() {
        super.initialize();
        if (level != null && !level.isClientSide)
            lavaSources = countLavaSources();
        if (!hasSource() || getGeneratedSpeed() > getTheoreticalSpeed())
            updateGeneratedRotation();
    }

    /** Раз в секунду пересчитываем лаву; если количество изменилось — меняем скорость сети. */
    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide || level.getGameTime() % CHECK_INTERVAL_TICKS != 0)
            return;

        int found = countLavaSources();
        if (found != lavaSources) {
            lavaSources = found;
            updateGeneratedRotation(); // Create пересчитает скорость и нагрузку всей сети
        }
    }

    /** Считает источники лавы со всех сторон, кроме стороны вала. */
    private int countLavaSources() {
        Direction shaftSide = getBlockState().getValue(LavaEngineBlock.FACING);
        int count = 0;
        for (Direction side : Direction.values()) {
            if (side == shaftSide) continue;
            FluidState fluid = level.getFluidState(worldPosition.relative(side));
            if (fluid.is(FluidTags.LAVA) && fluid.isSource())
                count++;
        }
        return Math.min(count, MAX_LAVA_SOURCES);
    }

    /** Скорость, которую двигатель отдаёт в сеть (со знаком — направление вращения). */
    @Override
    public float getGeneratedSpeed() {
        if (!(getBlockState().getBlock() instanceof LavaEngineBlock))
            return 0;
        return convertToDirection(lavaSources * RPM_PER_LAVA, getBlockState().getValue(LavaEngineBlock.FACING));
    }

    /** Дополнительная строка в подсказке Инженерных очков: сколько лавы видит двигатель. */
    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        super.addToGoggleTooltip(tooltip, isPlayerSneaking);
        tooltip.add(Component.literal("    ").append(
                Component.translatable("goggles.createlavaworks.lava_sources", lavaSources, MAX_LAVA_SOURCES)
                        .withStyle(lavaSources > 0 ? ChatFormatting.GOLD : ChatFormatting.RED)));
        return true;
    }

    // ---- Сохранение и синхронизация с клиентом (для очков) ----

    @Override
    protected void write(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(compound, registries, clientPacket);
        compound.putInt("LavaSources", lavaSources);
    }

    @Override
    protected void read(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(compound, registries, clientPacket);
        lavaSources = compound.getInt("LavaSources");
    }
}
