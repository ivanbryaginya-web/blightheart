# Create: Lavaworks — аддон к Create 6 (NeoForge 1.21.1)

Нужно в игре: NeoForge 21.1.219+ и Create 6.0.10+ для 1.21.1.

Сборка: gradlew build (нужна JDK 21) или через GitHub Actions (вкладка Actions → Artifacts).
Готовый мод: build/libs/createlavaworks-1.0.0.jar → папка mods (рядом с Create).
