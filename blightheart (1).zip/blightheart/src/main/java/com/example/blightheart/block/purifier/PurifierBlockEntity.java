// Path: src/main/java/com/example/blightheart/block/purifier/PurifierBlockEntity.java
package com.example.blightheart.block.purifier;

import com.example.blightheart.block.InfectionMassBlock;
import com.example.blightheart.entity.BlightMonster;
import com.example.blightheart.registry.ModBlockEntities;
import com.example.blightheart.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * "Мозг" Очистителя. Каждый тик проверяет часть шара радиусом 16 (весь шар — примерно за 4 секунды)
 * и очищает найденное заражение. Очищает только то, что в радиусе: дальнюю массу не трогает.
 */
public class PurifierBlockEntity extends BlockEntity {

    public static final int RADIUS = 16;
    private static final int SIDE = RADIUS * 2 + 1;
    private static final int TOTAL = SIDE * SIDE * SIDE;
    /** Сколько клеток проверяется за тик — нагрузка постоянная и небольшая. */
    private static final int CHECKS_PER_TICK = 600;

    private int cursor = 0;
    private int age = 0;

    public PurifierBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PURIFIER.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, PurifierBlockEntity purifier) {
        purifier.tick((ServerLevel) level);
    }

    private void tick(ServerLevel level) {
        age++;
        for (int i = 0; i < CHECKS_PER_TICK; i++) {
            int idx = cursor;
            cursor = (cursor + 1) % TOTAL;
            int dx = idx % SIDE - RADIUS;
            int dy = (idx / SIDE) % SIDE - RADIUS;
            int dz = idx / (SIDE * SIDE) - RADIUS;
            if (dx * dx + dy * dy + dz * dz > RADIUS * RADIUS) continue;

            BlockPos target = worldPosition.offset(dx, dy, dz);
            if (!level.isLoaded(target)) continue;
            BlockState state = level.getBlockState(target);

            if (state.getBlock() instanceof InfectionMassBlock mass) {
                // Очищаем только этот блок (без цепной волны) — массу за пределами радиуса не трогаем
                level.levelEvent(2001, target, Block.getId(state));
                level.setBlockAndUpdate(target, mass.restoredState(level, target));
                if (level.getRandom().nextInt(4) == 0) {
                    level.sendParticles(ParticleTypes.END_ROD, target.getX() + 0.5D, target.getY() + 1.0D,
                            target.getZ() + 0.5D, 2, 0.2D, 0.2D, 0.2D, 0.02D);
                }
            } else if (state.is(ModBlocks.INFECTED_GRASS_BLOCK.get())) {
                level.setBlockAndUpdate(target, Blocks.GRASS_BLOCK.defaultBlockState());
            }
        }

        // Раз в секунду — святой огонь по существам Заражения в радиусе
        if (age % 20 == 0) {
            AABB area = new AABB(worldPosition).inflate(RADIUS);
            for (BlightMonster monster : level.getEntitiesOfClass(BlightMonster.class, area)) {
                monster.hurt(level.damageSources().magic(), 3.0F);
                monster.igniteForSeconds(2.0F);
            }
        }
        // Луч света вверх и тихий гул
        if (age % 10 == 0) {
            level.sendParticles(ParticleTypes.END_ROD, worldPosition.getX() + 0.5D, worldPosition.getY() + 1.6D,
                    worldPosition.getZ() + 0.5D, 3, 0.05D, 0.8D, 0.05D, 0.0D);
        }
        if (age % 80 == 0) {
            level.playSound(null, worldPosition, SoundEvents.BEACON_AMBIENT, SoundSource.BLOCKS, 0.6F, 1.4F);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Cursor", cursor);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        cursor = Math.floorMod(tag.getInt("Cursor"), TOTAL);
    }
}
