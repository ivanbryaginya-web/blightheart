// Path: src/main/java/com/example/blightheart/registry/ModBlocks.java
package com.example.blightheart.registry;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.block.DomeMembraneBlock;
import com.example.blightheart.block.InfectionHeartBlock;
import com.example.blightheart.block.InfectionMassBlock;
import com.example.blightheart.dimension.InfectionPortalBlock;
import com.example.blightheart.block.nature.InfectedGrassBlock;
import com.example.blightheart.block.nature.PustuleBlock;
import com.example.blightheart.block.nature.BlightPlantBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Регистрация блоков. */
public final class ModBlocks {

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(BlightheartMod.MODID);

    /**
     * Сердце Заражения. Очень прочное (ломается дольше обсидиана), не боится взрывов
     * и не двигается поршнями — уничтожить его можно только упорной работой киркой.
     */
    public static final DeferredBlock<InfectionHeartBlock> INFECTION_HEART = BLOCKS.register("infection_heart",
            () -> new InfectionHeartBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.CRIMSON_HYPHAE)
                    .strength(60.0F, 3600000.0F)
                    .lightLevel(state -> 10)
                    .sound(SoundType.SCULK_CATALYST)
                    .pushReaction(PushReaction.BLOCK)));

    /** Заражённая масса — то, во что превращаются блоки вокруг Сердца. */
    public static final DeferredBlock<InfectionMassBlock> INFECTION_MASS = BLOCKS.register("infection_mass",
            () -> new InfectionMassBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.CRIMSON_NYLIUM)
                    .strength(1.5F, 3.0F)
                    .lightLevel(state -> 3)
                    .sound(SoundType.SCULK)));

    /**
     * Мембрана купола — полупрозрачная плоть, которой Сердце закрывает себя.
     * Прочнее массы; не распространяется сама, но Сердце заращивает в ней дыры.
     */
    public static final DeferredBlock<DomeMembraneBlock> DOME_MEMBRANE = BLOCKS.register("dome_membrane",
            () -> new DomeMembraneBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_RED)
                    .strength(4.0F, 9.0F)
                    .lightLevel(state -> 4)
                    .sound(SoundType.HONEY_BLOCK)
                    .noOcclusion()
                    .isViewBlocking((state, level, pos) -> false)
                    .isSuffocating((state, level, pos) -> false)
                    .isRedstoneConductor((state, level, pos) -> false)));

    /** Окаменевшая плоть — прочный блок для рамки портала (заражение на неё не действует). */
    public static final DeferredBlock<Block> PETRIFIED_FLESH = BLOCKS.register("petrified_flesh",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.TERRACOTTA_RED)
                    .strength(3.0F, 9.0F)
                    .requiresCorrectToolForDrops()
                    .sound(SoundType.BONE_BLOCK)));

    /** Портал в Заражённый мир: не ломается руками, пропадает, если сломать рамку. */
    public static final DeferredBlock<InfectionPortalBlock> INFECTION_PORTAL = BLOCKS.register("infection_portal",
            () -> new InfectionPortalBlock(BlockBehaviour.Properties.of()
                    .noCollission()
                    .strength(-1.0F, 3600000.0F)
                    .lightLevel(state -> 11)
                    .sound(SoundType.GLASS)
                    .noLootTable()
                    .pushReaction(PushReaction.BLOCK)));

    // ======================= ПРИРОДА ЗАРАЖЕНИЯ =======================

    /** Заражённый дёрн — багровая трава поверх земли. Так выглядит поверхность Заражённого мира. */
    public static final DeferredBlock<InfectedGrassBlock> INFECTED_GRASS_BLOCK = BLOCKS.register("infected_grass_block",
            () -> new InfectedGrassBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.CRIMSON_NYLIUM).strength(0.6F).randomTicks().sound(SoundType.GRASS)));

    /** Испорченная трава — низкие бурые стебли. */
    public static final DeferredBlock<BlightPlantBlock> BLIGHTED_GRASS = BLOCKS.register("blighted_grass",
            () -> new BlightPlantBlock(plant(MapColor.CRIMSON_NYLIUM).replaceable(),
                    Block.box(2, 0, 2, 14, 13, 14), false, false, null));

    /** Гнилоцвет — ядовитый цветок: иссушает, как роза иссушения. Сыплет спорами. */
    public static final DeferredBlock<BlightPlantBlock> ROTBLOOM = BLOCKS.register("rotbloom",
            () -> new BlightPlantBlock(plant(MapColor.COLOR_PURPLE),
                    Block.box(5, 0, 5, 11, 10, 11), true, false, ParticleTypes.CRIMSON_SPORE));

    /** Пульсирующий нарост — светящийся мясистый гриб. Освещает Заражённый мир и пещеры. */
    public static final DeferredBlock<BlightPlantBlock> PULSING_GROWTH = BLOCKS.register("pulsing_growth",
            () -> new BlightPlantBlock(plant(MapColor.COLOR_PINK).lightLevel(state -> 11),
                    Block.box(4, 0, 4, 12, 9, 12), false, true, ParticleTypes.SCULK_SOUL));

    /** Гнилое бревно — во что превращаются деревья в зоне заражения. */
    public static final DeferredBlock<RotatedPillarBlock> ROTWOOD_LOG = BLOCKS.register("rotwood_log",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.TERRACOTTA_GRAY).instrument(NoteBlockInstrument.BASS)
                    .strength(2.0F).sound(SoundType.WOOD)));

    /** Гнилые доски — строительный материал; годятся вместо обычных досок (верстак, палки и т.д.). */
    public static final DeferredBlock<Block> ROTWOOD_PLANKS = BLOCKS.register("rotwood_planks",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.TERRACOTTA_GRAY).instrument(NoteBlockInstrument.BASS)
                    .strength(2.0F, 3.0F).sound(SoundType.WOOD)));

    /** Общие свойства растений: без столкновений, ломаются мгновенно, случайный сдвиг как у травы. */
    private static BlockBehaviour.Properties plant(MapColor color) {
        return BlockBehaviour.Properties.of()
                .mapColor(color).noCollission().instabreak().sound(SoundType.GRASS)
                .offsetType(BlockBehaviour.OffsetType.XZ).pushReaction(PushReaction.DESTROY);
    }

    // ---- Новое разнообразие ----

    /** Кровоцвет — алый светящийся цветок; освещает Заражённый мир мягким красным светом. */
    public static final DeferredBlock<BlightPlantBlock> BLOODBLOOM = BLOCKS.register("bloodbloom",
            () -> new BlightPlantBlock(plant(MapColor.COLOR_RED).lightLevel(state -> 7),
                    Block.box(4, 0, 4, 12, 12, 12), false, false, ParticleTypes.CRIMSON_SPORE));

    /** Глазостебель — стебель с живым глазом на конце. Растёт и в пещерах. */
    public static final DeferredBlock<BlightPlantBlock> EYESTALK = BLOCKS.register("eyestalk",
            () -> new BlightPlantBlock(plant(MapColor.COLOR_PINK).lightLevel(state -> 4),
                    Block.box(5, 0, 5, 11, 13, 11), false, true, null));

    /** Гнойный нарост — пузырь на земле: лопается облаком яда, если на него наступить. */
    public static final DeferredBlock<PustuleBlock> PUSTULE = BLOCKS.register("pustule",
            () -> new PustuleBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_YELLOW).strength(0.3F).sound(SoundType.SLIME_BLOCK)
                    .noOcclusion().lightLevel(state -> 3).pushReaction(PushReaction.DESTROY)));

    // ---- Руды ----

    /** Сангвинитовая руда: красные кристаллы в камне Заражённого мира. Нужна железная кирка. */
    public static final DeferredBlock<DropExperienceBlock> SANGUINITE_ORE = BLOCKS.register("sanguinite_ore",
            () -> new DropExperienceBlock(UniformInt.of(3, 7), BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE).strength(3.0F, 3.0F).requiresCorrectToolForDrops()
                    .lightLevel(state -> 3).sound(SoundType.STONE)));

    /** Руда маны: голубые прожилки в обычном мире. Из неё — Эссенция маны. */
    public static final DeferredBlock<DropExperienceBlock> MANA_ORE = BLOCKS.register("mana_ore",
            () -> new DropExperienceBlock(UniformInt.of(2, 5), BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE).strength(3.0F, 3.0F).requiresCorrectToolForDrops()
                    .lightLevel(state -> 4).sound(SoundType.STONE)));

    public static final DeferredBlock<DropExperienceBlock> DEEPSLATE_MANA_ORE = BLOCKS.register("deepslate_mana_ore",
            () -> new DropExperienceBlock(UniformInt.of(2, 5), BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DEEPSLATE).strength(4.5F, 3.0F).requiresCorrectToolForDrops()
                    .lightLevel(state -> 4).sound(SoundType.DEEPSLATE)));

    /** Блок сангвинита — хранение и украшение; мягко светится. */
    public static final DeferredBlock<Block> SANGUINITE_BLOCK = BLOCKS.register("sanguinite_block",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_RED).strength(5.0F, 6.0F).requiresCorrectToolForDrops()
                    .lightLevel(state -> 7).sound(SoundType.AMETHYST)));

    /** Гнилая листва — на мёртвых деревьях Заражённого мира. Опадает, если срубить ствол. */
    public static final DeferredBlock<LeavesBlock> ROT_LEAVES = BLOCKS.register("rot_leaves",
            () -> new LeavesBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE).strength(0.2F).randomTicks().sound(SoundType.GRASS)
                    .noOcclusion().ignitedByLava().pushReaction(PushReaction.DESTROY)
                    .isValidSpawn((state, level, pos, type) -> false)
                    .isSuffocating((state, level, pos) -> false)
                    .isViewBlocking((state, level, pos) -> false)
                    .isRedstoneConductor((state, level, pos) -> false)));

    private ModBlocks() {}
}
