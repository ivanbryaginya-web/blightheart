// Path: src/main/java/com/example/blightheart/item/AmuletItem.java
package com.example.blightheart.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * Амулет: пока лежит в инвентаре (где угодно), даёт постоянный эффект.
 * Эффекты применяет ArmorSetEvents раз в полсекунды.
 */
public class AmuletItem extends Item {

    private final Holder<MobEffect> effect;
    private final int amplifier;

    public AmuletItem(Holder<MobEffect> effect, int amplifier, Properties properties) {
        super(properties);
        this.effect = effect;
        this.amplifier = amplifier;
    }

    /** Наложить эффект. 260 тиков — чтобы ночное зрение не мигало. */
    public void apply(Player player) {
        player.addEffect(new MobEffectInstance(effect, 260, amplifier, true, false, true));
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.blightheart.amulet",
                Component.translatable(effect.value().getDescriptionId())).withStyle(ChatFormatting.GOLD));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
