// Path: src/main/java/com/example/blightheart/block/InfectionManager.java
package com.example.blightheart.block;

import com.example.blightheart.entity.BlightMonster;
import com.example.blightheart.registry.ModBlocks;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;


/** Общие правила заражения и то, что происходит при гибели Сердца. */
public final class InfectionManager {

    /** Блоки прочнее этого (обсидиан = 50) заразить нельзя. Бедрок (-1) — тоже. */
    private static final float MAX_INFECTABLE_HARDNESS = 49.0F;
    /** Радиус, в котором гибнут Порождения при уничтожении Сердца. */
    private static final double KILL_RADIUS = 96.0D;

    /** Можно ли заразить блок. Не трогаем воздух, жидкости, неразрушимые блоки и сундуки/печки. */
    public static boolean canInfect(Level level, BlockPos pos, BlockState state) {
        if (state.isAir() || !state.getFluidState().isEmpty()) return false;
        if (state.hasBlockEntity()) return false; // защищаем сундуки, печи и т.п.
        float hardness = state.getDestroySpeed(level, pos);
        return hardness >= 0 && hardness <= MAX_INFECTABLE_HARDNESS;
    }

    /** Должно ли существо получать урон от заражения. */
    public static boolean isVictim(LivingEntity entity) {
        return entity.isAlive() && !InfectionHeartBlockEntity.isIgnored(entity);
    }

    /**
     * Заразить один блок: растения увядают, твёрдые блоки превращаются в массу.
     * Используется и Сердцем, и самой массой.
     */
    public static void infect(ServerLevel level, BlockPos pos, BlockState state) {
        if (!canInfect(level, pos, state)) return;

        // 1. Обычная трава на земле → заражённый дёрн (позже он станет массой)
        if (state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.PODZOL) || state.is(Blocks.MYCELIUM)) {
            level.setBlockAndUpdate(pos, ModBlocks.INFECTED_GRASS_BLOCK.get().defaultBlockState());
            return;
        }
        // 2. Обычные брёвна → гнилые (с тем же направлением)
        if (state.is(BlockTags.LOGS) && !state.is(ModBlocks.ROTWOOD_LOG.get()) && state.hasProperty(RotatedPillarBlock.AXIS)) {
            level.setBlockAndUpdate(pos, ModBlocks.ROTWOOD_LOG.get().defaultBlockState()
                    .setValue(RotatedPillarBlock.AXIS, state.getValue(RotatedPillarBlock.AXIS)));
            return;
        }
        // 3. Листва увядает
        if (state.is(BlockTags.LEAVES)) {
            level.destroyBlock(pos, false);
            return;
        }
        if (state.canBeReplaced()) {
            // Трава и цветы: иногда превращаются в испорченную траву или гнилоцвет, иначе увядают
            BlockState blighted = level.getRandom().nextInt(5) == 0
                    ? ModBlocks.ROTBLOOM.get().defaultBlockState()
                    : ModBlocks.BLIGHTED_GRASS.get().defaultBlockState();
            if (state.is(BlockTags.REPLACEABLE_BY_TREES) && level.getRandom().nextBoolean()
                    && blighted.canSurvive(level, pos)) {
                level.setBlockAndUpdate(pos, blighted);
            } else if (!state.is(ModBlocks.BLIGHTED_GRASS.get()) && !state.is(ModBlocks.ROTBLOOM.get())
                    && !state.is(ModBlocks.PULSING_GROWTH.get())) {
                level.destroyBlock(pos, false);
            }
        } else {
            level.setBlockAndUpdate(pos, ModBlocks.INFECTION_MASS.get().defaultBlockState());
            if (level.getRandom().nextInt(4) == 0) {
                level.sendParticles(ParticleTypes.SCULK_CHARGE_POP,
                        pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, 3, 0.3D, 0.1D, 0.3D, 0.0D);
            }
        }
    }

    /**
     * МОЩЬ РАЗБИТОГО СЕРДЦА.
     * 1) Все существа этого Сердца (Порождения и Стражи) мгновенно погибают.
     * 2) Соседняя с Сердцем масса начинает гнить — и гниение цепочкой проходит
     *    по ВСЕЙ связанной массе, даже если она разрослась на тысячи блоков.
     */
    public static void onHeartDestroyed(ServerLevel level, BlockPos heartPos) {
        HeartTracker.get(level).remove(heartPos);

        // 1. Смерть существ
        AABB area = new AABB(heartPos).inflate(KILL_RADIUS);
        for (BlightMonster monster : level.getEntitiesOfClass(BlightMonster.class, area,
                m -> heartPos.equals(m.getHeartPos()))) {
            monster.kill();
        }

        // 2. Запускаем волну гниения от Сердца
        for (Direction dir : Direction.values()) {
            BlockPos next = heartPos.relative(dir);
            BlockState state = level.getBlockState(next);
            if (state.is(ModBlocks.INFECTION_MASS.get()) && !state.getValue(InfectionMassBlock.DECAYING))
                InfectionMassBlock.startDecay(level, next, state, level.getRandom());
        }

        // 2б. Купол гниёт целиком, даже если он не касается массы (например, Сердце висит в воздухе)
        for (BlockPos offset : InfectionHeartBlockEntity.DOME_OFFSETS) {
            BlockPos domePos = heartPos.offset(offset);
            if (!level.isLoaded(domePos)) continue;
            BlockState state = level.getBlockState(domePos);
            if (state.is(ModBlocks.DOME_MEMBRANE.get()) && !state.getValue(InfectionMassBlock.DECAYING))
                InfectionMassBlock.startDecay(level, domePos, state, level.getRandom());
        }

        // 3. Эффекты гибели
        double x = heartPos.getX() + 0.5D, y = heartPos.getY() + 0.5D, z = heartPos.getZ() + 0.5D;
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y, z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.SCULK_SOUL, x, y, z, 60, 1.5D, 1.0D, 1.5D, 0.1D);
        level.playSound(null, heartPos, SoundEvents.WITHER_DEATH, SoundSource.BLOCKS, 1.5F, 1.2F);

        Component message = Component.translatable("message.blightheart.heart_destroyed").withStyle(ChatFormatting.GOLD);
        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class, area)) {
            player.displayClientMessage(message, true);
        }
    }

    private InfectionManager() {}
}
