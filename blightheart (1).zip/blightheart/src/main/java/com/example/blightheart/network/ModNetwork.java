// Path: src/main/java/com/example/blightheart/network/ModNetwork.java
package com.example.blightheart.network;

import com.example.blightheart.magic.ManaData;
import com.example.blightheart.registry.ModAttachments;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Регистрация пакетов и вспомогательные методы отправки. */
public final class ModNetwork {

    /** Версия сетевого протокола мода. Меняй при изменении формата пакетов. */
    private static final String PROTOCOL_VERSION = "1";

    /** Вызывается на шине мода (подписка в BlightheartMod). */
    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL_VERSION);
        registrar.playToClient(ManaSyncPayload.TYPE, ManaSyncPayload.STREAM_CODEC, ManaSyncPayload::handleOnClient);
    }

    /** Отправить игроку его актуальную ману. */
    public static void syncMana(ServerPlayer player) {
        ManaData mana = player.getData(ModAttachments.MANA);
        PacketDistributor.sendToPlayer(player, new ManaSyncPayload(mana.getCurrentMana(), mana.getMaxMana()));
    }

    private ModNetwork() {}
}
