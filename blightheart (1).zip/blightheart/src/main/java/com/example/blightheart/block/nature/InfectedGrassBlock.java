// Path: src/main/java/com/example/blightheart/block/nature/InfectedGrassBlock.java
package com.example.blightheart.block.nature;

import com.example.blightheart.block.HeartTracker;
import com.example.blightheart.dimension.ModDimensions;
import com.example.blightheart.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Заражённый дёрн: багровая поверхность из тонких мясистых волокон.
 * Медленно заражает соседние травяные блоки (как мицелий), а если её чем-то накрыть — превращается в землю.
 */
public class InfectedGrassBlock extends Block {

    public InfectedGrassBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        // Накрыли сплошным блоком — трава "задыхается"
        BlockState above = level.getBlockState(pos.above());
        if (above.isSolidRender(level, pos.above())) {
            level.setBlockAndUpdate(pos, Blocks.DIRT.defaultBlockState());
            return;
        }
        // Сердец в этом мире больше нет — заражение отступает, дёрн снова становится травой
        if (!ModDimensions.isInfectedWorld(level) && !HeartTracker.get(level).hasHearts()) {
            level.setBlockAndUpdate(pos, Blocks.GRASS_BLOCK.defaultBlockState());
            return;
        }
        if (!level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) return;

        // Заражаем один случайный травяной блок рядом (на 1 блок по горизонтали и ±1 по высоте)
        BlockPos target = pos.offset(random.nextInt(3) - 1, random.nextInt(3) - 1, random.nextInt(3) - 1);
        if (level.isLoaded(target) && level.getBlockState(target).is(Blocks.GRASS_BLOCK)
                && !level.getBlockState(target.above()).isSolidRender(level, target.above())) {
            level.setBlockAndUpdate(target, ModBlocks.INFECTED_GRASS_BLOCK.get().defaultBlockState());
        }
    }

    /** Над испорченной травой изредка поднимаются споры. */
    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(12) == 0 && level.getBlockState(pos.above()).isAir()) {
            level.addParticle(ParticleTypes.CRIMSON_SPORE, pos.getX() + random.nextDouble(), pos.getY() + 1.1D,
                    pos.getZ() + random.nextDouble(), 0.0D, 0.0D, 0.0D);
        }
    }
}
