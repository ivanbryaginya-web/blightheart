// Path: src/main/java/com/example/blightheart/block/nature/BlightPlantBlock.java
package com.example.blightheart.block.nature;

import com.example.blightheart.block.InfectionManager;
import com.example.blightheart.block.InfectionMassBlock;
import com.example.blightheart.event.ArmorSetEvents;
import com.example.blightheart.registry.ModBlocks;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

/**
 * Растения Заражения: испорченная трава, гнилоцвет и пульсирующий нарост.
 * Один класс с настройками, чтобы не плодить почти одинаковые файлы.
 */
public class BlightPlantBlock extends BushBlock {

    private final VoxelShape shape;
    /** Иссушает ли тех, кто сквозь него проходит (как роза иссушения). */
    private final boolean withering;
    /** Может ли расти на камне (например, в пещерах). */
    private final boolean growsOnStone;
    /** Какие частицы испускает (null — никаких). */
    @Nullable
    private final ParticleOptions particle;

    private final MapCodec<BlightPlantBlock> codec;

    public BlightPlantBlock(Properties properties, VoxelShape shape, boolean withering, boolean growsOnStone,
                            @Nullable ParticleOptions particle) {
        super(properties);
        this.shape = shape;
        this.withering = withering;
        this.growsOnStone = growsOnStone;
        this.particle = particle;
        this.codec = simpleCodec(p -> new BlightPlantBlock(p, shape, withering, growsOnStone, particle));
    }

    @Override
    protected MapCodec<? extends BushBlock> codec() {
        return codec;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        // Случайный сдвиг внутри блока (offsetType XZ) — как у обычной травы, чтобы поле не выглядело сеткой
        Vec3 offset = state.getOffset(level, pos);
        return shape.move(offset.x, offset.y, offset.z);
    }

    /** На чём может расти: земля (в т.ч. заражённый дёрн), масса, а некоторые — и на камне. */
    @Override
    protected boolean mayPlaceOn(BlockState ground, BlockGetter level, BlockPos pos) {
        return ground.is(BlockTags.DIRT)
                || ground.getBlock() instanceof InfectionMassBlock
                || ground.is(ModBlocks.INFECTED_GRASS_BLOCK.get())
                || (growsOnStone && ground.is(BlockTags.BASE_STONE_OVERWORLD));
    }

    /** Гнилоцвет иссушает всех, кроме существ Заражения и тех, кто в хитиновой броне. */
    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (withering && !level.isClientSide && entity instanceof LivingEntity living
                && InfectionManager.isVictim(living) && !ArmorSetEvents.wearsChitin(living)
                && !ArmorSetEvents.wearsMatriarch(living)) {
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, 40, 0));
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (particle != null && random.nextInt(5) == 0) {
            level.addParticle(particle, pos.getX() + 0.3D + random.nextDouble() * 0.4D, pos.getY() + 0.5D,
                    pos.getZ() + 0.3D + random.nextDouble() * 0.4D, 0.0D, 0.02D, 0.0D);
        }
    }
}
