// Path: src/main/java/com/example/blightheart/dimension/PortalHelper.java
package com.example.blightheart.dimension;

import com.example.blightheart.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Всё про портал:
 *  - поиск рамки 4×5 из Окаменевшей плоти (внутри пусто 2×3) и её активация;
 *  - перемещение игрока между мирами;
 *  - поиск или постройка портала на "той стороне", чтобы можно было вернуться.
 */
public final class PortalHelper {

    /** Ширина и высота пустого места внутри рамки (как у минимального портала в Незер). */
    private static final int INNER_WIDTH = 2;
    private static final int INNER_HEIGHT = 3;

    // ===================== АКТИВАЦИЯ РАМКИ =====================

    /**
     * Ищем рядом с кликнутым блоком правильную рамку и заполняем её порталом.
     * Проверяем обе ориентации (вдоль X и вдоль Z) и все сдвиги, при которых кликнутый блок может быть частью рамки.
     */
    public static boolean tryActivate(Level level, BlockPos clicked) {
        for (Direction.Axis axis : new Direction.Axis[]{Direction.Axis.X, Direction.Axis.Z}) {
            Direction right = axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;
            for (int dx = -INNER_WIDTH - 1; dx <= 1; dx++) {
                for (int dy = -INNER_HEIGHT - 1; dy <= 1; dy++) {
                    BlockPos innerBottomLeft = clicked.relative(right, dx).above(dy);
                    if (isValidFrame(level, innerBottomLeft, right)) {
                        fillPortal(level, innerBottomLeft, right, axis);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean isValidFrame(Level level, BlockPos inner, Direction right) {
        for (int i = 0; i < INNER_WIDTH; i++)
            for (int j = 0; j < INNER_HEIGHT; j++)
                if (!level.getBlockState(inner.relative(right, i).above(j)).isAir()) return false;

        for (int i = 0; i < INNER_WIDTH; i++) {
            if (!isFrame(level, inner.relative(right, i).below())) return false;          // низ
            if (!isFrame(level, inner.relative(right, i).above(INNER_HEIGHT))) return false; // верх
        }
        for (int j = 0; j < INNER_HEIGHT; j++) {
            if (!isFrame(level, inner.relative(right, -1).above(j))) return false;          // левый край
            if (!isFrame(level, inner.relative(right, INNER_WIDTH).above(j))) return false; // правый край
        }
        return true;
    }

    private static boolean isFrame(Level level, BlockPos pos) {
        return level.getBlockState(pos).is(ModBlocks.PETRIFIED_FLESH.get());
    }

    private static void fillPortal(Level level, BlockPos inner, Direction right, Direction.Axis axis) {
        BlockState portal = ModBlocks.INFECTION_PORTAL.get().defaultBlockState().setValue(InfectionPortalBlock.AXIS, axis);
        for (int i = 0; i < INNER_WIDTH; i++)
            for (int j = 0; j < INNER_HEIGHT; j++)
                level.setBlock(inner.relative(right, i).above(j), portal, Block.UPDATE_CLIENTS);
        level.playSound(null, inner, SoundEvents.END_PORTAL_SPAWN, SoundSource.BLOCKS, 0.8F, 0.6F);
    }

    // ===================== ПЕРЕМЕЩЕНИЕ =====================

    /** Из обычного мира — в Заражённый; из Заражённого — обратно в обычный. Координаты X/Z сохраняются. */
    public static void teleport(ServerPlayer player) {
        ServerLevel current = player.serverLevel();
        boolean inInfected = ModDimensions.isInfectedWorld(current);
        ServerLevel target = player.server.getLevel(inInfected ? Level.OVERWORLD : ModDimensions.INFECTED_WORLD);
        if (target == null) return;

        BlockPos stand = findOrBuildExit(target, player.getBlockX(), player.getBlockZ());
        player.setPortalCooldown(); // защита от мгновенного "перескока" обратно
        player.teleportTo(target, stand.getX() + 0.5D, stand.getY(), stand.getZ() + 0.5D, player.getYRot(), player.getXRot());
        target.playSound(null, stand, SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.4F, 0.8F);

        if (!inInfected) {
            player.displayClientMessage(Component.translatable("message.blightheart.entered_infected_world"), true);
        }
    }

    /**
     * Ищем портал рядом с точкой прибытия; если его нет — строим новый, чтобы игрок мог вернуться.
     * @return позиция, где игрок встанет (перед порталом)
     */
    private static BlockPos findOrBuildExit(ServerLevel level, int x, int z) {
        int surface = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);

        // 1. Уже есть портал поблизости (например, построенный в прошлый раз)?
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        for (int dx = -12; dx <= 12; dx++) {
            for (int dz = -12; dz <= 12; dz++) {
                for (int dy = -24; dy <= 24; dy++) {
                    cursor.set(x + dx, surface + dy, z + dz);
                    BlockState state = level.getBlockState(cursor);
                    if (state.is(ModBlocks.INFECTION_PORTAL.get())) {
                        BlockPos bottom = cursor.immutable();
                        while (level.getBlockState(bottom.below()).is(ModBlocks.INFECTION_PORTAL.get())) bottom = bottom.below();
                        Direction front = state.getValue(InfectionPortalBlock.AXIS) == Direction.Axis.X
                                ? Direction.SOUTH : Direction.EAST;
                        BlockPos stand = bottom.relative(front);
                        return level.getBlockState(stand).isAir() ? stand : bottom.relative(front.getOpposite());
                    }
                }
            }
        }

        // 2. Портала нет — строим. Если под ногами пустота или вода, ставим платформу на высоте 70.
        int y = surface;
        if (y <= level.getMinBuildHeight() + 2 || !level.getFluidState(new BlockPos(x, y - 1, z)).isEmpty()) y = 70;
        return buildPortal(level, new BlockPos(x, y, z));
    }

    /** Строит рамку вдоль оси X: низ рамки на уровне base. Перед и за порталом — площадка и свободное место. */
    private static BlockPos buildPortal(ServerLevel level, BlockPos base) {
        BlockState frame = ModBlocks.PETRIFIED_FLESH.get().defaultBlockState();
        BlockState portal = ModBlocks.INFECTION_PORTAL.get().defaultBlockState()
                .setValue(InfectionPortalBlock.AXIS, Direction.Axis.X);

        for (int dx = -1; dx <= INNER_WIDTH; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                level.setBlockAndUpdate(base.offset(dx, -1, dz), frame);        // площадка под ногами
                for (int dy = 0; dy <= INNER_HEIGHT + 1; dy++) {                // расчищаем место
                    if (dz != 0) level.setBlockAndUpdate(base.offset(dx, dy, dz), Blocks.AIR.defaultBlockState());
                }
            }
        }
        for (int dx = -1; dx <= INNER_WIDTH; dx++) {
            level.setBlockAndUpdate(base.offset(dx, 0, 0), frame);                  // низ рамки
            level.setBlockAndUpdate(base.offset(dx, INNER_HEIGHT + 1, 0), frame);   // верх рамки
        }
        for (int dy = 1; dy <= INNER_HEIGHT; dy++) {
            level.setBlockAndUpdate(base.offset(-1, dy, 0), frame);                 // левый край
            level.setBlockAndUpdate(base.offset(INNER_WIDTH, dy, 0), frame);        // правый край
            for (int dx = 0; dx < INNER_WIDTH; dx++)
                level.setBlock(base.offset(dx, dy, 0), portal, Block.UPDATE_CLIENTS);
        }
        return base.offset(0, 1, 1); // встаём перед порталом
    }

    private PortalHelper() {}
}
