// Path: src/main/java/com/example/blightheart/client/SpitterRenderer.java
package com.example.blightheart.client;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.client.model.SpitterModel;
import com.example.blightheart.entity.SpitterEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Рендер на собственной модели + светящийся слой (глаза и т.п.). */
public class SpitterRenderer extends MobRenderer<SpitterEntity, SpitterModel<SpitterEntity>> {

    private static final ResourceLocation TEXTURE = BlightheartMod.id("textures/entity/spitter.png");
    private static final ResourceLocation GLOW = BlightheartMod.id("textures/entity/spitter_glow.png");

    public SpitterRenderer(EntityRendererProvider.Context context) {
        super(context, new SpitterModel<>(context.bakeLayer(SpitterModel.LAYER)), 0.5F);
        this.addLayer(new GlowLayer<>(this, GLOW));
    }

    @Override
    public ResourceLocation getTextureLocation(SpitterEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(SpitterEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.0F, 1.0F, 1.0F);
    }
}
