// Path: src/main/java/com/example/blightheart/client/SpitterRenderer.java
package com.example.blightheart.client;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.entity.SpitterEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Плевун: тощая модель скелета со своей "кислотной" текстурой. */
public class SpitterRenderer extends HumanoidMobRenderer<SpitterEntity, HumanoidModel<SpitterEntity>> {

    private static final ResourceLocation TEXTURE = BlightheartMod.id("textures/entity/spitter.png");

    public SpitterRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.SKELETON)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(SpitterEntity entity) {
        return TEXTURE;
    }
}
