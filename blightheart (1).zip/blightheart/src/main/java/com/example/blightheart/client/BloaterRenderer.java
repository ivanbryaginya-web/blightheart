// Path: src/main/java/com/example/blightheart/client/BloaterRenderer.java
package com.example.blightheart.client;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.client.model.BloaterModel;
import com.example.blightheart.entity.BloaterEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Гнойник: своя модель; перед взрывом раздувается, дрожит и мигает белым. */
public class BloaterRenderer extends MobRenderer<BloaterEntity, BloaterModel<BloaterEntity>> {

    private static final ResourceLocation TEXTURE = BlightheartMod.id("textures/entity/bloater.png");
    private static final ResourceLocation GLOW = BlightheartMod.id("textures/entity/bloater_glow.png");

    public BloaterRenderer(EntityRendererProvider.Context context) {
        super(context, new BloaterModel<>(context.bakeLayer(BloaterModel.LAYER)), 0.6F);
        this.addLayer(new GlowLayer<>(this, GLOW));
    }

    @Override
    public ResourceLocation getTextureLocation(BloaterEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(BloaterEntity entity, PoseStack poseStack, float partialTick) {
        float swell = Mth.clamp(entity.getSwelling(partialTick), 0.0F, 1.0F);
        float wobble = 1.0F + Mth.sin(swell * 100.0F) * swell * 0.02F;
        float curve = swell * swell * swell * swell;
        float wide = (1.15F + curve * 0.5F) * wobble;
        float tall = (1.15F + curve * 0.1F) / wobble;
        poseStack.scale(wide, tall, wide);
    }

    @Override
    protected float getWhiteOverlayProgress(BloaterEntity entity, float partialTick) {
        float swell = entity.getSwelling(partialTick);
        return (int) (swell * 10.0F) % 2 == 0 ? 0.0F : Mth.clamp(swell, 0.5F, 1.0F);
    }
}
