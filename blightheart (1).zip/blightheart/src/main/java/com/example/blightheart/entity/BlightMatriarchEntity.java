// Path: src/main/java/com/example/blightheart/entity/BlightMatriarchEntity.java
package com.example.blightheart.entity;

import com.example.blightheart.block.InfectionManager;
import com.example.blightheart.registry.ModBlocks;
import com.example.blightheart.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * БОСС: Матка Заражения — прародительница всех Сердец.
 *  - 300 здоровья, броня, не отбрасывается; полоса здоровья вверху экрана;
 *  - каждые 10 секунд рожает 3 Порождения;
 *  - каждые 7 секунд бьёт о землю: урон и подбрасывание всех вокруг;
 *  - на половине здоровья впадает в ярость: быстрее, сильнее, атакует чаще.
 */
public class BlightMatriarchEntity extends BlightMonster {

    private final ServerBossEvent bossEvent = (ServerBossEvent) new ServerBossEvent(getDisplayName(),
            BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10).setDarkenScreen(true);

    private int summonCooldown = 100;
    private int slamCooldown = 80;
    private boolean enraged = false;

    public BlightMatriarchEntity(EntityType<? extends BlightMatriarchEntity> type, Level level) {
        super(type, level);
        this.xpReward = 150;
        setPersistenceRequired(); // босс никогда не исчезает сам
    }

    public static AttributeSupplier.Builder createAttributes() {
        return BlightMonster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.ARMOR, 10.0D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 1.5D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this, BlightMonster.class));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, false));
    }

    /** Мозг босса: полоса здоровья, ярость и особые атаки. */
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());
        if (!(level() instanceof ServerLevel server)) return;

        // Ярость на половине здоровья — один раз
        if (!enraged && getHealth() < getMaxHealth() * 0.5F) becomeEnraged(server);

        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;

        if (--summonCooldown <= 0) {
            summonSpawn(server);
            summonCooldown = enraged ? 140 : 200;
        }
        if (--slamCooldown <= 0 && distanceToSqr(target) < 49.0D) {
            groundSlam(server);
            slamCooldown = enraged ? 90 : 140;
        }
    }

    /** Рожает 3 Порождения вокруг себя и сразу натравливает их на цель. */
    private void summonSpawn(ServerLevel server) {
        for (int i = 0; i < 3; i++) {
            SpawnlingEntity spawn = ModEntities.SPAWNLING.get().create(server);
            if (spawn == null) continue;
            double angle = random.nextDouble() * Math.PI * 2.0D;
            spawn.moveTo(getX() + Math.cos(angle) * 2.5D, getY(), getZ() + Math.sin(angle) * 2.5D,
                    random.nextFloat() * 360.0F, 0.0F);
            spawn.setTarget(getTarget());
            server.addFreshEntity(spawn);
            server.sendParticles(ParticleTypes.SCULK_SOUL, spawn.getX(), spawn.getY() + 0.3D, spawn.getZ(),
                    10, 0.3D, 0.3D, 0.3D, 0.02D);
        }
        server.playSound(null, blockPosition(), SoundEvents.SCULK_SHRIEKER_SHRIEK, SoundSource.HOSTILE, 2.0F, 0.5F);
    }

    /** Удар о землю: урон всем вокруг в радиусе 6 и подбрасывание от босса. */
    private void groundSlam(ServerLevel server) {
        List<LivingEntity> victims = server.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(6.0D),
                InfectionManager::isVictim);
        for (LivingEntity victim : victims) {
            victim.hurt(damageSources().mobAttack(this), enraged ? 12.0F : 8.0F);
            Vec3 push = victim.position().subtract(position()).normalize().scale(1.4D);
            victim.push(push.x, 0.7D, push.z);
            victim.hurtMarked = true; // отправить игроку новую скорость
        }
        server.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, ModBlocks.INFECTION_MASS.get().defaultBlockState()),
                getX(), getY() + 0.2D, getZ(), 120, 3.0D, 0.1D, 3.0D, 0.15D);
        server.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.5D, getZ(), 6, 2.0D, 0.2D, 2.0D, 0.0D);
        server.playSound(null, blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 2.0F, 0.6F);
        server.playSound(null, blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 1.5F, 0.4F);
    }

    private void becomeEnraged(ServerLevel server) {
        enraged = true;
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.33D);
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(16.0D);
        bossEvent.setColor(BossEvent.BossBarColor.PURPLE);
        server.playSound(null, blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 1.5F, 0.7F);
        Component message = Component.translatable("message.blightheart.matriarch_enraged").withStyle(ChatFormatting.DARK_RED);
        for (ServerPlayer player : bossEvent.getPlayers()) player.displayClientMessage(message, true);
    }

    // ---- Полоса здоровья видна игрокам, которые видят босса ----
    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(Component name) {
        super.setCustomName(name);
        bossEvent.setName(getDisplayName());
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    // ---- Звуки: низкий рёв ----
    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.WARDEN_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.RAVAGER_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.WITHER_DEATH; }

    @Override
    public float getVoicePitch() { return 0.6F; }

    // ---- Сохранение ----
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Enraged", enraged);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        enraged = tag.getBoolean("Enraged");
        if (enraged) {
            getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.33D);
            getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(16.0D);
            bossEvent.setColor(BossEvent.BossBarColor.PURPLE);
        }
        if (hasCustomName()) bossEvent.setName(getDisplayName());
    }
}
