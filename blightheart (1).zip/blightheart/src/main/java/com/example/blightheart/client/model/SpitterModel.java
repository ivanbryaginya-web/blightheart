// Path: src/main/java/com/example/blightheart/client/model/SpitterModel.java
package com.example.blightheart.client.model;

import com.example.blightheart.BlightheartMod;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/**
 * Плевун: тощее тело, длинная шея и пульсирующий мешок с кислотой на спине.
 * Собственная модель (сгенерирована вместе с текстурой — развёртка UV совпадает).
 */
public class SpitterModel<T extends Entity> extends HierarchicalModel<T> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(BlightheartMod.id("spitter"), "main");

    private static final float DEG = (float) (Math.PI / 180.0);
    private static final float PI = (float) Math.PI;

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart sac;
    private final ModelPart neck;
    private final ModelPart head;
    private final ModelPart arm_r;
    private final ModelPart arm_l;
    private final ModelPart leg_r;
    private final ModelPart leg_l;

    public SpitterModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.sac = root.getChild("sac");
        this.neck = root.getChild("neck");
        this.head = root.getChild("head");
        this.arm_r = root.getChild("arm_r");
        this.arm_l = root.getChild("arm_l");
        this.leg_r = root.getChild("leg_r");
        this.leg_l = root.getChild("leg_l");
    }

    /** Геометрия: кубы, их положение и развёртка на текстуре 64×64. */
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -12.0F, -2.0F, 8.0F, 12.0F, 4.0F),
                PartPose.offsetAndRotation(0.0F, 12.0F, 0.0F, 0.15F, 0.0F, 0.0F));
        root.addOrReplaceChild("sac", CubeListBuilder.create().texOffs(24, 0).addBox(-3.0F, -4.0F, 0.0F, 6.0F, 7.0F, 5.0F),
                PartPose.offset(0.0F, 4.0F, 2.0F));
        root.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(48, 0).addBox(-1.5F, -6.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, 1.0F, -1.0F, 0.3F, 0.0F, 0.0F));
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, -5.0F, -4.0F, 6.0F, 5.0F, 6.0F),
                PartPose.offset(0.0F, -4.0F, -3.0F));
        root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(32, 16).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 14.0F, 2.0F),
                PartPose.offset(-5.0F, 1.0F, 0.0F));
        root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(32, 16).mirror().addBox(-1.0F, -1.0F, -1.0F, 2.0F, 14.0F, 2.0F).mirror(false),
                PartPose.offset(5.0F, 1.0F, 0.0F));
        root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(24, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F),
                PartPose.offset(-2.0F, 12.0F, 0.0F));
        root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(24, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F).mirror(false),
                PartPose.offset(2.0F, 12.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public ModelPart root() {
        return root;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);   // вернуть исходную позу перед анимацией
        // Тонкие конечности; мешок с кислотой на спине пульсирует
        head.yRot = netHeadYaw * DEG;
        head.xRot = headPitch * DEG;
        float s = limbSwing * 0.6662F;
        leg_r.xRot = Mth.cos(s) * 1.4F * limbSwingAmount;
        leg_l.xRot = Mth.cos(s + PI) * 1.4F * limbSwingAmount;
        arm_r.xRot = Mth.cos(s + PI) * 1.0F * limbSwingAmount;
        arm_l.xRot = Mth.cos(s) * 1.0F * limbSwingAmount;
        float pulse = 1.0F + Mth.sin(ageInTicks * 0.15F) * 0.08F;
        sac.xScale = pulse;
        sac.yScale = pulse;
        sac.zScale = pulse;
        neck.xRot += Mth.sin(ageInTicks * 0.05F) * 0.08F;
    }
}
