// Path: src/main/java/com/example/blightheart/entity/BloaterEntity.java
package com.example.blightheart.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Гнойник — раздутый мешок с гноем. Подбирается вплотную, раздувается полторы секунды
 * и лопается: небольшой взрыв (без разрушения блоков) и облако иссушения.
 */
public class BloaterEntity extends BlightMonster {

    /** Сколько тиков раздувается перед взрывом (1,5 секунды). */
    public static final int MAX_FUSE = 30;
    /** Счётчик раздувания синхронизируется с клиентом — чтобы было видно, как моб пухнет и мигает. */
    private static final EntityDataAccessor<Integer> DATA_FUSE =
            SynchedEntityData.defineId(BloaterEntity.class, EntityDataSerializers.INT);

    private int oldFuse;

    public BloaterEntity(EntityType<? extends BloaterEntity> type, Level level) {
        super(type, level);
        this.xpReward = 6;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return BlightMonster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.24D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_FUSE, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.0D, false)); // просто подходит вплотную
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this, BlightMonster.class));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false, PREY));
    }

    public int getFuse() {
        return entityData.get(DATA_FUSE);
    }

    /** Насколько раздут (0..1), плавно между кадрами — для рендера. */
    public float getSwelling(float partialTick) {
        return Mth.lerp(partialTick, (float) oldFuse, (float) getFuse()) / (float) MAX_FUSE;
    }

    @Override
    public void tick() {
        oldFuse = getFuse();
        super.tick();
    }

    /** Цель рядом — раздуваемся; ушла — сдуваемся. Дошли до предела — лопаемся. */
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        LivingEntity target = getTarget();
        int fuse = getFuse();

        if (target != null && target.isAlive() && distanceToSqr(target) < 9.0D) {
            if (fuse == 0) playSound(SoundEvents.CREEPER_PRIMED, 1.0F, 0.5F);
            fuse++;
        } else {
            fuse = Math.max(0, fuse - 1);
        }
        entityData.set(DATA_FUSE, fuse);

        if (fuse >= MAX_FUSE) burst();
    }

    /** Взрыв: урон и отбрасывание, но блоки целы; остаётся облако иссушения. */
    private void burst() {
        if (!(level() instanceof ServerLevel server)) return;
        server.explode(this, getX(), getY(), getZ(), 2.0F, Level.ExplosionInteraction.NONE);

        AreaEffectCloud cloud = new AreaEffectCloud(server, getX(), getY(), getZ());
        cloud.setRadius(3.0F);
        cloud.setRadiusOnUse(-0.3F);
        cloud.setWaitTime(5);
        cloud.setDuration(120);
        cloud.setRadiusPerTick(-cloud.getRadius() / (float) cloud.getDuration());
        cloud.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0));
        server.addFreshEntity(cloud);

        server.sendParticles(ParticleTypes.CRIMSON_SPORE, getX(), getY() + 0.5D, getZ(), 60, 1.2D, 0.6D, 1.2D, 0.05D);
        discard();
    }

    /** Гнойник не кусается — его оружие только взрыв. */
    @Override
    public boolean doHurtTarget(Entity target) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Fuse", getFuse());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(DATA_FUSE, tag.getInt("Fuse"));
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.SLIME_SQUISH; }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.SLIME_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.SLIME_DEATH; }

    @Override
    public float getVoicePitch() { return super.getVoicePitch() * 0.5F; }
}
