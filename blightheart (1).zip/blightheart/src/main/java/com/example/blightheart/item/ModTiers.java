// Path: src/main/java/com/example/blightheart/item/ModTiers.java
package com.example.blightheart.item;

import com.example.blightheart.registry.ModItems;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;

/** Материал инструментов. Сангвинит: прочнее и быстрее алмаза, но слабее незерита. */
public final class ModTiers {

    public static final Tier SANGUINITE = new Tier() {
        @Override public int getUses() { return 1400; }                 // алмаз — 1561, железо — 250
        @Override public float getSpeed() { return 8.5F; }               // алмаз — 8.0
        @Override public float getAttackDamageBonus() { return 3.5F; }   // алмаз — 3.0
        @Override public TagKey<Block> getIncorrectBlocksForDrops() { return BlockTags.INCORRECT_FOR_DIAMOND_TOOL; }
        @Override public int getEnchantmentValue() { return 16; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.of(ModItems.SANGUINITE.get()); }
    };

    /** Хитин: чуть лучше железа. */
    public static final Tier CHITIN = new Tier() {
        @Override public int getUses() { return 500; }
        @Override public float getSpeed() { return 7.0F; }
        @Override public float getAttackDamageBonus() { return 2.5F; }
        @Override public TagKey<Block> getIncorrectBlocksForDrops() { return BlockTags.INCORRECT_FOR_IRON_TOOL; }
        @Override public int getEnchantmentValue() { return 12; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.of(ModItems.CHITIN_PLATE.get()); }
    };

    private ModTiers() {}
}
