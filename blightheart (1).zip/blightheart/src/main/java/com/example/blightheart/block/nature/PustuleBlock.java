// Path: src/main/java/com/example/blightheart/block/nature/PustuleBlock.java
package com.example.blightheart.block.nature;

import com.example.blightheart.entity.BlightMonster;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Гнойный нарост — пузырь на земле. Наступишь (не крадучись) — лопнет облаком яда.
 * Если подкрасться на Shift — можно спокойно сломать и иногда добыть Целебную смолу.
 */
public class PustuleBlock extends Block {

    private static final VoxelShape SHAPE = Block.box(3.0D, 0.0D, 3.0D, 13.0D, 8.0D, 13.0D);

    public PustuleBlock(Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (level instanceof ServerLevel server && entity instanceof LivingEntity
                && !(entity instanceof BlightMonster) && !entity.isSteppingCarefully()) {
            burst(server, pos);
        }
        super.stepOn(level, pos, state, entity);
    }

    private static void burst(ServerLevel level, BlockPos pos) {
        level.removeBlock(pos, false);
        AreaEffectCloud cloud = new AreaEffectCloud(level, pos.getX() + 0.5D, pos.getY() + 0.2D, pos.getZ() + 0.5D);
        cloud.setRadius(2.0F);
        cloud.setDuration(60);
        cloud.setRadiusPerTick(-cloud.getRadius() / (float) cloud.getDuration());
        cloud.addEffect(new MobEffectInstance(MobEffects.POISON, 80, 0));
        level.addFreshEntity(cloud);
        level.sendParticles(ParticleTypes.ITEM_SLIME, pos.getX() + 0.5D, pos.getY() + 0.4D, pos.getZ() + 0.5D,
                20, 0.3D, 0.2D, 0.3D, 0.1D);
        level.playSound(null, pos, SoundEvents.SLIME_BLOCK_BREAK, SoundSource.BLOCKS, 1.0F, 0.6F);
    }
}
