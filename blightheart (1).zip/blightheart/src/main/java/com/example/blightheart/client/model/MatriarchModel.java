// Path: src/main/java/com/example/blightheart/client/model/MatriarchModel.java
package com.example.blightheart.client.model;

import com.example.blightheart.BlightheartMod;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/**
 * Матка Заражения: огромное тело, костяная корона и четыре щупальца на спине.
 * Собственная модель (сгенерирована вместе с текстурой — развёртка UV совпадает).
 */
public class MatriarchModel<T extends Entity> extends HierarchicalModel<T> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(BlightheartMod.id("blight_matriarch"), "main");

    private static final float DEG = (float) (Math.PI / 180.0);
    private static final float PI = (float) Math.PI;

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart arm_r;
    private final ModelPart arm_l;
    private final ModelPart leg_r;
    private final ModelPart leg_l;
    private final ModelPart tent_1;
    private final ModelPart tent_2;
    private final ModelPart tent_3;
    private final ModelPart tent_4;

    public MatriarchModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.arm_r = root.getChild("arm_r");
        this.arm_l = root.getChild("arm_l");
        this.leg_r = root.getChild("leg_r");
        this.leg_l = root.getChild("leg_l");
        this.tent_1 = root.getChild("tent_1");
        this.tent_2 = root.getChild("tent_2");
        this.tent_3 = root.getChild("tent_3");
        this.tent_4 = root.getChild("tent_4");
    }

    /** Геометрия: кубы, их положение и развёртка на текстуре 128×128. */
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-9.0F, -16.0F, -6.0F, 18.0F, 16.0F, 12.0F),
                PartPose.offsetAndRotation(0.0F, 10.0F, 0.0F, 0.1F, 0.0F, 0.0F));
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(64, 0).addBox(-5.0F, -9.0F, -7.0F, 10.0F, 9.0F, 9.0F).texOffs(104, 0).addBox(-4.0F, -14.0F, -3.0F, 2.0F, 5.0F, 2.0F).texOffs(104, 0).addBox(-1.0F, -15.0F, -4.0F, 2.0F, 6.0F, 2.0F).texOffs(104, 0).mirror().addBox(2.0F, -14.0F, -3.0F, 2.0F, 5.0F, 2.0F).mirror(false),
                PartPose.offset(0.0F, -6.0F, -2.0F));
        root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(24, 30).addBox(-6.0F, -2.0F, -3.5F, 7.0F, 24.0F, 7.0F),
                PartPose.offset(-10.0F, -4.0F, 0.0F));
        root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(24, 30).mirror().addBox(-1.0F, -2.0F, -3.5F, 7.0F, 24.0F, 7.0F).mirror(false),
                PartPose.offset(10.0F, -4.0F, 0.0F));
        root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 30).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 14.0F, 6.0F),
                PartPose.offset(-5.0F, 10.0F, 0.0F));
        root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(0, 30).mirror().addBox(-3.0F, 0.0F, -3.0F, 6.0F, 14.0F, 6.0F).mirror(false),
                PartPose.offset(5.0F, 10.0F, 0.0F));
        root.addOrReplaceChild("tent_1", CubeListBuilder.create().texOffs(56, 30).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 14.0F, 2.0F),
                PartPose.offsetAndRotation(-5.0F, -4.0F, 5.0F, 0.7F, 0.0F, 0.3F));
        root.addOrReplaceChild("tent_2", CubeListBuilder.create().texOffs(56, 30).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 14.0F, 2.0F).mirror(false),
                PartPose.offsetAndRotation(5.0F, -4.0F, 5.0F, 0.7F, 0.0F, -0.3F));
        root.addOrReplaceChild("tent_3", CubeListBuilder.create().texOffs(56, 30).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 14.0F, 2.0F),
                PartPose.offsetAndRotation(-2.0F, 0.0F, 6.0F, 0.9F, 0.0F, 0.1F));
        root.addOrReplaceChild("tent_4", CubeListBuilder.create().texOffs(56, 30).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 14.0F, 2.0F).mirror(false),
                PartPose.offsetAndRotation(2.0F, 0.0F, 6.0F, 0.9F, 0.0F, -0.1F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ModelPart root() {
        return root;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);   // вернуть исходную позу перед анимацией
        // Огромная поступь, взмахи руками при атаке и вечно шевелящиеся щупальца на спине
        head.yRot = netHeadYaw * DEG * 0.6F;
        head.xRot = headPitch * DEG * 0.6F;
        float s = limbSwing * 0.5F;
        leg_r.xRot = Mth.cos(s) * 0.9F * limbSwingAmount;
        leg_l.xRot = Mth.cos(s + PI) * 0.9F * limbSwingAmount;
        arm_r.xRot = Mth.cos(s + PI) * 0.6F * limbSwingAmount;
        arm_l.xRot = Mth.cos(s) * 0.6F * limbSwingAmount;
        if (attackTime > 0.0F) {
            float swing = Mth.sin(attackTime * PI);
            arm_r.xRot -= swing * 2.4F;
            arm_l.xRot -= swing * 2.4F;
        }
        tent_1.xRot += Mth.sin(ageInTicks * 0.10F) * 0.25F;
        tent_2.xRot += Mth.sin(ageInTicks * 0.10F + 1.5F) * 0.25F;
        tent_3.zRot += Mth.sin(ageInTicks * 0.13F + 3.0F) * 0.30F;
        tent_4.zRot += Mth.sin(ageInTicks * 0.13F + 4.5F) * 0.30F;
    }
}
