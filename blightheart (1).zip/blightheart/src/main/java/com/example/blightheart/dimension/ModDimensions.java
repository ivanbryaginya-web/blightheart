// Path: src/main/java/com/example/blightheart/dimension/ModDimensions.java
package com.example.blightheart.dimension;

import com.example.blightheart.BlightheartMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/**
 * Заражённый мир. Само измерение описано в JSON (data/blightheart/dimension/infected_world.json):
 * рельеф как в обычном мире, но багровое небо, кровавая вода, мёртвые деревья, пятна плоти и вечный закат.
 */
public final class ModDimensions {

    public static final ResourceKey<Level> INFECTED_WORLD =
            ResourceKey.create(Registries.DIMENSION, BlightheartMod.id("infected_world"));

    public static boolean isInfectedWorld(Level level) {
        return level.dimension().equals(INFECTED_WORLD);
    }

    private ModDimensions() {}
}
