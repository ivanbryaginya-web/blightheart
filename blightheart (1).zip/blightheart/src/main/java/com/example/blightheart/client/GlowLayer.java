// Path: src/main/java/com/example/blightheart/client/GlowLayer.java
package com.example.blightheart.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/** Светящийся слой (глаза, кислотный мешок, трещины): рисуется на полной яркости даже в темноте. */
public class GlowLayer<T extends LivingEntity, M extends EntityModel<T>> extends EyesLayer<T, M> {

    private final RenderType renderType;

    public GlowLayer(RenderLayerParent<T, M> parent, ResourceLocation texture) {
        super(parent);
        this.renderType = RenderType.eyes(texture);
    }

    @Override
    public RenderType renderType() {
        return renderType;
    }
}
