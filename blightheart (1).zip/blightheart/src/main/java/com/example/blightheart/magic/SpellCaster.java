// Path: src/main/java/com/example/blightheart/magic/SpellCaster.java
package com.example.blightheart.magic;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import com.example.blightheart.block.InfectionMassBlock;
import com.example.blightheart.entity.BlightMonster;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Эффекты заклинаний. Вызывается только на сервере.
 * Логика отделена от предмета, чтобы её можно было переиспользовать (свитки, посохи, мобы-маги).
 */
public final class SpellCaster {

    /**
     * Сотворить заклинание.
     * @param power множитель силы (у Посоха Архимага он больше 1)
     * @return true, если заклинание сработало (только тогда списывается мана)
     */
    public static boolean cast(SpellType spell, ServerLevel level, ServerPlayer player, float power) {
        return switch (spell) {
            case FIREBALL -> castFireball(level, player, power);
            case HEAL -> castHeal(level, player, power);
            case LEVITATION -> castLevitation(level, player, power);
            case PURIFY -> castPurify(level, player, power);
            case LIGHTNING -> castLightning(level, player, power);
            case FROST_NOVA -> castFrostNova(level, player, power);
            case BLINK -> castBlink(level, player, power);
            case WARD -> castWard(level, player, power);
            case METEOR -> castMeteor(level, player, power);
            case LIFE_DRAIN -> castLifeDrain(level, player, power);
            case REPULSE -> castRepulse(level, player, power);
            case REVEAL -> castReveal(level, player, power);
        };
    }

    /** Огненный шар: малый огненный снаряд (как у всполоха), поджигает мобов и блоки. */
    private static boolean castFireball(ServerLevel level, ServerPlayer player, float power) {
        Vec3 look = player.getLookAngle();
        SmallFireball fireball = new SmallFireball(level, player, look);
        // Появляется перед глазами игрока, чтобы не задеть его самого
        fireball.setPos(player.getX() + look.x, player.getEyeY() - 0.1D + look.y, player.getZ() + look.z);
        fireball.setDeltaMovement(look.scale(1.2D * power));
        level.addFreshEntity(fireball);

        level.playSound(null, player.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0F, 1.0F);
        return true;
    }

    /** Исцеление: восстанавливает 3 сердца (× сила палочки). Не срабатывает при полном здоровье. */
    private static boolean castHeal(ServerLevel level, ServerPlayer player, float power) {
        if (player.getHealth() >= player.getMaxHealth()) {
            player.displayClientMessage(Component.translatable("message.blightheart.already_healthy")
                    .withStyle(ChatFormatting.GRAY), true);
            return false; // мана не тратится впустую
        }
        player.heal(6.0F * power);

        level.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.0D, player.getZ(),
                6, 0.4D, 0.5D, 0.4D, 0.0D);
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.2F);
        return true;
    }

    /** Левитация: подбрасывает игрока вверх и даёт плавное падение, чтобы не разбиться. */
    private static boolean castLevitation(ServerLevel level, ServerPlayer player, float power) {
        player.setDeltaMovement(player.getDeltaMovement().add(0.0D, 1.0D * power, 0.0D));
        player.hurtMarked = true; // заставляет сервер отправить новую скорость клиенту
        player.resetFallDistance();
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100));

        level.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY(), player.getZ(),
                15, 0.4D, 0.1D, 0.4D, 0.05D);
        level.playSound(null, player.blockPosition(), SoundEvents.PHANTOM_FLAP, SoundSource.PLAYERS, 1.0F, 1.4F);
        return true;
    }

    /**
     * Очищение — оружие против Сердца Заражения.
     * Масса и мембрана в радиусе начинают гнить (волна гниения пойдёт дальше сама),
     * а Порождения и Стражи рядом получают сильный урон и загораются.
     */
    private static boolean castPurify(ServerLevel level, ServerPlayer player, float power) {
        int radius = Math.round(4 * power);
        BlockPos center = player.blockPosition();
        int purified = 0;

        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-radius, -radius, -radius), center.offset(radius, radius, radius))) {
            if (pos.distSqr(center) > radius * radius) continue;
            BlockState state = level.getBlockState(pos);
            if (state.getBlock() instanceof InfectionMassBlock && !state.getValue(InfectionMassBlock.DECAYING)) {
                InfectionMassBlock.startDecay(level, pos.immutable(), state, level.getRandom());
                purified++;
            }
        }

        AABB area = new AABB(center).inflate(radius + 2);
        for (BlightMonster monster : level.getEntitiesOfClass(BlightMonster.class, area)) {
            monster.hurt(level.damageSources().indirectMagic(player, player), 10.0F * power);
            monster.igniteForSeconds(4);
            purified++;
        }

        if (purified == 0) {
            player.displayClientMessage(Component.translatable("message.blightheart.nothing_to_purify")
                    .withStyle(ChatFormatting.GRAY), true);
            return false; // нечего очищать — мана не тратится
        }

        level.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0D, player.getZ(),
                60, radius * 0.5D, 1.0D, radius * 0.5D, 0.05D);
        level.playSound(null, center, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0F, 1.6F);
        return true;
    }

    /** Молния туда, куда смотрит игрок. Сильный посох бьёт тремя молниями сразу. */
    private static boolean castLightning(ServerLevel level, ServerPlayer player, float power) {
        HitResult hit = player.pick(48.0D, 1.0F, false);
        if (hit.getType() == HitResult.Type.MISS) {
            player.displayClientMessage(Component.translatable("message.blightheart.no_target")
                    .withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        Vec3 center = hit.getLocation();
        int bolts = power >= 1.4F ? 3 : 1;
        for (int i = 0; i < bolts; i++) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
            if (bolt == null) continue;
            double ox = i == 0 ? 0 : (level.getRandom().nextDouble() - 0.5D) * 6.0D;
            double oz = i == 0 ? 0 : (level.getRandom().nextDouble() - 0.5D) * 6.0D;
            bolt.moveTo(center.x + ox, center.y, center.z + oz);
            bolt.setCause(player);
            level.addFreshEntity(bolt);
        }
        return true;
    }

    /** Ледяная волна: урон, сильное замедление и "обморожение" всем вокруг. */
    private static boolean castFrostNova(ServerLevel level, ServerPlayer player, float power) {
        double radius = 5.0D * power;
        AABB area = player.getBoundingBox().inflate(radius);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, area, e -> e != player && e.isAlive())) {
            target.hurt(level.damageSources().indirectMagic(player, player), 4.0F * power);
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 2));
            target.setTicksFrozen(Math.max(target.getTicksFrozen(), 200));
        }
        for (int i = 0; i < 48; i++) {
            double angle = i * Math.PI * 2.0D / 48.0D;
            level.sendParticles(ParticleTypes.SNOWFLAKE, player.getX() + Math.cos(angle) * radius * 0.6D,
                    player.getY() + 0.3D, player.getZ() + Math.sin(angle) * radius * 0.6D, 2, 0.2D, 0.1D, 0.2D, 0.02D);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 1.0F, 0.6F);
        level.playSound(null, player.blockPosition(), SoundEvents.POWDER_SNOW_STEP, SoundSource.PLAYERS, 1.5F, 0.8F);
        return true;
    }

    /** Рывок: телепорт к блоку, на который смотришь (до 12 блоков, у сильных посохов дальше). */
    private static boolean castBlink(ServerLevel level, ServerPlayer player, float power) {
        double range = 12.0D * power;
        HitResult hit = player.pick(range, 1.0F, false);
        BlockPos dest;
        if (hit instanceof BlockHitResult blockHit && hit.getType() == HitResult.Type.BLOCK) {
            dest = blockHit.getBlockPos().relative(blockHit.getDirection());
        } else {
            dest = BlockPos.containing(player.getEyePosition().add(player.getLookAngle().scale(range)));
        }
        // Нужно 2 свободных блока, чтобы игрок поместился; если нет — пробуем на блок выше
        if (!level.getBlockState(dest).isAir() || !level.getBlockState(dest.above()).isAir()) dest = dest.above();
        if (!level.getBlockState(dest).isAir() || !level.getBlockState(dest.above()).isAir()) {
            player.displayClientMessage(Component.translatable("message.blightheart.blink_blocked")
                    .withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        level.sendParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1.0D, player.getZ(), 40, 0.3D, 0.6D, 0.3D, 0.3D);
        player.teleportTo(dest.getX() + 0.5D, dest.getY(), dest.getZ() + 0.5D);
        player.resetFallDistance();
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, player.getX(), player.getY() + 1.0D, player.getZ(), 40, 0.3D, 0.6D, 0.3D, 0.1D);
        level.playSound(null, dest, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.2F);
        return true;
    }

    /** Оберег: поглощение (золотые сердца) на 20 секунд и сопротивление урону на 10 секунд. */
    private static boolean castWard(ServerLevel level, ServerPlayer player, float power) {
        int absorption = power >= 1.4F ? 2 : 1;
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400, absorption));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0));
        level.sendParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.0D, player.getZ(), 60, 0.6D, 0.8D, 0.6D, 0.5D);
        level.playSound(null, player.blockPosition(), SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.0F, 0.8F);
        return true;
    }

    /** Метеор: большой огненный шар, как у гаста. Сила взрыва растёт с силой посоха. */
    private static boolean castMeteor(ServerLevel level, ServerPlayer player, float power) {
        Vec3 look = player.getLookAngle();
        LargeFireball meteor = new LargeFireball(level, player, look, power >= 1.4F ? 3 : 2);
        meteor.setPos(player.getX() + look.x * 1.5D, player.getEyeY() - 0.2D + look.y * 1.5D, player.getZ() + look.z * 1.5D);
        meteor.setDeltaMovement(look.scale(1.0D));
        level.addFreshEntity(meteor);
        level.playSound(null, player.blockPosition(), SoundEvents.GHAST_SHOOT, SoundSource.PLAYERS, 1.2F, 0.6F);
        return true;
    }

    /** Похищение жизни: ближайшая цель перед игроком (до 16 блоков) теряет здоровье, игрок его получает. */
    private static boolean castLifeDrain(ServerLevel level, ServerPlayer player, float power) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(16.0D),
                e -> e != player && e.isAlive())) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist < 16.0D && to.normalize().dot(look) > 0.96D && dist < bestDist && player.hasLineOfSight(e)) {
                best = e;
                bestDist = dist;
            }
        }
        if (best == null) {
            player.displayClientMessage(Component.translatable("message.blightheart.no_target")
                    .withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        float damage = 6.0F * power;
        best.hurt(level.damageSources().indirectMagic(player, player), damage);
        player.heal(damage * 0.5F);
        // Алая "нить" от цели к игроку
        Vec3 from = best.getBoundingBox().getCenter();
        for (int i = 0; i <= 12; i++) {
            Vec3 p = from.lerp(player.getBoundingBox().getCenter(), i / 12.0D);
            level.sendParticles(ParticleTypes.DAMAGE_INDICATOR, p.x, p.y, p.z, 1, 0.05D, 0.05D, 0.05D, 0.0D);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.PLAYERS, 1.5F, 1.2F);
        return true;
    }

    /** Отталкивание: всех вокруг отбрасывает от игрока и слегка подбрасывает. */
    private static boolean castRepulse(ServerLevel level, ServerPlayer player, float power) {
        double radius = 6.0D * power;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius),
                e -> e != player && e.isAlive())) {
            Vec3 push = e.position().subtract(player.position()).multiply(1.0D, 0.0D, 1.0D).normalize().scale(1.6D * power);
            e.push(push.x, 0.5D, push.z);
            e.hurtMarked = true;
        }
        level.sendParticles(ParticleTypes.SWEEP_ATTACK, player.getX(), player.getY() + 1.0D, player.getZ(), 16, radius * 0.4D, 0.3D, radius * 0.4D, 0.0D);
        level.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 0.2D, player.getZ(), 40, radius * 0.3D, 0.1D, radius * 0.3D, 0.2D);
        level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.5F, 0.5F);
        return true;
    }

    /** Озарение: ночное зрение на 30 секунд и свечение всех существ в 32 блоках на 10 секунд. */
    private static boolean castReveal(ServerLevel level, ServerPlayer player, float power) {
        player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 600, 0));
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(32.0D * power),
                e -> e != player && e.isAlive())) {
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
        }
        level.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.2D, player.getZ(), 40, 0.8D, 0.8D, 0.8D, 0.05D);
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0F, 1.5F);
        return true;
    }

    private SpellCaster() {}
}
