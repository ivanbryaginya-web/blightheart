// Path: src/main/java/com/example/blightheart/entity/SpitterEntity.java
package com.example.blightheart.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Плевун — тощее существо Заражения, которое держится на расстоянии
 * и плюётся ядовитой кислотой (взрывающимися зельями яда, как ведьма).
 */
public class SpitterEntity extends BlightMonster implements RangedAttackMob {

    public SpitterEntity(EntityType<? extends SpitterEntity> type, Level level) {
        super(type, level);
        this.xpReward = 8;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return BlightMonster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 18.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        // Плевок раз в 2,5 секунды с расстояния до 12 блоков
        this.goalSelector.addGoal(2, new RangedAttackGoal(this, 1.0D, 50, 12.0F));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this, BlightMonster.class));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false, PREY));
    }

    /** Плевок: бросаем взрывающееся зелье яда с упреждением (целимся туда, куда цель бежит). */
    @Override
    public void performRangedAttack(LivingEntity target, float velocity) {
        Vec3 motion = target.getDeltaMovement();
        double dx = target.getX() + motion.x - getX();
        double dy = target.getEyeY() - 1.1D - getY();
        double dz = target.getZ() + motion.z - getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        ThrownPotion spit = new ThrownPotion(level(), this);
        spit.setItem(PotionContents.createItemStack(Items.SPLASH_POTION, Potions.POISON));
        spit.setXRot(spit.getXRot() + 20.0F);
        spit.shoot(dx, dy + horizontal * 0.2D, dz, 0.75F, 8.0F);

        level().playSound(null, getX(), getY(), getZ(), SoundEvents.WITCH_THROW, getSoundSource(),
                1.0F, 0.6F + random.nextFloat() * 0.3F);
        level().addFreshEntity(spit);
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.SKELETON_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.SKELETON_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.SKELETON_DEATH; }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(SoundEvents.SKELETON_STEP, 0.15F, 0.7F);
    }

    @Override
    public float getVoicePitch() { return super.getVoicePitch() * 0.6F; }
}
