// Path: src/main/java/com/example/blightheart/client/ManaHudLayer.java
package com.example.blightheart.client;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.magic.ManaData;
import com.example.blightheart.registry.ModAttachments;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

/**
 * Полоска маны — внизу экрана, слева от хотбара (не мешает чату и списку эффектов).
 * Рамка, градиентная заливка и мерцающий блик, когда мана полная.
 */
@EventBusSubscriber(modid = BlightheartMod.MODID, value = Dist.CLIENT)
public final class ManaHudLayer {

    private static final int BAR_WIDTH = 72;
    private static final int BAR_HEIGHT = 6;

    @SubscribeEvent
    public static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(BlightheartMod.id("mana_bar"), (graphics, deltaTracker) -> render(graphics));
    }

    private static void render(GuiGraphics graphics) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.player.isSpectator()) return;

        ManaData mana = mc.player.getData(ModAttachments.MANA);
        int screenW = graphics.guiWidth();
        int screenH = graphics.guiHeight();

        // Слева от хотбара (хотбар шириной 182 по центру), с отступом под слот второй руки.
        // На очень узком экране — в левый нижний угол.
        int x = Math.max(4, screenW / 2 - 91 - 34 - BAR_WIDTH);
        int y = screenH - 12;

        float fraction = mana.getCurrentMana() / (float) mana.getMaxMana();
        int filled = Math.round(BAR_WIDTH * fraction);

        // Рамка и фон
        graphics.fill(x - 2, y - 2, x + BAR_WIDTH + 2, y + BAR_HEIGHT + 2, 0xFF1A1030);
        graphics.fill(x - 1, y - 1, x + BAR_WIDTH + 1, y + BAR_HEIGHT + 1, 0xFF4B3A8C);
        graphics.fill(x, y, x + BAR_WIDTH, y + BAR_HEIGHT, 0xFF0E0A1E);
        // Заливка: сверху светлее, снизу темнее
        if (filled > 0) graphics.fillGradient(x, y, x + filled, y + BAR_HEIGHT, 0xFF8FB8FF, 0xFF3A4BD6);
        // Блик на полной мане
        if (fraction >= 1.0F) {
            int shine = (int) ((mc.level == null ? 0 : mc.level.getGameTime() % 60) * (BAR_WIDTH + 10) / 60) - 10;
            if (shine > 0 && shine < BAR_WIDTH - 3) graphics.fill(x + shine, y, x + shine + 3, y + BAR_HEIGHT, 0x88FFFFFF);
        }
        // Подпись над полоской: ✦ 80 / 100
        Component label = Component.literal("✦ ").append(Component.translatable("hud.blightheart.mana_short",
                mana.getCurrentMana(), mana.getMaxMana()));
        graphics.drawString(mc.font, label, x, y - 11, 0xFFB9C8FF, true);
    }

    private ManaHudLayer() {}
}
