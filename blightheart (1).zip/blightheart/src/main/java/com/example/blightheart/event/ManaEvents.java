// Path: src/main/java/com/example/blightheart/event/ManaEvents.java
package com.example.blightheart.event;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.network.ModNetwork;
import com.example.blightheart.registry.ModAttachments;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** Игровые события, связанные с маной (игровая шина NeoForge). */
@EventBusSubscriber(modid = BlightheartMod.MODID)
public final class ManaEvents {

    /** Как часто восстанавливать ману (20 тиков = 1 секунда). */
    private static final int REGEN_INTERVAL_TICKS = 20;
    /** Сколько маны восстанавливается за раз. */
    private static final int REGEN_AMOUNT = 2;

    /**
     * Регенерация маны. Работает только на сервере, раз в секунду.
     * Пакет шлём лишь тогда, когда мана реально изменилась (при полной мане сеть не нагружается).
     */
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!player.isAlive() || player.tickCount % REGEN_INTERVAL_TICKS != 0) return;

        if (player.getData(ModAttachments.MANA).regenerate(REGEN_AMOUNT)) {
            ModNetwork.syncMana(player);
        }
    }

    /** При входе в мир клиент ещё не знает ману — отправляем её. */
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) ModNetwork.syncMana(player);
    }

    /** После возрождения клиент создаёт нового игрока — данные нужно прислать заново. */
    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) ModNetwork.syncMana(player);
    }

    /** При смене измерения клиентский игрок тоже пересоздаётся. */
    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) ModNetwork.syncMana(player);
    }

    private ManaEvents() {}
}
