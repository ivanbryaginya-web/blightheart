// Path: src/main/java/com/example/blightheart/block/HeartTracker.java
package com.example.blightheart.block;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Список живых Сердец в измерении (сохраняется вместе с миром).
 * Нужен массе, чтобы понять: если Сердец не осталось вовсе — пора гнить,
 * даже если кусок массы оторван от остальной и волна гниения до него не дошла.
 */
public class HeartTracker extends SavedData {

    private static final String NAME = "blightheart_hearts";

    private final LongOpenHashSet hearts = new LongOpenHashSet();

    /** У каждого измерения (Верхний мир, Незер, Энд) — свой список. */
    public static HeartTracker get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(HeartTracker::new, HeartTracker::load, null), NAME);
    }

    private static HeartTracker load(CompoundTag tag, HolderLookup.Provider registries) {
        HeartTracker tracker = new HeartTracker();
        for (long pos : tag.getLongArray("Hearts")) tracker.hearts.add(pos);
        return tracker;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putLongArray("Hearts", hearts.toLongArray());
        return tag;
    }

    public void add(BlockPos pos) {
        if (hearts.add(pos.asLong())) setDirty();
    }

    public void remove(BlockPos pos) {
        if (hearts.remove(pos.asLong())) setDirty();
    }

    public boolean hasHearts() {
        return !hearts.isEmpty();
    }

    /** Есть ли живое Сердце ближе radius блоков (Сердец в мире обычно единицы — перебор быстрый). */
    public boolean isNearHeart(BlockPos pos, int radius) {
        long maxDistSq = (long) radius * radius;
        for (long packed : hearts) {
            if (BlockPos.of(packed).distSqr(pos) <= maxDistSq) return true;
        }
        return false;
    }
}
