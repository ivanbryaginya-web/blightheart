// Path: src/main/java/com/example/blightheart/client/ClientEvents.java
package com.example.blightheart.client;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.client.model.BloaterModel;
import com.example.blightheart.client.model.HeartGuardianModel;
import com.example.blightheart.client.model.MatriarchModel;
import com.example.blightheart.client.model.SpawnlingModel;
import com.example.blightheart.client.model.SpitterModel;
import com.example.blightheart.registry.ModEntities;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/**
 * Клиентская регистрация: модели (геометрия) и рендеры мобов.
 * bus = MOD указан явно: на старых сборках NeoForge 21.1 шина не определяется автоматически,
 * и без этого регистрация молча не срабатывала бы.
 */
@SuppressWarnings("removal")
@EventBusSubscriber(modid = BlightheartMod.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class ClientEvents {

    /** Геометрия собственных моделей мобов. */
    @SubscribeEvent
    public static void onRegisterLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(SpawnlingModel.LAYER, SpawnlingModel::createBodyLayer);
        event.registerLayerDefinition(HeartGuardianModel.LAYER, HeartGuardianModel::createBodyLayer);
        event.registerLayerDefinition(SpitterModel.LAYER, SpitterModel::createBodyLayer);
        event.registerLayerDefinition(BloaterModel.LAYER, BloaterModel::createBodyLayer);
        event.registerLayerDefinition(MatriarchModel.LAYER, MatriarchModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.SPAWNLING.get(), SpawnlingRenderer::new);
        event.registerEntityRenderer(ModEntities.HEART_GUARDIAN.get(), HeartGuardianRenderer::new);
        event.registerEntityRenderer(ModEntities.SPITTER.get(), SpitterRenderer::new);
        event.registerEntityRenderer(ModEntities.BLOATER.get(), BloaterRenderer::new);
        event.registerEntityRenderer(ModEntities.BLIGHT_MATRIARCH.get(), MatriarchRenderer::new);
    }

    private ClientEvents() {}
}
