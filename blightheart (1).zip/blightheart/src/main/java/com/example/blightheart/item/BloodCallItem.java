// Path: src/main/java/com/example/blightheart/item/BloodCallItem.java
package com.example.blightheart.item;

import com.example.blightheart.dimension.ModDimensions;
import com.example.blightheart.entity.BlightMatriarchEntity;
import com.example.blightheart.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Кровавый Зов — рог из плоти. Протруби в Заражённом мире, и в 6 блоках перед тобой
 * из земли поднимется Матка Заражения.
 */
public class BloodCallItem extends Item {

    public BloodCallItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(level instanceof ServerLevel server)) return InteractionResultHolder.success(stack);

        // Матка откликается только в своём мире
        if (!ModDimensions.isInfectedWorld(level)) {
            player.displayClientMessage(Component.translatable("message.blightheart.blood_call_wrong_world")
                    .withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(stack);
        }

        BlightMatriarchEntity boss = ModEntities.BLIGHT_MATRIARCH.get().create(server);
        if (boss == null) return InteractionResultHolder.fail(stack);

        Vec3 look = player.getLookAngle().multiply(1.0D, 0.0D, 1.0D).normalize();
        Vec3 spot = player.position().add(look.scale(6.0D));
        boss.moveTo(spot.x, player.getY(), spot.z, player.getYRot() + 180.0F, 0.0F);
        boss.setTarget(player);
        server.addFreshEntity(boss);

        server.sendParticles(ParticleTypes.SCULK_SOUL, spot.x, player.getY() + 1.0D, spot.z, 80, 1.5D, 2.0D, 1.5D, 0.05D);
        server.playSound(null, player.blockPosition(), SoundEvents.RAVAGER_ROAR,
                SoundSource.PLAYERS, 2.0F, 0.5F);
        server.playSound(null, boss.blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 1.5F, 0.6F);

        if (!player.getAbilities().instabuild) stack.shrink(1);
        player.getCooldowns().addCooldown(this, 100);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.blightheart.blood_call").withStyle(ChatFormatting.DARK_RED));
    }
}
