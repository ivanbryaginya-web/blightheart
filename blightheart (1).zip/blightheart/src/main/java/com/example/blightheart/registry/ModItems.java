// Path: src/main/java/com/example/blightheart/registry/ModItems.java
package com.example.blightheart.registry;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.dimension.HeartShardItem;
import com.example.blightheart.magic.SpellWandItem;
import com.example.blightheart.magic.ManaEssenceItem;
import com.example.blightheart.item.BloodCallItem;
import com.example.blightheart.item.HealingResinItem;
import com.example.blightheart.item.PurifyingBladeItem;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.core.Holder;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Регистрация предметов. */
public final class ModItems {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(BlightheartMod.MODID);

    public static final DeferredItem<BlockItem> INFECTION_HEART = ITEMS.register("infection_heart",
            () -> new BlockItem(ModBlocks.INFECTION_HEART.get(), new Item.Properties().rarity(Rarity.EPIC)));

    public static final DeferredItem<BlockItem> INFECTION_MASS = ITEMS.registerSimpleBlockItem(ModBlocks.INFECTION_MASS);

    public static final DeferredItem<BlockItem> DOME_MEMBRANE = ITEMS.registerSimpleBlockItem(ModBlocks.DOME_MEMBRANE);

    /** Яйцо призыва Порождения (тёмно-красное с алыми пятнами). */
    public static final DeferredItem<DeferredSpawnEggItem> SPAWNLING_SPAWN_EGG = ITEMS.register("spawnling_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.SPAWNLING, 0x3A0A0F, 0xD4203A, new Item.Properties()));

    /** Яйцо призыва Стража Сердца (почти чёрное с жёлтыми пятнами — как его глаза). */
    public static final DeferredItem<DeferredSpawnEggItem> HEART_GUARDIAN_SPAWN_EGG = ITEMS.register("heart_guardian_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.HEART_GUARDIAN, 0x1E0508, 0xF2C230, new Item.Properties()));

    public static final DeferredItem<BlockItem> PETRIFIED_FLESH = ITEMS.registerSimpleBlockItem(ModBlocks.PETRIFIED_FLESH);
    public static final DeferredItem<BlockItem> BLOODBLOOM = ITEMS.registerSimpleBlockItem(ModBlocks.BLOODBLOOM);
    public static final DeferredItem<BlockItem> EYESTALK = ITEMS.registerSimpleBlockItem(ModBlocks.EYESTALK);
    public static final DeferredItem<BlockItem> PUSTULE = ITEMS.registerSimpleBlockItem(ModBlocks.PUSTULE);
    public static final DeferredItem<BlockItem> ROT_LEAVES = ITEMS.registerSimpleBlockItem(ModBlocks.ROT_LEAVES);
    public static final DeferredItem<BlockItem> SANGUINITE_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.SANGUINITE_ORE);
    public static final DeferredItem<BlockItem> MANA_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.MANA_ORE);
    public static final DeferredItem<BlockItem> DEEPSLATE_MANA_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.DEEPSLATE_MANA_ORE);
    public static final DeferredItem<BlockItem> SANGUINITE_BLOCK = ITEMS.registerSimpleBlockItem(ModBlocks.SANGUINITE_BLOCK);

    /** Сангвинит — алый кристалл из руды Заражённого мира. */
    public static final DeferredItem<Item> SANGUINITE = ITEMS.register("sanguinite",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));

    /** Эссенция маны — ПКМ восстанавливает 40 маны. */
    public static final DeferredItem<ManaEssenceItem> MANA_ESSENCE = ITEMS.register("mana_essence",
            () -> new ManaEssenceItem(new Item.Properties().rarity(Rarity.UNCOMMON)));

    // ---- Природа Заражения ----
    public static final DeferredItem<BlockItem> INFECTED_GRASS_BLOCK = ITEMS.registerSimpleBlockItem(ModBlocks.INFECTED_GRASS_BLOCK);
    public static final DeferredItem<BlockItem> BLIGHTED_GRASS = ITEMS.registerSimpleBlockItem(ModBlocks.BLIGHTED_GRASS);
    public static final DeferredItem<BlockItem> ROTBLOOM = ITEMS.registerSimpleBlockItem(ModBlocks.ROTBLOOM);
    public static final DeferredItem<BlockItem> PULSING_GROWTH = ITEMS.registerSimpleBlockItem(ModBlocks.PULSING_GROWTH);
    public static final DeferredItem<BlockItem> ROTWOOD_LOG = ITEMS.registerSimpleBlockItem(ModBlocks.ROTWOOD_LOG);
    public static final DeferredItem<BlockItem> ROTWOOD_PLANKS = ITEMS.registerSimpleBlockItem(ModBlocks.ROTWOOD_PLANKS);

    /** Осколок Сердца — ключ к Заражённому миру. */
    public static final DeferredItem<HeartShardItem> HEART_SHARD = ITEMS.register("heart_shard",
            () -> new HeartShardItem(new Item.Properties().rarity(Rarity.RARE)));

    // ---- Магия (бывший Mysticor) ----

    /** Обычная палочка: 250 использований, стандартная сила и стоимость. */
    public static final DeferredItem<SpellWandItem> BASE_WAND = ITEMS.register("base_wand",
            () -> new SpellWandItem(new Item.Properties().durability(250).rarity(Rarity.UNCOMMON),
                    1.0F, 1.0F, false));

    /** Посох Архимага: 1000 использований, сила ×1.5, заклинания на 25% дешевле, светится. */
    public static final DeferredItem<SpellWandItem> ARCHMAGE_WAND = ITEMS.register("archmage_wand",
            () -> new SpellWandItem(new Item.Properties().durability(1000).rarity(Rarity.EPIC).fireResistant(),
                    1.5F, 0.75F, true));

    /** Посох Матки: 2000 использований, сила ×2, заклинания вдвое дешевле. Крафтится из Ядра Матки. */
    public static final DeferredItem<SpellWandItem> MATRIARCH_STAFF = ITEMS.register("matriarch_staff",
            () -> new SpellWandItem(new Item.Properties().durability(2000).rarity(Rarity.EPIC).fireResistant(),
                    2.0F, 0.5F, true));

    // ---- Оружие, еда и трофеи ----

    /** Клинок Очищения: алмазный меч, +6 урона и поджог против существ Заражения. */
    public static final DeferredItem<PurifyingBladeItem> PURIFYING_BLADE = ITEMS.register("purifying_blade",
            () -> new PurifyingBladeItem(Tiers.DIAMOND, new Item.Properties().rarity(Rarity.RARE)
                    .attributes(SwordItem.createAttributes(Tiers.DIAMOND, 3, -2.4F))));

    /** Целебная смола: еда, снимающая иссушение и отравление. Падает с Плевунов. */
    public static final DeferredItem<HealingResinItem> HEALING_RESIN = ITEMS.register("healing_resin",
            () -> new HealingResinItem(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(4).saturationModifier(0.6F).alwaysEdible().build())));

    /** Кровавый Зов: призывает босса в Заражённом мире. */
    public static final DeferredItem<BloodCallItem> BLOOD_CALL = ITEMS.register("blood_call",
            () -> new BloodCallItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    /** Ядро Матки: главный трофей с босса. */
    public static final DeferredItem<Item> MATRIARCH_CORE = ITEMS.register("matriarch_core",
            () -> new Item(new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    // ---- Яйца призыва новых мобов ----
    public static final DeferredItem<DeferredSpawnEggItem> SPITTER_SPAWN_EGG = ITEMS.register("spitter_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.SPITTER, 0x4A0E16, 0x7FBF3F, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> BLOATER_SPAWN_EGG = ITEMS.register("bloater_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.BLOATER, 0x8C2A3A, 0xE8C25A, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> BLIGHT_MATRIARCH_SPAWN_EGG = ITEMS.register("blight_matriarch_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.BLIGHT_MATRIARCH, 0x12020A, 0xFF2040, new Item.Properties()));

    // ---- Материалы для брони ----

    /** Хитиновая пластина: падает со Стражей Сердца (и иногда с Порождений). */
    public static final DeferredItem<Item> CHITIN_PLATE = ITEMS.register("chitin_plate",
            () -> new Item(new Item.Properties()));

    /** Чешуя Матки: падает с босса. */
    public static final DeferredItem<Item> MATRIARCH_SCALE = ITEMS.register("matriarch_scale",
            () -> new Item(new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    // ---- Хитиновая броня (прочность ×20, как у алмаза ×33 — чуть выше железа ×15) ----
    public static final DeferredItem<ArmorItem> CHITIN_HELMET = armor("chitin_helmet", ModArmorMaterials.CHITIN, ArmorItem.Type.HELMET, 20, false);
    public static final DeferredItem<ArmorItem> CHITIN_CHESTPLATE = armor("chitin_chestplate", ModArmorMaterials.CHITIN, ArmorItem.Type.CHESTPLATE, 20, false);
    public static final DeferredItem<ArmorItem> CHITIN_LEGGINGS = armor("chitin_leggings", ModArmorMaterials.CHITIN, ArmorItem.Type.LEGGINGS, 20, false);
    public static final DeferredItem<ArmorItem> CHITIN_BOOTS = armor("chitin_boots", ModArmorMaterials.CHITIN, ArmorItem.Type.BOOTS, 20, false);

    // ---- Броня Матки (прочность ×37, как у незерита) ----
    public static final DeferredItem<ArmorItem> MATRIARCH_HELMET = armor("matriarch_helmet", ModArmorMaterials.MATRIARCH, ArmorItem.Type.HELMET, 37, true);
    public static final DeferredItem<ArmorItem> MATRIARCH_CHESTPLATE = armor("matriarch_chestplate", ModArmorMaterials.MATRIARCH, ArmorItem.Type.CHESTPLATE, 37, true);
    public static final DeferredItem<ArmorItem> MATRIARCH_LEGGINGS = armor("matriarch_leggings", ModArmorMaterials.MATRIARCH, ArmorItem.Type.LEGGINGS, 37, true);
    public static final DeferredItem<ArmorItem> MATRIARCH_BOOTS = armor("matriarch_boots", ModArmorMaterials.MATRIARCH, ArmorItem.Type.BOOTS, 37, true);

    private static DeferredItem<ArmorItem> armor(String name, Holder<ArmorMaterial> material, ArmorItem.Type type,
                                                 int durabilityFactor, boolean epic) {
        return ITEMS.register(name, () -> new ArmorItem(material, type, new Item.Properties()
                .durability(type.getDurability(durabilityFactor))
                .rarity(epic ? Rarity.EPIC : Rarity.UNCOMMON)));
    }

    private ModItems() {}
}
