// Path: src/main/java/com/example/blightheart/client/model/BloaterModel.java
package com.example.blightheart.client.model;

import com.example.blightheart.BlightheartMod;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/**
 * Гнойник: круглый раздутый мешок с гнойниками на четырёх коротких ножках.
 * Собственная модель (сгенерирована вместе с текстурой — развёртка UV совпадает).
 */
public class BloaterModel<T extends Entity> extends HierarchicalModel<T> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(BlightheartMod.id("bloater"), "main");

    private static final float DEG = (float) (Math.PI / 180.0);
    private static final float PI = (float) Math.PI;

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart leg_fr;
    private final ModelPart leg_fl;
    private final ModelPart leg_br;
    private final ModelPart leg_bl;

    public BloaterModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.leg_fr = root.getChild("leg_fr");
        this.leg_fl = root.getChild("leg_fl");
        this.leg_br = root.getChild("leg_br");
        this.leg_bl = root.getChild("leg_bl");
    }

    /** Геометрия: кубы, их положение и развёртка на текстуре 64×64. */
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -12.0F, -6.0F, 12.0F, 12.0F, 12.0F).texOffs(48, 0).addBox(-7.0F, -9.0F, -2.0F, 1.0F, 3.0F, 3.0F).texOffs(48, 0).mirror().addBox(6.0F, -7.0F, 1.0F, 1.0F, 3.0F, 3.0F).mirror(false).texOffs(48, 8).addBox(-2.0F, -13.0F, -3.0F, 4.0F, 1.0F, 4.0F),
                PartPose.offset(0.0F, 20.0F, 0.0F));
        root.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(0, 24).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F),
                PartPose.offset(-3.5F, 20.0F, -3.5F));
        root.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(0, 24).mirror().addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F).mirror(false),
                PartPose.offset(3.5F, 20.0F, -3.5F));
        root.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(0, 24).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F),
                PartPose.offset(-3.5F, 20.0F, 3.5F));
        root.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(0, 24).mirror().addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F).mirror(false),
                PartPose.offset(3.5F, 20.0F, 3.5F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public ModelPart root() {
        return root;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);   // вернуть исходную позу перед анимацией
        // Короткие ножки семенят, раздутое тело колышется
        float s = limbSwing * 1.2F;
        leg_fr.xRot = Mth.cos(s) * 1.0F * limbSwingAmount;
        leg_bl.xRot = Mth.cos(s) * 1.0F * limbSwingAmount;
        leg_fl.xRot = Mth.cos(s + PI) * 1.0F * limbSwingAmount;
        leg_br.xRot = Mth.cos(s + PI) * 1.0F * limbSwingAmount;
        float breathe = Mth.sin(ageInTicks * 0.1F) * 0.04F;
        body.xScale = 1.0F + breathe;
        body.zScale = 1.0F + breathe;
        body.yScale = 1.0F - breathe * 0.5F;
        body.zRot = Mth.sin(limbSwing * 0.6F) * 0.08F * limbSwingAmount;
    }
}
