// Path: src/main/java/com/example/blightheart/client/model/HeartGuardianModel.java
package com.example.blightheart.client.model;

import com.example.blightheart.BlightheartMod;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/**
 * Страж Сердца: сгорбленный великан с горбом и длинными руками до земли.
 * Собственная модель (сгенерирована вместе с текстурой — развёртка UV совпадает).
 */
public class HeartGuardianModel<T extends Entity> extends HierarchicalModel<T> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(BlightheartMod.id("heart_guardian"), "main");

    private static final float DEG = (float) (Math.PI / 180.0);
    private static final float PI = (float) Math.PI;

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart arm_r;
    private final ModelPart arm_l;
    private final ModelPart leg_r;
    private final ModelPart leg_l;

    public HeartGuardianModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.arm_r = root.getChild("arm_r");
        this.arm_l = root.getChild("arm_l");
        this.leg_r = root.getChild("leg_r");
        this.leg_l = root.getChild("leg_l");
    }

    /** Геометрия: кубы, их положение и развёртка на текстуре 128×64. */
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-7.0F, -12.0F, -4.5F, 14.0F, 12.0F, 9.0F).texOffs(48, 0).addBox(-4.0F, -15.0F, -1.0F, 8.0F, 4.0F, 6.0F),
                PartPose.offsetAndRotation(0.0F, 14.0F, 0.0F, 0.2F, 0.0F, 0.0F));
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 22).addBox(-4.0F, -6.0F, -6.0F, 8.0F, 7.0F, 7.0F),
                PartPose.offset(0.0F, 3.0F, -4.0F));
        root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(32, 22).addBox(-5.0F, -2.0F, -3.0F, 6.0F, 18.0F, 6.0F),
                PartPose.offset(-8.0F, 4.0F, 0.0F));
        root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(32, 22).mirror().addBox(-1.0F, -2.0F, -3.0F, 6.0F, 18.0F, 6.0F).mirror(false),
                PartPose.offset(8.0F, 4.0F, 0.0F));
        root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(60, 22).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 10.0F, 5.0F),
                PartPose.offset(-3.5F, 14.0F, 0.0F));
        root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(60, 22).mirror().addBox(-2.5F, 0.0F, -2.5F, 5.0F, 10.0F, 5.0F).mirror(false),
                PartPose.offset(3.5F, 14.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    @Override
    public ModelPart root() {
        return root;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);   // вернуть исходную позу перед анимацией
        // Тяжёлая походка, длинные руки раскачиваются; при ударе руки взмывают вверх
        head.yRot = netHeadYaw * DEG;
        head.xRot = headPitch * DEG;
        float s = limbSwing * 0.6662F;
        leg_r.xRot = Mth.cos(s) * 1.2F * limbSwingAmount;
        leg_l.xRot = Mth.cos(s + PI) * 1.2F * limbSwingAmount;
        arm_r.xRot = Mth.cos(s + PI) * 0.8F * limbSwingAmount;
        arm_l.xRot = Mth.cos(s) * 0.8F * limbSwingAmount;
        arm_r.zRot = 0.1F + Mth.sin(ageInTicks * 0.067F) * 0.05F;
        arm_l.zRot = -0.1F - Mth.sin(ageInTicks * 0.067F) * 0.05F;
        if (attackTime > 0.0F) {
            float swing = Mth.sin(attackTime * PI);
            arm_r.xRot -= swing * 2.2F;
            arm_l.xRot -= swing * 2.2F;
        }
    }
}
