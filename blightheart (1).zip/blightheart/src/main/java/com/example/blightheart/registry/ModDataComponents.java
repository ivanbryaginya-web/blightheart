// Path: src/main/java/com/example/blightheart/registry/ModDataComponents.java
package com.example.blightheart.registry;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.magic.SpellType;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Компоненты данных предметов (Data Components) — замена NBT-тегов предметов в 1.20.5+. */
public final class ModDataComponents {

    public static final DeferredRegister<DataComponentType<?>> DATA_COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, BlightheartMod.MODID);

    /**
     * Выбранное в палочке заклинание.
     * persistent — сохранять в мире; networkSynchronized — передавать клиенту
     * (нужно, чтобы подсказка к предмету показывала актуальное заклинание).
     */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<SpellType>> SELECTED_SPELL =
            DATA_COMPONENTS.register("selected_spell", () -> DataComponentType.<SpellType>builder()
                    .persistent(SpellType.CODEC)
                    .networkSynchronized(SpellType.STREAM_CODEC)
                    .build());

    private ModDataComponents() {}
}
