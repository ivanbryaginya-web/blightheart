// Path: src/main/java/com/example/blightheart/magic/SpellWandItem.java
package com.example.blightheart.magic;

import com.example.blightheart.magic.ManaData;
import com.example.blightheart.network.ModNetwork;
import com.example.blightheart.registry.ModAttachments;
import com.example.blightheart.registry.ModDataComponents;
import com.example.blightheart.magic.SpellCaster;
import com.example.blightheart.magic.SpellType;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * Магическая палочка.
 * ПКМ — сотворить выбранное заклинание. Shift + ПКМ — выбрать следующее заклинание.
 */
public class SpellWandItem extends Item {

    /** Перезарядка между заклинаниями в тиках (0.5 сек). */
    private static final int COOLDOWN_TICKS = 10;

    private final float powerMultiplier;
    private final float costMultiplier;
    private final boolean glowing;

    /**
     * @param powerMultiplier множитель силы заклинаний (урон, лечение, высота прыжка)
     * @param costMultiplier  множитель стоимости в мане (0.75 = на 25% дешевле)
     * @param glowing         рисовать ли эффект зачарования
     */
    public SpellWandItem(Properties properties, float powerMultiplier, float costMultiplier, boolean glowing) {
        super(properties);
        this.powerMultiplier = powerMultiplier;
        this.costMultiplier = costMultiplier;
        this.glowing = glowing;
    }

    /** Заклинание из Data Component палочки. Если компонента ещё нет — Огненный шар по умолчанию. */
    public static SpellType getSelectedSpell(ItemStack stack) {
        return stack.getOrDefault(ModDataComponents.SELECTED_SPELL.get(), SpellType.FIREBALL);
    }

    /** Итоговая стоимость заклинания с учётом бонуса палочки (минимум 1). */
    public int getManaCost(SpellType spell) {
        return Math.max(1, Mth.ceil(spell.getManaCost() * costMultiplier));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // ---------- Shift + ПКМ: смена заклинания ----------
        if (player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                // Берём текущее заклинание и переходим к следующему по кругу
                SpellType next = getSelectedSpell(stack).next();
                // Записываем новое значение в Data Component — оно сохранится в предмете
                stack.set(ModDataComponents.SELECTED_SPELL.get(), next);

                player.displayClientMessage(
                        Component.translatable("message.blightheart.spell_selected", next.getDisplayName()), false);
                level.playSound(null, player.blockPosition(), SoundEvents.UI_BUTTON_CLICK.value(),
                        SoundSource.PLAYERS, 0.5F, 1.5F);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        // ---------- ПКМ: сотворение заклинания ----------
        // Вся логика — на сервере. Клиент только проигрывает анимацию взмаха.
        if (level.isClientSide || !(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResultHolder.success(stack);
        }

        SpellType spell = getSelectedSpell(stack);
        int cost = getManaCost(spell);
        ManaData mana = serverPlayer.getData(ModAttachments.MANA);
        boolean creative = serverPlayer.getAbilities().instabuild;

        // Проверка маны ДО каста: если маны не хватает, заклинание не срабатывает вовсе.
        // В творческом режиме мана не нужна.
        if (!creative && !mana.hasEnough(cost)) {
            serverPlayer.displayClientMessage(Component.translatable("message.blightheart.not_enough_mana",
                    cost, mana.getCurrentMana()).withStyle(ChatFormatting.RED), false);
            level.playSound(null, player.blockPosition(), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.5F, 1.5F);
            return InteractionResultHolder.fail(stack);
        }

        // Само заклинание. Если оно не сработало (например, лечение при полном здоровье) — мана не списывается.
        if (!SpellCaster.cast(spell, (ServerLevel) level, serverPlayer, powerMultiplier)) {
            return InteractionResultHolder.fail(stack);
        }

        // Списываем ману только после успешного каста и сразу сообщаем клиенту новое значение
        if (!creative) {
            mana.consume(cost);
            ModNetwork.syncMana(serverPlayer);
        }

        serverPlayer.displayClientMessage(Component.translatable("message.blightheart.spell_cast",
                spell.getDisplayName(), mana.getCurrentMana(), mana.getMaxMana()), false);

        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        // Тратим 1 единицу прочности (в творческом режиме прочность не тратится автоматически)
        stack.hurtAndBreak(1, serverPlayer, LivingEntity.getSlotForHand(hand));

        return InteractionResultHolder.consume(stack);
    }

    /** Подсказка: выбранное заклинание, его стоимость и управление. */
    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        SpellType spell = getSelectedSpell(stack);
        tooltip.add(Component.translatable("tooltip.blightheart.selected_spell", spell.getDisplayName())
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.blightheart.mana_cost", getManaCost(spell))
                .withStyle(ChatFormatting.BLUE));
        tooltip.add(Component.translatable("tooltip.blightheart.controls").withStyle(ChatFormatting.DARK_GRAY));
    }

    /** Блеск зачарования для продвинутой палочки. */
    @Override
    public boolean isFoil(ItemStack stack) {
        return glowing || super.isFoil(stack);
    }
}
