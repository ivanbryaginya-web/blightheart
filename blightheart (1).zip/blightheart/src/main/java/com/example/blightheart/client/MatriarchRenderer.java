// Path: src/main/java/com/example/blightheart/client/MatriarchRenderer.java
package com.example.blightheart.client;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.client.model.MatriarchModel;
import com.example.blightheart.entity.BlightMatriarchEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Рендер на собственной модели + светящийся слой (глаза и т.п.). */
public class MatriarchRenderer extends MobRenderer<BlightMatriarchEntity, MatriarchModel<BlightMatriarchEntity>> {

    private static final ResourceLocation TEXTURE = BlightheartMod.id("textures/entity/blight_matriarch.png");
    private static final ResourceLocation GLOW = BlightheartMod.id("textures/entity/blight_matriarch_glow.png");

    public MatriarchRenderer(EntityRendererProvider.Context context) {
        super(context, new MatriarchModel<>(context.bakeLayer(MatriarchModel.LAYER)), 2.0F);
        this.addLayer(new GlowLayer<>(this, GLOW));
    }

    @Override
    public ResourceLocation getTextureLocation(BlightMatriarchEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(BlightMatriarchEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.55F, 1.55F, 1.55F);
    }
}
