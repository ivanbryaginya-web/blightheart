// Path: src/main/java/com/example/blightheart/client/MatriarchRenderer.java
package com.example.blightheart.client;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.entity.BlightMatriarchEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Матка Заражения: гуманоидная модель, увеличенная в 2,2 раза. */
public class MatriarchRenderer extends HumanoidMobRenderer<BlightMatriarchEntity, HumanoidModel<BlightMatriarchEntity>> {

    private static final ResourceLocation TEXTURE = BlightheartMod.id("textures/entity/blight_matriarch.png");

    public MatriarchRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 1.8F);
    }

    @Override
    public ResourceLocation getTextureLocation(BlightMatriarchEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(BlightMatriarchEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(2.2F, 2.2F, 2.2F);
    }
}
