// Path: src/main/java/com/example/blightheart/client/model/SpawnlingModel.java
package com.example.blightheart.client.model;

import com.example.blightheart.BlightheartMod;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/**
 * Порождение: приземистое тело, голова-глаз и шесть паучьих лап.
 * Собственная модель (сгенерирована вместе с текстурой — развёртка UV совпадает).
 */
public class SpawnlingModel<T extends Entity> extends HierarchicalModel<T> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(BlightheartMod.id("spawnling"), "main");

    private static final float DEG = (float) (Math.PI / 180.0);
    private static final float PI = (float) Math.PI;

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leg_r1;
    private final ModelPart leg_r2;
    private final ModelPart leg_r3;
    private final ModelPart leg_l1;
    private final ModelPart leg_l2;
    private final ModelPart leg_l3;

    public SpawnlingModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.leg_r1 = root.getChild("leg_r1");
        this.leg_r2 = root.getChild("leg_r2");
        this.leg_r3 = root.getChild("leg_r3");
        this.leg_l1 = root.getChild("leg_l1");
        this.leg_l2 = root.getChild("leg_l2");
        this.leg_l3 = root.getChild("leg_l3");
    }

    /** Геометрия: кубы, их положение и развёртка на текстуре 64×32. */
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -3.0F, -5.0F, 8.0F, 5.0F, 10.0F),
                PartPose.offset(0.0F, 19.0F, 0.0F));
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, -3.0F, -4.0F, 6.0F, 6.0F, 4.0F),
                PartPose.offset(0.0F, 18.0F, -5.0F));
        root.addOrReplaceChild("leg_r1", CubeListBuilder.create().texOffs(24, 16).addBox(-9.0F, -1.0F, -1.0F, 9.0F, 2.0F, 2.0F),
                PartPose.offsetAndRotation(-4.0F, 19.0F, -3.0F, 0.0F, 0.5F, 0.7F));
        root.addOrReplaceChild("leg_r2", CubeListBuilder.create().texOffs(24, 16).addBox(-9.0F, -1.0F, -1.0F, 9.0F, 2.0F, 2.0F),
                PartPose.offsetAndRotation(-4.0F, 19.0F, 0.0F, 0.0F, 0.0F, 0.7F));
        root.addOrReplaceChild("leg_r3", CubeListBuilder.create().texOffs(24, 16).addBox(-9.0F, -1.0F, -1.0F, 9.0F, 2.0F, 2.0F),
                PartPose.offsetAndRotation(-4.0F, 19.0F, 3.0F, 0.0F, -0.5F, 0.7F));
        root.addOrReplaceChild("leg_l1", CubeListBuilder.create().texOffs(24, 16).mirror().addBox(0.0F, -1.0F, -1.0F, 9.0F, 2.0F, 2.0F).mirror(false),
                PartPose.offsetAndRotation(4.0F, 19.0F, -3.0F, 0.0F, -0.5F, -0.7F));
        root.addOrReplaceChild("leg_l2", CubeListBuilder.create().texOffs(24, 16).mirror().addBox(0.0F, -1.0F, -1.0F, 9.0F, 2.0F, 2.0F).mirror(false),
                PartPose.offsetAndRotation(4.0F, 19.0F, 0.0F, 0.0F, 0.0F, -0.7F));
        root.addOrReplaceChild("leg_l3", CubeListBuilder.create().texOffs(24, 16).mirror().addBox(0.0F, -1.0F, -1.0F, 9.0F, 2.0F, 2.0F).mirror(false),
                PartPose.offsetAndRotation(4.0F, 19.0F, 3.0F, 0.0F, 0.5F, -0.7F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public ModelPart root() {
        return root;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);   // вернуть исходную позу перед анимацией
        // Шесть лап перебирают, как у паука; голова следит за целью
        head.yRot = netHeadYaw * DEG;
        head.xRot = headPitch * DEG;
        float s = limbSwing * 1.6F;
        float a = limbSwingAmount;
        leg_r1.yRot += Mth.sin(s) * 0.4F * a;            leg_l1.yRot -= Mth.sin(s) * 0.4F * a;
        leg_r2.yRot += Mth.sin(s + PI / 2) * 0.4F * a;   leg_l2.yRot -= Mth.sin(s + PI / 2) * 0.4F * a;
        leg_r3.yRot += Mth.sin(s + PI) * 0.4F * a;       leg_l3.yRot -= Mth.sin(s + PI) * 0.4F * a;
        leg_r1.zRot += Math.abs(Mth.cos(s)) * 0.4F * a;  leg_l1.zRot -= Math.abs(Mth.cos(s)) * 0.4F * a;
        leg_r2.zRot += Math.abs(Mth.cos(s + PI / 2)) * 0.4F * a; leg_l2.zRot -= Math.abs(Mth.cos(s + PI / 2)) * 0.4F * a;
        leg_r3.zRot += Math.abs(Mth.cos(s + PI)) * 0.4F * a;     leg_l3.zRot -= Math.abs(Mth.cos(s + PI)) * 0.4F * a;
        body.yScale = 1.0F + Mth.sin(ageInTicks * 0.2F) * 0.04F;   // дышит
    }
}
