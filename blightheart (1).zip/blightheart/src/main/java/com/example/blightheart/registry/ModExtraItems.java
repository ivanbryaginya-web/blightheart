// Path: src/main/java/com/example/blightheart/registry/ModExtraItems.java
package com.example.blightheart.registry;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.item.AmuletItem;
import com.example.blightheart.item.ManaFlaskItem;
import com.example.blightheart.item.ManaFoodItem;
import com.example.blightheart.item.ModTiers;
import com.example.blightheart.item.SpellScrollItem;
import com.example.blightheart.magic.SpellType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Дополнительные предметы: свитки всех заклинаний, флаконы маны, амулеты,
 * хитиновые инструменты, еда из Заражённого мира.
 */
public final class ModExtraItems {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(BlightheartMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BlightheartMod.MODID);

    public static final DeferredItem<SpellScrollItem> SCROLL_FIREBALL = ITEMS.register("scroll_fireball",
            () -> new SpellScrollItem(SpellType.FIREBALL, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_HEAL = ITEMS.register("scroll_heal",
            () -> new SpellScrollItem(SpellType.HEAL, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_LEVITATION = ITEMS.register("scroll_levitation",
            () -> new SpellScrollItem(SpellType.LEVITATION, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_PURIFY = ITEMS.register("scroll_purify",
            () -> new SpellScrollItem(SpellType.PURIFY, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_LIGHTNING = ITEMS.register("scroll_lightning",
            () -> new SpellScrollItem(SpellType.LIGHTNING, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_FROST_NOVA = ITEMS.register("scroll_frost_nova",
            () -> new SpellScrollItem(SpellType.FROST_NOVA, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_BLINK = ITEMS.register("scroll_blink",
            () -> new SpellScrollItem(SpellType.BLINK, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_WARD = ITEMS.register("scroll_ward",
            () -> new SpellScrollItem(SpellType.WARD, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_METEOR = ITEMS.register("scroll_meteor",
            () -> new SpellScrollItem(SpellType.METEOR, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_LIFE_DRAIN = ITEMS.register("scroll_life_drain",
            () -> new SpellScrollItem(SpellType.LIFE_DRAIN, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_REPULSE = ITEMS.register("scroll_repulse",
            () -> new SpellScrollItem(SpellType.REPULSE, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<SpellScrollItem> SCROLL_REVEAL = ITEMS.register("scroll_reveal",
            () -> new SpellScrollItem(SpellType.REVEAL, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<ManaFlaskItem> MANA_FLASK = ITEMS.register("mana_flask",
            () -> new ManaFlaskItem(50, new Item.Properties().stacksTo(16)));
    public static final DeferredItem<ManaFlaskItem> GREATER_MANA_FLASK = ITEMS.register("greater_mana_flask",
            () -> new ManaFlaskItem(150, new Item.Properties().stacksTo(16).rarity(Rarity.RARE)));
    public static final DeferredItem<AmuletItem> AMULET_REGENERATION = ITEMS.register("amulet_regeneration",
            () -> new AmuletItem(MobEffects.REGENERATION, 0, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final DeferredItem<AmuletItem> AMULET_SWIFTNESS = ITEMS.register("amulet_swiftness",
            () -> new AmuletItem(MobEffects.MOVEMENT_SPEED, 0, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final DeferredItem<AmuletItem> AMULET_NIGHT_VISION = ITEMS.register("amulet_night_vision",
            () -> new AmuletItem(MobEffects.NIGHT_VISION, 0, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final DeferredItem<AmuletItem> AMULET_FIRE_RESISTANCE = ITEMS.register("amulet_fire_resistance",
            () -> new AmuletItem(MobEffects.FIRE_RESISTANCE, 0, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final DeferredItem<AmuletItem> AMULET_STRENGTH = ITEMS.register("amulet_strength",
            () -> new AmuletItem(MobEffects.DAMAGE_BOOST, 0, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final DeferredItem<SwordItem> CHITIN_SWORD = ITEMS.register("chitin_sword",
            () -> new SwordItem(ModTiers.CHITIN, new Item.Properties().attributes(SwordItem.createAttributes(ModTiers.CHITIN, 3, -2.4F))));
    public static final DeferredItem<PickaxeItem> CHITIN_PICKAXE = ITEMS.register("chitin_pickaxe",
            () -> new PickaxeItem(ModTiers.CHITIN, new Item.Properties().attributes(DiggerItem.createAttributes(ModTiers.CHITIN, 1.0F, -2.8F))));
    public static final DeferredItem<AxeItem> CHITIN_AXE = ITEMS.register("chitin_axe",
            () -> new AxeItem(ModTiers.CHITIN, new Item.Properties().attributes(DiggerItem.createAttributes(ModTiers.CHITIN, 6.0F, -3.1F))));
    public static final DeferredItem<ShovelItem> CHITIN_SHOVEL = ITEMS.register("chitin_shovel",
            () -> new ShovelItem(ModTiers.CHITIN, new Item.Properties().attributes(DiggerItem.createAttributes(ModTiers.CHITIN, 1.5F, -3.0F))));
    public static final DeferredItem<HoeItem> CHITIN_HOE = ITEMS.register("chitin_hoe",
            () -> new HoeItem(ModTiers.CHITIN, new Item.Properties().attributes(DiggerItem.createAttributes(ModTiers.CHITIN, -2.0F, -1.0F))));
    public static final DeferredItem<HoeItem> SANGUINITE_HOE = ITEMS.register("sanguinite_hoe",
            () -> new HoeItem(ModTiers.SANGUINITE, new Item.Properties().attributes(DiggerItem.createAttributes(ModTiers.SANGUINITE, -3.0F, 0.0F))));
    public static final DeferredItem<Item> FLESH_CHUNK = ITEMS.register("flesh_chunk",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).effect(new MobEffectInstance(MobEffects.HUNGER, 300, 0), 0.3F).build())));
    public static final DeferredItem<Item> COOKED_FLESH_CHUNK = ITEMS.register("cooked_flesh_chunk",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(7).saturationModifier(0.8F).build())));
    public static final DeferredItem<Item> BLOOD_BERRIES = ITEMS.register("blood_berries",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.2F).fast().build())));
    public static final DeferredItem<Item> BLIGHT_STEW = ITEMS.register("blight_stew",
            () -> new Item(new Item.Properties().stacksTo(1).food(new FoodProperties.Builder().nutrition(8).saturationModifier(0.6F).effect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0), 1.0F).usingConvertsTo(Items.BOWL).build())));
    public static final DeferredItem<ManaFoodItem> MANA_BREAD = ITEMS.register("mana_bread",
            () -> new ManaFoodItem(15, new Item.Properties().food(new FoodProperties.Builder().nutrition(5).saturationModifier(0.6F).build())));
    public static final DeferredItem<Item> RESIN_CANDY = ITEMS.register("resin_candy",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.3F).fast().alwaysEdible().effect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 0), 1.0F).build())));
    public static final DeferredItem<Item> PURIFIED_APPLE = ITEMS.register("purified_apple",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationModifier(1.2F).alwaysEdible().effect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1), 1.0F).effect(new MobEffectInstance(MobEffects.ABSORPTION, 2400, 0), 1.0F).build())));
    public static final DeferredItem<Item> PUS_GLOB = ITEMS.register("pus_glob",
            () -> new Item(new Item.Properties()));

    /** Вкладка "Магия и снаряжение". */
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("gear",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.blightheart.gear"))
                    .icon(() -> SCROLL_FIREBALL.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(SCROLL_FIREBALL.get());
                        output.accept(SCROLL_HEAL.get());
                        output.accept(SCROLL_LEVITATION.get());
                        output.accept(SCROLL_PURIFY.get());
                        output.accept(SCROLL_LIGHTNING.get());
                        output.accept(SCROLL_FROST_NOVA.get());
                        output.accept(SCROLL_BLINK.get());
                        output.accept(SCROLL_WARD.get());
                        output.accept(SCROLL_METEOR.get());
                        output.accept(SCROLL_LIFE_DRAIN.get());
                        output.accept(SCROLL_REPULSE.get());
                        output.accept(SCROLL_REVEAL.get());
                        output.accept(MANA_FLASK.get());
                        output.accept(GREATER_MANA_FLASK.get());
                        output.accept(AMULET_REGENERATION.get());
                        output.accept(AMULET_SWIFTNESS.get());
                        output.accept(AMULET_NIGHT_VISION.get());
                        output.accept(AMULET_FIRE_RESISTANCE.get());
                        output.accept(AMULET_STRENGTH.get());
                        output.accept(CHITIN_SWORD.get());
                        output.accept(CHITIN_PICKAXE.get());
                        output.accept(CHITIN_AXE.get());
                        output.accept(CHITIN_SHOVEL.get());
                        output.accept(CHITIN_HOE.get());
                        output.accept(SANGUINITE_HOE.get());
                        output.accept(FLESH_CHUNK.get());
                        output.accept(COOKED_FLESH_CHUNK.get());
                        output.accept(BLOOD_BERRIES.get());
                        output.accept(BLIGHT_STEW.get());
                        output.accept(MANA_BREAD.get());
                        output.accept(RESIN_CANDY.get());
                        output.accept(PURIFIED_APPLE.get());
                        output.accept(PUS_GLOB.get());
                    })
                    .build());

    private ModExtraItems() {}
}
