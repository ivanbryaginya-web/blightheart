// Path: src/main/java/com/example/blightheart/item/HealingResinItem.java
package com.example.blightheart.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Целебная смола (падает с Плевунов): съешь — и иссушение с отравлением проходят. */
public class HealingResinItem extends Item {

    public HealingResinItem(Properties properties) {
        super(properties);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide) {
            entity.removeEffect(MobEffects.WITHER);
            entity.removeEffect(MobEffects.POISON);
        }
        return super.finishUsingItem(stack, level, entity);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.blightheart.healing_resin").withStyle(ChatFormatting.GREEN));
    }
}
