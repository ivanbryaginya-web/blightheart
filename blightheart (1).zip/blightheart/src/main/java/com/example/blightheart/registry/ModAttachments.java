// Path: src/main/java/com/example/blightheart/registry/ModAttachments.java
package com.example.blightheart.registry;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.magic.ManaData;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/** Типы вложений данных (Attachment Types) — замена Capabilities в NeoForge 1.20.5+. */
public final class ModAttachments {

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, BlightheartMod.MODID);

    /**
     * Мана игрока.
     * serialize(...) — сохранять вложение вместе с данными сущности;
     * copyOnDeath() — переносить ману на "нового" игрока после смерти
     * (при возвращении из Энда сериализуемые вложения копируются автоматически).
     */
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<ManaData>> MANA =
            ATTACHMENT_TYPES.register("mana", () -> AttachmentType.builder(() -> new ManaData())
                    .serialize(ManaData.CODEC)
                    .copyOnDeath()
                    .build());

    private ModAttachments() {}
}
