// Path: src/main/java/com/example/blightheart/item/PurifyingBladeItem.java
package com.example.blightheart.item;

import com.example.blightheart.entity.BlightMonster;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * Клинок Очищения — меч алмазной прочности.
 * Против существ Заражения: +6 урона и поджог на 3 секунды.
 */
public class PurifyingBladeItem extends SwordItem {

    private static final float BONUS_VS_BLIGHT = 6.0F;

    public PurifyingBladeItem(Tier tier, Properties properties) {
        super(tier, properties);
    }

    /** Дополнительный урон по существам Заражения. */
    @Override
    public float getAttackDamageBonus(Entity target, float baseDamage, DamageSource source) {
        return target instanceof BlightMonster ? BONUS_VS_BLIGHT : 0.0F;
    }

    /** Попадание по существу Заражения поджигает его святым огнём. */
    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (target instanceof BlightMonster) target.igniteForSeconds(3.0F);
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.blightheart.purifying_blade").withStyle(ChatFormatting.AQUA));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
