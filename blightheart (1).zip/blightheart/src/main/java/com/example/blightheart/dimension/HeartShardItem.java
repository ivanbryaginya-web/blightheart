// Path: src/main/java/com/example/blightheart/dimension/HeartShardItem.java
package com.example.blightheart.dimension;

import com.example.blightheart.registry.ModBlocks;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import java.util.List;

/** Осколок Сердца: выпадает из разбитого Сердца. ПКМ по рамке из Окаменевшей плоти — открывает портал. */
public class HeartShardItem extends Item {

    public HeartShardItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!level.getBlockState(context.getClickedPos()).is(ModBlocks.PETRIFIED_FLESH.get()))
            return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;

        if (PortalHelper.tryActivate(level, context.getClickedPos())) {
            if (context.getPlayer() == null || !context.getPlayer().getAbilities().instabuild)
                context.getItemInHand().shrink(1); // осколок расходуется
            return InteractionResult.CONSUME;
        }
        if (context.getPlayer() != null) {
            context.getPlayer().displayClientMessage(Component.translatable("message.blightheart.bad_frame")
                    .withStyle(ChatFormatting.RED), true);
        }
        return InteractionResult.FAIL;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.blightheart.heart_shard").withStyle(ChatFormatting.DARK_RED));
    }

    /** Блестит, как зачарованный. */
    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
