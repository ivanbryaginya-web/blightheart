// Path: src/main/java/com/example/blightheart/magic/ManaEssenceItem.java
package com.example.blightheart.magic;

import com.example.blightheart.network.ModNetwork;
import com.example.blightheart.registry.ModAttachments;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Эссенция маны (добывается из руды маны): ПКМ — мгновенно восстанавливает 40 маны. */
public class ManaEssenceItem extends Item {

    public static final int RESTORE = 40;

    public ManaEssenceItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer serverPlayer)) return InteractionResultHolder.success(stack);

        ManaData mana = serverPlayer.getData(ModAttachments.MANA);
        if (!mana.regenerate(RESTORE)) {   // мана уже полная — не тратим эссенцию
            player.displayClientMessage(Component.translatable("message.blightheart.mana_full")
                    .withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }
        ModNetwork.syncMana(serverPlayer);
        if (!player.getAbilities().instabuild) stack.shrink(1);

        ((ServerLevel) level).sendParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.0D, player.getZ(),
                30, 0.4D, 0.6D, 0.4D, 0.6D);
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_CLUSTER_BREAK, SoundSource.PLAYERS, 1.0F, 1.4F);
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.blightheart.mana_essence", RESTORE).withStyle(ChatFormatting.BLUE));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
