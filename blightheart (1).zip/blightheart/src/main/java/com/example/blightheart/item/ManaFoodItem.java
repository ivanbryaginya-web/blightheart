// Path: src/main/java/com/example/blightheart/item/ManaFoodItem.java
package com.example.blightheart.item;

import com.example.blightheart.network.ModNetwork;
import com.example.blightheart.registry.ModAttachments;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Еда, которая кроме сытости немного восстанавливает ману (Хлеб маны). */
public class ManaFoodItem extends Item {

    private final int mana;

    public ManaFoodItem(int mana, Properties properties) {
        super(properties);
        this.mana = mana;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer player) {
            player.getData(ModAttachments.MANA).regenerate(mana);
            ModNetwork.syncMana(player);
        }
        return super.finishUsingItem(stack, level, entity);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.blightheart.mana_food", mana).withStyle(ChatFormatting.BLUE));
    }
}
