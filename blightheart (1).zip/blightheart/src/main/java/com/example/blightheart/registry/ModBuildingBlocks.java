// Path: src/main/java/com/example/blightheart/registry/ModBuildingBlocks.java
package com.example.blightheart.registry;

import com.example.blightheart.BlightheartMod;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Строительные блоки: ступеньки, плиты, стены, заборы, двери, люки, кнопки, стекло, фонарь.
 * Модели, рецепты и добыча сделаны по ванильным образцам — блоки ведут себя как обычные
 * (стены соединяются, двери открываются, плиты складываются в двойные).
 */
public final class ModBuildingBlocks {

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(BlightheartMod.MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(BlightheartMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BlightheartMod.MODID);

    private static BlockBehaviour.Properties stone(MapColor color) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(1.8F, 6.0F)
                .requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE_BRICKS);
    }

    private static BlockBehaviour.Properties wood() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.TERRACOTTA_BROWN).strength(2.0F, 3.0F)
                .sound(SoundType.WOOD).ignitedByLava();
    }

    private static BlockBehaviour.Properties glass() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(0.3F).sound(SoundType.GLASS)
                .noOcclusion().isValidSpawn((s, l, p, t) -> false).isRedstoneConductor((s, l, p) -> false)
                .isSuffocating((s, l, p) -> false).isViewBlocking((s, l, p) -> false);
    }

    public static final DeferredBlock<StairBlock> PETRIFIED_FLESH_STAIRS = BLOCKS.register("petrified_flesh_stairs",
            () -> new StairBlock(ModBlocks.PETRIFIED_FLESH.get().defaultBlockState(), stone(MapColor.TERRACOTTA_RED)));
    public static final DeferredBlock<SlabBlock> PETRIFIED_FLESH_SLAB = BLOCKS.register("petrified_flesh_slab",
            () -> new SlabBlock(stone(MapColor.TERRACOTTA_RED)));
    public static final DeferredBlock<WallBlock> PETRIFIED_FLESH_WALL = BLOCKS.register("petrified_flesh_wall",
            () -> new WallBlock(stone(MapColor.TERRACOTTA_RED).forceSolidOn()));
    public static final DeferredBlock<Block> PETRIFIED_FLESH_BRICKS = BLOCKS.register("petrified_flesh_bricks",
            () -> new Block(stone(MapColor.TERRACOTTA_RED)));
    public static final DeferredBlock<StairBlock> PETRIFIED_FLESH_BRICK_STAIRS = BLOCKS.register("petrified_flesh_brick_stairs",
            () -> new StairBlock(PETRIFIED_FLESH_BRICKS.get().defaultBlockState(), stone(MapColor.TERRACOTTA_RED)));
    public static final DeferredBlock<SlabBlock> PETRIFIED_FLESH_BRICK_SLAB = BLOCKS.register("petrified_flesh_brick_slab",
            () -> new SlabBlock(stone(MapColor.TERRACOTTA_RED)));
    public static final DeferredBlock<WallBlock> PETRIFIED_FLESH_BRICK_WALL = BLOCKS.register("petrified_flesh_brick_wall",
            () -> new WallBlock(stone(MapColor.TERRACOTTA_RED).forceSolidOn()));
    public static final DeferredBlock<Block> POLISHED_PETRIFIED_FLESH = BLOCKS.register("polished_petrified_flesh",
            () -> new Block(stone(MapColor.TERRACOTTA_RED)));
    public static final DeferredBlock<StairBlock> POLISHED_PETRIFIED_FLESH_STAIRS = BLOCKS.register("polished_petrified_flesh_stairs",
            () -> new StairBlock(POLISHED_PETRIFIED_FLESH.get().defaultBlockState(), stone(MapColor.TERRACOTTA_RED)));
    public static final DeferredBlock<SlabBlock> POLISHED_PETRIFIED_FLESH_SLAB = BLOCKS.register("polished_petrified_flesh_slab",
            () -> new SlabBlock(stone(MapColor.TERRACOTTA_RED)));
    public static final DeferredBlock<Block> BLIGHTSTONE = BLOCKS.register("blightstone",
            () -> new Block(stone(MapColor.COLOR_PURPLE)));
    public static final DeferredBlock<StairBlock> BLIGHTSTONE_STAIRS = BLOCKS.register("blightstone_stairs",
            () -> new StairBlock(BLIGHTSTONE.get().defaultBlockState(), stone(MapColor.COLOR_PURPLE)));
    public static final DeferredBlock<SlabBlock> BLIGHTSTONE_SLAB = BLOCKS.register("blightstone_slab",
            () -> new SlabBlock(stone(MapColor.COLOR_PURPLE)));
    public static final DeferredBlock<Block> COBBLED_BLIGHTSTONE = BLOCKS.register("cobbled_blightstone",
            () -> new Block(stone(MapColor.COLOR_PURPLE)));
    public static final DeferredBlock<StairBlock> COBBLED_BLIGHTSTONE_STAIRS = BLOCKS.register("cobbled_blightstone_stairs",
            () -> new StairBlock(COBBLED_BLIGHTSTONE.get().defaultBlockState(), stone(MapColor.COLOR_PURPLE)));
    public static final DeferredBlock<SlabBlock> COBBLED_BLIGHTSTONE_SLAB = BLOCKS.register("cobbled_blightstone_slab",
            () -> new SlabBlock(stone(MapColor.COLOR_PURPLE)));
    public static final DeferredBlock<WallBlock> COBBLED_BLIGHTSTONE_WALL = BLOCKS.register("cobbled_blightstone_wall",
            () -> new WallBlock(stone(MapColor.COLOR_PURPLE).forceSolidOn()));
    public static final DeferredBlock<Block> BLIGHTSTONE_BRICKS = BLOCKS.register("blightstone_bricks",
            () -> new Block(stone(MapColor.COLOR_PURPLE)));
    public static final DeferredBlock<StairBlock> BLIGHTSTONE_BRICK_STAIRS = BLOCKS.register("blightstone_brick_stairs",
            () -> new StairBlock(BLIGHTSTONE_BRICKS.get().defaultBlockState(), stone(MapColor.COLOR_PURPLE)));
    public static final DeferredBlock<SlabBlock> BLIGHTSTONE_BRICK_SLAB = BLOCKS.register("blightstone_brick_slab",
            () -> new SlabBlock(stone(MapColor.COLOR_PURPLE)));
    public static final DeferredBlock<WallBlock> BLIGHTSTONE_BRICK_WALL = BLOCKS.register("blightstone_brick_wall",
            () -> new WallBlock(stone(MapColor.COLOR_PURPLE).forceSolidOn()));
    public static final DeferredBlock<Block> SANGUINITE_BRICKS = BLOCKS.register("sanguinite_bricks",
            () -> new Block(stone(MapColor.COLOR_RED)));
    public static final DeferredBlock<StairBlock> SANGUINITE_BRICK_STAIRS = BLOCKS.register("sanguinite_brick_stairs",
            () -> new StairBlock(SANGUINITE_BRICKS.get().defaultBlockState(), stone(MapColor.COLOR_RED)));
    public static final DeferredBlock<SlabBlock> SANGUINITE_BRICK_SLAB = BLOCKS.register("sanguinite_brick_slab",
            () -> new SlabBlock(stone(MapColor.COLOR_RED)));
    public static final DeferredBlock<WallBlock> SANGUINITE_BRICK_WALL = BLOCKS.register("sanguinite_brick_wall",
            () -> new WallBlock(stone(MapColor.COLOR_RED).forceSolidOn()));
    public static final DeferredBlock<Block> CHISELED_PETRIFIED_FLESH = BLOCKS.register("chiseled_petrified_flesh",
            () -> new Block(stone(MapColor.TERRACOTTA_RED)));
    public static final DeferredBlock<Block> SANGUINITE_LAMP = BLOCKS.register("sanguinite_lamp",
            () -> new Block(stone(MapColor.COLOR_RED).lightLevel(s -> 15).sound(SoundType.GLASS)));
    public static final DeferredBlock<StairBlock> ROTWOOD_STAIRS = BLOCKS.register("rotwood_stairs",
            () -> new StairBlock(ModBlocks.ROTWOOD_PLANKS.get().defaultBlockState(), wood()));
    public static final DeferredBlock<SlabBlock> ROTWOOD_SLAB = BLOCKS.register("rotwood_slab",
            () -> new SlabBlock(wood()));
    public static final DeferredBlock<FenceBlock> ROTWOOD_FENCE = BLOCKS.register("rotwood_fence",
            () -> new FenceBlock(wood()));
    public static final DeferredBlock<FenceGateBlock> ROTWOOD_FENCE_GATE = BLOCKS.register("rotwood_fence_gate",
            () -> new FenceGateBlock(WoodType.OAK, wood()));
    public static final DeferredBlock<DoorBlock> ROTWOOD_DOOR = BLOCKS.register("rotwood_door",
            () -> new DoorBlock(BlockSetType.OAK, wood().strength(3.0F).noOcclusion().pushReaction(PushReaction.DESTROY)));
    public static final DeferredBlock<TrapDoorBlock> ROTWOOD_TRAPDOOR = BLOCKS.register("rotwood_trapdoor",
            () -> new TrapDoorBlock(BlockSetType.OAK, wood().strength(3.0F).noOcclusion().isValidSpawn((s, l, p, t) -> false)));
    public static final DeferredBlock<ButtonBlock> ROTWOOD_BUTTON = BLOCKS.register("rotwood_button",
            () -> new ButtonBlock(BlockSetType.OAK, 30, BlockBehaviour.Properties.of().noCollission().strength(0.5F).pushReaction(PushReaction.DESTROY)));
    public static final DeferredBlock<PressurePlateBlock> ROTWOOD_PRESSURE_PLATE = BLOCKS.register("rotwood_pressure_plate",
            () -> new PressurePlateBlock(BlockSetType.OAK, wood().noCollission().strength(0.5F).pushReaction(PushReaction.DESTROY)));
    public static final DeferredBlock<TransparentBlock> MEMBRANE_GLASS = BLOCKS.register("membrane_glass",
            () -> new TransparentBlock(glass()));
    public static final DeferredBlock<IronBarsBlock> MEMBRANE_GLASS_PANE = BLOCKS.register("membrane_glass_pane",
            () -> new IronBarsBlock(glass()));
    public static final DeferredBlock<LanternBlock> BLOOD_LANTERN = BLOCKS.register("blood_lantern",
            () -> new LanternBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).requiresCorrectToolForDrops().strength(3.5F).sound(SoundType.LANTERN).lightLevel(s -> 13).noOcclusion().pushReaction(PushReaction.DESTROY)));

    public static final DeferredItem<BlockItem> PETRIFIED_FLESH_STAIRS_ITEM = ITEMS.registerSimpleBlockItem(PETRIFIED_FLESH_STAIRS);
    public static final DeferredItem<BlockItem> PETRIFIED_FLESH_SLAB_ITEM = ITEMS.registerSimpleBlockItem(PETRIFIED_FLESH_SLAB);
    public static final DeferredItem<BlockItem> PETRIFIED_FLESH_WALL_ITEM = ITEMS.registerSimpleBlockItem(PETRIFIED_FLESH_WALL);
    public static final DeferredItem<BlockItem> PETRIFIED_FLESH_BRICKS_ITEM = ITEMS.registerSimpleBlockItem(PETRIFIED_FLESH_BRICKS);
    public static final DeferredItem<BlockItem> PETRIFIED_FLESH_BRICK_STAIRS_ITEM = ITEMS.registerSimpleBlockItem(PETRIFIED_FLESH_BRICK_STAIRS);
    public static final DeferredItem<BlockItem> PETRIFIED_FLESH_BRICK_SLAB_ITEM = ITEMS.registerSimpleBlockItem(PETRIFIED_FLESH_BRICK_SLAB);
    public static final DeferredItem<BlockItem> PETRIFIED_FLESH_BRICK_WALL_ITEM = ITEMS.registerSimpleBlockItem(PETRIFIED_FLESH_BRICK_WALL);
    public static final DeferredItem<BlockItem> POLISHED_PETRIFIED_FLESH_ITEM = ITEMS.registerSimpleBlockItem(POLISHED_PETRIFIED_FLESH);
    public static final DeferredItem<BlockItem> POLISHED_PETRIFIED_FLESH_STAIRS_ITEM = ITEMS.registerSimpleBlockItem(POLISHED_PETRIFIED_FLESH_STAIRS);
    public static final DeferredItem<BlockItem> POLISHED_PETRIFIED_FLESH_SLAB_ITEM = ITEMS.registerSimpleBlockItem(POLISHED_PETRIFIED_FLESH_SLAB);
    public static final DeferredItem<BlockItem> BLIGHTSTONE_ITEM = ITEMS.registerSimpleBlockItem(BLIGHTSTONE);
    public static final DeferredItem<BlockItem> BLIGHTSTONE_STAIRS_ITEM = ITEMS.registerSimpleBlockItem(BLIGHTSTONE_STAIRS);
    public static final DeferredItem<BlockItem> BLIGHTSTONE_SLAB_ITEM = ITEMS.registerSimpleBlockItem(BLIGHTSTONE_SLAB);
    public static final DeferredItem<BlockItem> COBBLED_BLIGHTSTONE_ITEM = ITEMS.registerSimpleBlockItem(COBBLED_BLIGHTSTONE);
    public static final DeferredItem<BlockItem> COBBLED_BLIGHTSTONE_STAIRS_ITEM = ITEMS.registerSimpleBlockItem(COBBLED_BLIGHTSTONE_STAIRS);
    public static final DeferredItem<BlockItem> COBBLED_BLIGHTSTONE_SLAB_ITEM = ITEMS.registerSimpleBlockItem(COBBLED_BLIGHTSTONE_SLAB);
    public static final DeferredItem<BlockItem> COBBLED_BLIGHTSTONE_WALL_ITEM = ITEMS.registerSimpleBlockItem(COBBLED_BLIGHTSTONE_WALL);
    public static final DeferredItem<BlockItem> BLIGHTSTONE_BRICKS_ITEM = ITEMS.registerSimpleBlockItem(BLIGHTSTONE_BRICKS);
    public static final DeferredItem<BlockItem> BLIGHTSTONE_BRICK_STAIRS_ITEM = ITEMS.registerSimpleBlockItem(BLIGHTSTONE_BRICK_STAIRS);
    public static final DeferredItem<BlockItem> BLIGHTSTONE_BRICK_SLAB_ITEM = ITEMS.registerSimpleBlockItem(BLIGHTSTONE_BRICK_SLAB);
    public static final DeferredItem<BlockItem> BLIGHTSTONE_BRICK_WALL_ITEM = ITEMS.registerSimpleBlockItem(BLIGHTSTONE_BRICK_WALL);
    public static final DeferredItem<BlockItem> SANGUINITE_BRICKS_ITEM = ITEMS.registerSimpleBlockItem(SANGUINITE_BRICKS);
    public static final DeferredItem<BlockItem> SANGUINITE_BRICK_STAIRS_ITEM = ITEMS.registerSimpleBlockItem(SANGUINITE_BRICK_STAIRS);
    public static final DeferredItem<BlockItem> SANGUINITE_BRICK_SLAB_ITEM = ITEMS.registerSimpleBlockItem(SANGUINITE_BRICK_SLAB);
    public static final DeferredItem<BlockItem> SANGUINITE_BRICK_WALL_ITEM = ITEMS.registerSimpleBlockItem(SANGUINITE_BRICK_WALL);
    public static final DeferredItem<BlockItem> CHISELED_PETRIFIED_FLESH_ITEM = ITEMS.registerSimpleBlockItem(CHISELED_PETRIFIED_FLESH);
    public static final DeferredItem<BlockItem> SANGUINITE_LAMP_ITEM = ITEMS.registerSimpleBlockItem(SANGUINITE_LAMP);
    public static final DeferredItem<BlockItem> ROTWOOD_STAIRS_ITEM = ITEMS.registerSimpleBlockItem(ROTWOOD_STAIRS);
    public static final DeferredItem<BlockItem> ROTWOOD_SLAB_ITEM = ITEMS.registerSimpleBlockItem(ROTWOOD_SLAB);
    public static final DeferredItem<BlockItem> ROTWOOD_FENCE_ITEM = ITEMS.registerSimpleBlockItem(ROTWOOD_FENCE);
    public static final DeferredItem<BlockItem> ROTWOOD_FENCE_GATE_ITEM = ITEMS.registerSimpleBlockItem(ROTWOOD_FENCE_GATE);
    public static final DeferredItem<DoubleHighBlockItem> ROTWOOD_DOOR_ITEM = ITEMS.register("rotwood_door",
            () -> new DoubleHighBlockItem(ROTWOOD_DOOR.get(), new Item.Properties()));
    public static final DeferredItem<BlockItem> ROTWOOD_TRAPDOOR_ITEM = ITEMS.registerSimpleBlockItem(ROTWOOD_TRAPDOOR);
    public static final DeferredItem<BlockItem> ROTWOOD_BUTTON_ITEM = ITEMS.registerSimpleBlockItem(ROTWOOD_BUTTON);
    public static final DeferredItem<BlockItem> ROTWOOD_PRESSURE_PLATE_ITEM = ITEMS.registerSimpleBlockItem(ROTWOOD_PRESSURE_PLATE);
    public static final DeferredItem<BlockItem> MEMBRANE_GLASS_ITEM = ITEMS.registerSimpleBlockItem(MEMBRANE_GLASS);
    public static final DeferredItem<BlockItem> MEMBRANE_GLASS_PANE_ITEM = ITEMS.registerSimpleBlockItem(MEMBRANE_GLASS_PANE);
    public static final DeferredItem<BlockItem> BLOOD_LANTERN_ITEM = ITEMS.registerSimpleBlockItem(BLOOD_LANTERN);

    /** Отдельная вкладка творческого режима для строительства. */
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("building",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.blightheart.building"))
                    .icon(() -> PETRIFIED_FLESH_BRICKS_ITEM.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(PETRIFIED_FLESH_STAIRS_ITEM.get());
                        output.accept(PETRIFIED_FLESH_SLAB_ITEM.get());
                        output.accept(PETRIFIED_FLESH_WALL_ITEM.get());
                        output.accept(PETRIFIED_FLESH_BRICKS_ITEM.get());
                        output.accept(PETRIFIED_FLESH_BRICK_STAIRS_ITEM.get());
                        output.accept(PETRIFIED_FLESH_BRICK_SLAB_ITEM.get());
                        output.accept(PETRIFIED_FLESH_BRICK_WALL_ITEM.get());
                        output.accept(POLISHED_PETRIFIED_FLESH_ITEM.get());
                        output.accept(POLISHED_PETRIFIED_FLESH_STAIRS_ITEM.get());
                        output.accept(POLISHED_PETRIFIED_FLESH_SLAB_ITEM.get());
                        output.accept(BLIGHTSTONE_ITEM.get());
                        output.accept(BLIGHTSTONE_STAIRS_ITEM.get());
                        output.accept(BLIGHTSTONE_SLAB_ITEM.get());
                        output.accept(COBBLED_BLIGHTSTONE_ITEM.get());
                        output.accept(COBBLED_BLIGHTSTONE_STAIRS_ITEM.get());
                        output.accept(COBBLED_BLIGHTSTONE_SLAB_ITEM.get());
                        output.accept(COBBLED_BLIGHTSTONE_WALL_ITEM.get());
                        output.accept(BLIGHTSTONE_BRICKS_ITEM.get());
                        output.accept(BLIGHTSTONE_BRICK_STAIRS_ITEM.get());
                        output.accept(BLIGHTSTONE_BRICK_SLAB_ITEM.get());
                        output.accept(BLIGHTSTONE_BRICK_WALL_ITEM.get());
                        output.accept(SANGUINITE_BRICKS_ITEM.get());
                        output.accept(SANGUINITE_BRICK_STAIRS_ITEM.get());
                        output.accept(SANGUINITE_BRICK_SLAB_ITEM.get());
                        output.accept(SANGUINITE_BRICK_WALL_ITEM.get());
                        output.accept(CHISELED_PETRIFIED_FLESH_ITEM.get());
                        output.accept(SANGUINITE_LAMP_ITEM.get());
                        output.accept(ROTWOOD_STAIRS_ITEM.get());
                        output.accept(ROTWOOD_SLAB_ITEM.get());
                        output.accept(ROTWOOD_FENCE_ITEM.get());
                        output.accept(ROTWOOD_FENCE_GATE_ITEM.get());
                        output.accept(ROTWOOD_DOOR_ITEM.get());
                        output.accept(ROTWOOD_TRAPDOOR_ITEM.get());
                        output.accept(ROTWOOD_BUTTON_ITEM.get());
                        output.accept(ROTWOOD_PRESSURE_PLATE_ITEM.get());
                        output.accept(MEMBRANE_GLASS_ITEM.get());
                        output.accept(MEMBRANE_GLASS_PANE_ITEM.get());
                        output.accept(BLOOD_LANTERN_ITEM.get());
                    })
                    .build());

    private ModBuildingBlocks() {}
}
