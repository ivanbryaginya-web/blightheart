// Path: src/main/java/com/example/blightheart/event/ArmorSetEvents.java
package com.example.blightheart.event;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.entity.BlightMonster;
import com.example.blightheart.item.AmuletItem;
import com.example.blightheart.registry.ModItems;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Бонусы за полный комплект брони.
 *  Хитиновая броня: иммунитет к иссушению (заражение и мобы Сердца больше не иссушают).
 *  Броня Матки: то же + постоянная регенерация + тот, кто тебя ударил, сам иссыхает.
 */
@EventBusSubscriber(modid = BlightheartMod.MODID)
public final class ArmorSetEvents {

    /** Надет ли весь комплект (шлем, нагрудник, поножи, ботинки). */
    public static boolean wearsSet(LivingEntity entity, Item helmet, Item chest, Item legs, Item boots) {
        return entity.getItemBySlot(EquipmentSlot.HEAD).is(helmet)
                && entity.getItemBySlot(EquipmentSlot.CHEST).is(chest)
                && entity.getItemBySlot(EquipmentSlot.LEGS).is(legs)
                && entity.getItemBySlot(EquipmentSlot.FEET).is(boots);
    }

    public static boolean wearsChitin(LivingEntity e) {
        return wearsSet(e, ModItems.CHITIN_HELMET.get(), ModItems.CHITIN_CHESTPLATE.get(),
                ModItems.CHITIN_LEGGINGS.get(), ModItems.CHITIN_BOOTS.get());
    }

    public static boolean wearsMatriarch(LivingEntity e) {
        return wearsSet(e, ModItems.MATRIARCH_HELMET.get(), ModItems.MATRIARCH_CHESTPLATE.get(),
                ModItems.MATRIARCH_LEGGINGS.get(), ModItems.MATRIARCH_BOOTS.get());
    }

    /** Раз в полсекунды проверяем комплект и применяем бонусы. */
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide || player.tickCount % 10 != 0) return;

        // Амулеты в инвентаре
        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            if (player.getInventory().getItem(slot).getItem() instanceof AmuletItem amulet) amulet.apply(player);
        }

        boolean matriarch = wearsMatriarch(player);
        if (matriarch || wearsChitin(player)) {
            player.removeEffect(MobEffects.WITHER); // заражение не берёт
        }
        if (matriarch && player.tickCount % 40 == 0) {
            // Регенерация I, пока надет комплект (без частиц, чтобы не мешали)
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, false, true));
        }
    }

    /** Броня Матки: напавший на тебя получает иссушение (существа Заражения к нему невосприимчивы). */
    @SubscribeEvent
    public static void onDamage(LivingDamageEvent.Post event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide || !(event.getSource().getEntity() instanceof LivingEntity attacker)) return;
        if (attacker == victim || attacker instanceof BlightMonster) return;
        if (wearsMatriarch(victim)) {
            attacker.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 1), victim);
        }
    }

    private ArmorSetEvents() {}
}
