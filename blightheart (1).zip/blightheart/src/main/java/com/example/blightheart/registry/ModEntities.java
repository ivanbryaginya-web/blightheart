// Path: src/main/java/com/example/blightheart/registry/ModEntities.java
package com.example.blightheart.registry;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.entity.BlightMatriarchEntity;
import com.example.blightheart.entity.BloaterEntity;
import com.example.blightheart.entity.HeartGuardianEntity;
import com.example.blightheart.entity.SpitterEntity;
import com.example.blightheart.entity.SpawnlingEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Регистрация существ. */
public final class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, BlightheartMod.MODID);

    /** Порождение — существо, которое рождает Сердце. */
    public static final DeferredHolder<EntityType<?>, EntityType<SpawnlingEntity>> SPAWNLING =
            ENTITY_TYPES.register("spawnling", () -> EntityType.Builder
                    .of(SpawnlingEntity::new, MobCategory.MONSTER)
                    .sized(1.0F, 0.7F)
                    .clientTrackingRange(8)
                    .build(BlightheartMod.MODID + ":spawnling"));

    /** Страж Сердца — большой гуманоид ростом почти 3 блока. */
    public static final DeferredHolder<EntityType<?>, EntityType<HeartGuardianEntity>> HEART_GUARDIAN =
            ENTITY_TYPES.register("heart_guardian", () -> EntityType.Builder
                    .of(HeartGuardianEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 2.7F)
                    .clientTrackingRange(10)
                    .build(BlightheartMod.MODID + ":heart_guardian"));

    /** Плевун — плюётся ядом издалека. */
    public static final DeferredHolder<EntityType<?>, EntityType<SpitterEntity>> SPITTER =
            ENTITY_TYPES.register("spitter", () -> EntityType.Builder
                    .of(SpitterEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.99F)
                    .clientTrackingRange(8)
                    .build(BlightheartMod.MODID + ":spitter"));

    /** Гнойник — подходит и лопается. */
    public static final DeferredHolder<EntityType<?>, EntityType<BloaterEntity>> BLOATER =
            ENTITY_TYPES.register("bloater", () -> EntityType.Builder
                    .of(BloaterEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 1.2F)
                    .clientTrackingRange(8)
                    .build(BlightheartMod.MODID + ":bloater"));

    /** БОСС: Матка Заражения — огромная, ростом больше 4 блоков, не горит. */
    public static final DeferredHolder<EntityType<?>, EntityType<BlightMatriarchEntity>> BLIGHT_MATRIARCH =
            ENTITY_TYPES.register("blight_matriarch", () -> EntityType.Builder
                    .of(BlightMatriarchEntity::new, MobCategory.MONSTER)
                    .sized(1.6F, 4.3F)
                    .fireImmune()
                    .clientTrackingRange(12)
                    .build(BlightheartMod.MODID + ":blight_matriarch"));

    private ModEntities() {}
}
