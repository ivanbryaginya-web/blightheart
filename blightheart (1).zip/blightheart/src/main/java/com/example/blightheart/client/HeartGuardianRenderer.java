// Path: src/main/java/com/example/blightheart/client/HeartGuardianRenderer.java
package com.example.blightheart.client;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.client.model.HeartGuardianModel;
import com.example.blightheart.entity.HeartGuardianEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Рендер на собственной модели + светящийся слой (глаза и т.п.). */
public class HeartGuardianRenderer extends MobRenderer<HeartGuardianEntity, HeartGuardianModel<HeartGuardianEntity>> {

    private static final ResourceLocation TEXTURE = BlightheartMod.id("textures/entity/heart_guardian.png");
    private static final ResourceLocation GLOW = BlightheartMod.id("textures/entity/heart_guardian_glow.png");

    public HeartGuardianRenderer(EntityRendererProvider.Context context) {
        super(context, new HeartGuardianModel<>(context.bakeLayer(HeartGuardianModel.LAYER)), 1.0F);
        this.addLayer(new GlowLayer<>(this, GLOW));
    }

    @Override
    public ResourceLocation getTextureLocation(HeartGuardianEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(HeartGuardianEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.4F, 1.4F, 1.4F);
    }
}
