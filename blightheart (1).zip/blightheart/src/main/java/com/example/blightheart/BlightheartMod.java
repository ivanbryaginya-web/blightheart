// Path: src/main/java/com/example/blightheart/BlightheartMod.java
package com.example.blightheart;

import com.example.blightheart.entity.BlightMatriarchEntity;
import com.example.blightheart.entity.BloaterEntity;
import com.example.blightheart.entity.HeartGuardianEntity;
import com.example.blightheart.entity.SpitterEntity;
import com.example.blightheart.entity.SpawnlingEntity;
import com.example.blightheart.registry.*;
import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import org.slf4j.Logger;
import com.example.blightheart.network.ModNetwork;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

/**
 * Мод "Сердце Заражения".
 * Сердце распространяет заражённую массу, порождает существ и убивает всё живое вокруг.
 * Если разбить Сердце, гибнет всё, что оно создало.
 *
 * Также включает магию (бывший мод Mysticor): ману, палочки и заклинания —
 * в том числе Очищение против заражения — и Заражённый мир, куда ведёт портал.
 */
@Mod(BlightheartMod.MODID)
public class BlightheartMod {

    public static final String MODID = "blightheart";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }

    public BlightheartMod(IEventBus modEventBus, ModContainer modContainer) {
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITY_TYPES.register(modEventBus);
        ModEntities.ENTITY_TYPES.register(modEventBus);
        ModArmorMaterials.ARMOR_MATERIALS.register(modEventBus);   // материалы брони
        ModCreativeTabs.CREATIVE_TABS.register(modEventBus);
        ModDataComponents.DATA_COMPONENTS.register(modEventBus);   // магия: выбранное заклинание палочки
        ModAttachments.ATTACHMENT_TYPES.register(modEventBus);     // магия: мана игрока

        modEventBus.addListener(ModNetwork::registerPayloads);     // синхронизация маны

        // Существа Заражения сами появляются в Заражённом мире — при любом освещении
        modEventBus.addListener((RegisterSpawnPlacementsEvent event) -> {
            event.register(ModEntities.SPAWNLING.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkAnyLightMonsterSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.REPLACE);
            event.register(ModEntities.HEART_GUARDIAN.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkAnyLightMonsterSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.REPLACE);
            event.register(ModEntities.SPITTER.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkAnyLightMonsterSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.REPLACE);
            event.register(ModEntities.BLOATER.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkAnyLightMonsterSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.REPLACE);
        });

        // Без атрибутов (здоровье, урон, скорость) живое существо упадёт с ошибкой при появлении
        modEventBus.addListener((EntityAttributeCreationEvent event) -> {
            event.put(ModEntities.SPAWNLING.get(), SpawnlingEntity.createAttributes().build());
            event.put(ModEntities.HEART_GUARDIAN.get(), HeartGuardianEntity.createAttributes().build());
            event.put(ModEntities.SPITTER.get(), SpitterEntity.createAttributes().build());
            event.put(ModEntities.BLOATER.get(), BloaterEntity.createAttributes().build());
            event.put(ModEntities.BLIGHT_MATRIARCH.get(), BlightMatriarchEntity.createAttributes().build());
        });
    }
}
