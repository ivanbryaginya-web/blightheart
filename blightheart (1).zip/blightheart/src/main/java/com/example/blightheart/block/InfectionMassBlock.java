// Path: src/main/java/com/example/blightheart/block/InfectionMassBlock.java
package com.example.blightheart.block;

import com.example.blightheart.dimension.ModDimensions;
import com.example.blightheart.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/**
 * Заражённая масса. Живая масса САМА заражает соседние блоки (как скалк или мицелий),
 * поэтому заражение растёт бесконечно. Кто по ней ходит — иссыхает.
 * Гниющая масса (DECAYING) передаёт гниение соседям и рассыпается — так волна
 * от разбитого Сердца проходит по всей массе, сколько бы её ни было.
 */
public class InfectionMassBlock extends Block {

    /** "Гниёт" — Сердце мертво, блок скоро исчезнет. */
    public static final BooleanProperty DECAYING = BooleanProperty.create("decaying");

    /** Сколько соседей пытается заразить блок за один случайный тик. */
    private static final int SPREAD_TRIES = 2;

    public InfectionMassBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(DECAYING, false));
    }

    /** Растёт ли блок сам. Масса — да, мембрана купола — нет (её строит Сердце). */
    protected boolean canSpread() {
        return true;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(DECAYING);
    }

    /** Наступил на живую массу — получаешь иссушение. */
    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (!level.isClientSide && !state.getValue(DECAYING)
                && entity instanceof LivingEntity living && InfectionManager.isVictim(living)) {
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, 20, 0));
        }
        super.stepOn(level, pos, state, entity);
    }

    /** Случайные тики нужны и живой массе (рост), и гниющей (запасной способ рассыпаться). */
    @Override
    public boolean isRandomlyTicking(BlockState state) {
        return true;
    }

    /**
     * Случайный тик живой массы — бесконечное распространение.
     * Скорость зависит от /gamerule randomTickSpeed (по умолчанию 3; 20–30 — очень быстро).
     */
    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(DECAYING)) {
            tick(state, level, pos, random);
            return;
        }

        // В Заражённом мире масса — это просто земля: не растёт и не гниёт
        if (ModDimensions.isInfectedWorld(level)) return;

        // В этом измерении не осталось ни одного Сердца — масса-сирота начинает гнить
        if (!HeartTracker.get(level).hasHearts()) {
            startDecay(level, pos, state, random);
            return;
        }

        // Мембрана купола не растёт; /gamerule mobGriefing false останавливает рост массы
        if (!canSpread() || !level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) return;

        for (int i = 0; i < SPREAD_TRIES; i++) {
            BlockPos target = pos.relative(Direction.getRandom(random));
            if (!level.isLoaded(target)) continue;
            BlockState targetState = level.getBlockState(target);
            if (targetState.getBlock() instanceof InfectionMassBlock
                    || targetState.is(ModBlocks.INFECTION_HEART.get())) continue;
            InfectionManager.infect(level, target, targetState);
        }
    }

    /**
     * Во что превращается отмершая масса:
     *  - мембрана купола висела в воздухе → воздух;
     *  - на поверхности под открытым небом → трава (или земля, если сверху что-то есть);
     *  - глубоко под землёй → камень, ниже нуля → глубинный сланец.
     */
    protected BlockState restoredState(ServerLevel level, BlockPos pos) {
        if (!canSpread()) return net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        if (pos.getY() < 0) return net.minecraft.world.level.block.Blocks.DEEPSLATE.defaultBlockState();
        if (level.canSeeSky(pos.above())) {
            return level.getBlockState(pos.above()).isAir()
                    ? net.minecraft.world.level.block.Blocks.GRASS_BLOCK.defaultBlockState()
                    : net.minecraft.world.level.block.Blocks.DIRT.defaultBlockState();
        }
        return net.minecraft.world.level.block.Blocks.STONE.defaultBlockState();
    }

    /** Пометить блок как гниющий и запланировать, когда он рассыплется. */
    public static void startDecay(ServerLevel level, BlockPos pos, BlockState state, RandomSource random) {
        level.setBlock(pos, state.setValue(DECAYING, true), Block.UPDATE_CLIENTS);
        level.scheduleTick(pos, state.getBlock(), 5 + random.nextInt(20));
    }

    /**
     * Гниющий блок: заражает гниением всех живых соседей и рассыпается.
     * Если сосед в незагруженном чанке — ждём, пока игрок подойдёт, чтобы волна не оборвалась.
     */
    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.getValue(DECAYING)) return;

        for (Direction dir : Direction.values()) {
            if (!level.isLoaded(pos.relative(dir))) {
                level.scheduleTick(pos, this, 100); // попробуем снова через 5 секунд
                return;
            }
        }
        for (Direction dir : Direction.values()) {
            BlockPos neighbor = pos.relative(dir);
            BlockState neighborState = level.getBlockState(neighbor);
            // Гниение переходит и на массу, и на мембрану купола
            if (neighborState.getBlock() instanceof InfectionMassBlock && !neighborState.getValue(DECAYING))
                startDecay(level, neighbor, neighborState, random);
        }
        // Раньше масса просто исчезала, и после гибели Сердца мир оставался в огромных дырах.
        // Теперь она "отмирает" и под ней проступает обычная земля.
        level.levelEvent(2001, pos, Block.getId(state));   // частицы и звук разрушения
        level.setBlockAndUpdate(pos, restoredState(level, pos));
    }
}
