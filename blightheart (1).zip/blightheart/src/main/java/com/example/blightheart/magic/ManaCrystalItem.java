// Path: src/main/java/com/example/blightheart/magic/ManaCrystalItem.java
package com.example.blightheart.magic;

import com.example.blightheart.network.ModNetwork;
import com.example.blightheart.registry.ModAttachments;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Кристалл маны: ПКМ — навсегда +20 к максимуму маны (до 200). */
public class ManaCrystalItem extends Item {

    public static final int BONUS = 20;
    public static final int CAP = 200;

    public ManaCrystalItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer serverPlayer)) return InteractionResultHolder.success(stack);

        ManaData mana = serverPlayer.getData(ModAttachments.MANA);
        if (!mana.increaseMax(BONUS, CAP)) {
            player.displayClientMessage(Component.translatable("message.blightheart.mana_max_reached", CAP)
                    .withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }
        ModNetwork.syncMana(serverPlayer);
        if (!player.getAbilities().instabuild) stack.shrink(1);
        player.displayClientMessage(Component.translatable("message.blightheart.mana_max_up", mana.getMaxMana())
                .withStyle(ChatFormatting.AQUA), true);
        ((ServerLevel) level).sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1.0D,
                player.getZ(), 40, 0.5D, 0.8D, 0.5D, 0.3D);
        level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.2F);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.blightheart.mana_crystal", BONUS, CAP).withStyle(ChatFormatting.AQUA));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
