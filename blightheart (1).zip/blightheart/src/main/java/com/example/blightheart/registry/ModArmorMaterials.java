// Path: src/main/java/com/example/blightheart/registry/ModArmorMaterials.java
package com.example.blightheart.registry;

import com.example.blightheart.BlightheartMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.List;

/**
 * Материалы брони. В 1.21 материал — запись в реестре: защита по частям, прочность "толщины",
 * звук надевания, чем чинить на наковальне и какие текстуры рисовать на игроке.
 */
public final class ModArmorMaterials {

    public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS =
            DeferredRegister.create(Registries.ARMOR_MATERIAL, BlightheartMod.MODID);

    /** Хитин: чуть лучше железа (железо = 2/5/6/2), немного "толщины". */
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> CHITIN = ARMOR_MATERIALS.register("chitin",
            () -> new ArmorMaterial(defense(2, 6, 7, 3, 6), 12, SoundEvents.ARMOR_EQUIP_TURTLE,
                    () -> Ingredient.of(ModItems.CHITIN_PLATE.get()),
                    List.of(new ArmorMaterial.Layer(BlightheartMod.id("chitin"))), 1.0F, 0.0F));

    /** Чешуя Матки: на уровне незерита (3/6/8/3), высокая "толщина" и сопротивление отбрасыванию. */
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> MATRIARCH = ARMOR_MATERIALS.register("matriarch",
            () -> new ArmorMaterial(defense(3, 6, 8, 3, 11), 18, SoundEvents.ARMOR_EQUIP_NETHERITE,
                    () -> Ingredient.of(ModItems.MATRIARCH_SCALE.get()),
                    List.of(new ArmorMaterial.Layer(BlightheartMod.id("matriarch"))), 3.5F, 0.15F));

    /** Защита: ботинки, поножи, нагрудник, шлем и броня для волка (BODY — нужен для полноты таблицы). */
    private static EnumMap<ArmorItem.Type, Integer> defense(int boots, int legs, int chest, int helmet, int body) {
        EnumMap<ArmorItem.Type, Integer> map = new EnumMap<>(ArmorItem.Type.class);
        map.put(ArmorItem.Type.BOOTS, boots);
        map.put(ArmorItem.Type.LEGGINGS, legs);
        map.put(ArmorItem.Type.CHESTPLATE, chest);
        map.put(ArmorItem.Type.HELMET, helmet);
        map.put(ArmorItem.Type.BODY, body);
        return map;
    }

    private ModArmorMaterials() {}
}
