// Path: src/main/java/com/example/blightheart/client/SpawnlingRenderer.java
package com.example.blightheart.client;

import com.example.blightheart.BlightheartMod;
import com.example.blightheart.client.model.SpawnlingModel;
import com.example.blightheart.entity.SpawnlingEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Рендер на собственной модели + светящийся слой (глаза и т.п.). */
public class SpawnlingRenderer extends MobRenderer<SpawnlingEntity, SpawnlingModel<SpawnlingEntity>> {

    private static final ResourceLocation TEXTURE = BlightheartMod.id("textures/entity/spawnling.png");
    private static final ResourceLocation GLOW = BlightheartMod.id("textures/entity/spawnling_glow.png");

    public SpawnlingRenderer(EntityRendererProvider.Context context) {
        super(context, new SpawnlingModel<>(context.bakeLayer(SpawnlingModel.LAYER)), 0.6F);
        this.addLayer(new GlowLayer<>(this, GLOW));
    }

    @Override
    public ResourceLocation getTextureLocation(SpawnlingEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(SpawnlingEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.15F, 1.15F, 1.15F);
    }
    /** Мёртвое Порождение переворачивается на спину, как паук. */
    @Override
    protected float getFlipDegrees(SpawnlingEntity entity) {
        return 180.0F;
    }
}
