// Path: src/main/java/com/example/mysticor/network/ManaSyncPayload.java
package com.example.mysticor.network;

import com.example.mysticor.MysticorMod;
import com.example.mysticor.registry.ModAttachments;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Пакет "сервер → клиент" с текущей маной игрока. */
public record ManaSyncPayload(int currentMana, int maxMana) implements CustomPacketPayload {

    public static final Type<ManaSyncPayload> TYPE = new Type<>(MysticorMod.id("mana_sync"));

    /** Как записать/прочитать пакет: два числа в компактном формате VarInt. */
    public static final StreamCodec<ByteBuf, ManaSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ManaSyncPayload::currentMana,
            ByteBufCodecs.VAR_INT, ManaSyncPayload::maxMana,
            ManaSyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    /**
     * Обработка на клиенте (выполняется в главном потоке).
     * Записываем ману в Attachment клиентского игрока — так HUD и любой клиентский код
     * читают её тем же вызовом player.getData(ModAttachments.MANA), что и сервер.
     * Здесь нет клиентских импортов, поэтому класс безопасен для выделенного сервера.
     */
    public static void handleOnClient(ManaSyncPayload payload, IPayloadContext context) {
        context.player().getData(ModAttachments.MANA).set(payload.currentMana(), payload.maxMana());
    }
}
