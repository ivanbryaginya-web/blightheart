// Path: src/main/java/com/example/mysticor/mana/ManaData.java
package com.example.mysticor.mana;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.Mth;

/**
 * Мана игрока. Хранится в Attachment Type, прикреплённом к игроку.
 * Объект изменяемый: player.getData(...) возвращает этот же экземпляр,
 * поэтому изменения сразу попадают в данные игрока и сохраняются вместе с ним.
 */
public class ManaData {

    public static final int DEFAULT_MAX_MANA = 100;

    /**
     * Кодек для сохранения на диск (и для copyOnDeath — NeoForge копирует вложение через сериализацию).
     * В NBT это будет выглядеть как {current_mana: 80, max_mana: 100}.
     */
    public static final Codec<ManaData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.fieldOf("current_mana").forGetter(ManaData::getCurrentMana),
            Codec.INT.fieldOf("max_mana").forGetter(ManaData::getMaxMana)
    ).apply(instance, ManaData::new));

    private int currentMana;
    private int maxMana;

    /** Значение по умолчанию для нового игрока: полная мана. */
    public ManaData() {
        this(DEFAULT_MAX_MANA, DEFAULT_MAX_MANA);
    }

    public ManaData(int currentMana, int maxMana) {
        this.maxMana = Math.max(1, maxMana);
        this.currentMana = Mth.clamp(currentMana, 0, this.maxMana);
    }

    public int getCurrentMana() { return currentMana; }
    public int getMaxMana() { return maxMana; }

    /** Хватает ли маны на действие стоимостью cost. */
    public boolean hasEnough(int cost) {
        return currentMana >= cost;
    }

    /**
     * Потратить ману. Сначала проверяем, хватает ли её, и только потом списываем,
     * чтобы мана никогда не уходила в минус.
     * @return true, если мана списана; false, если не хватило (значение не меняется).
     */
    public boolean consume(int cost) {
        if (!hasEnough(cost)) return false;
        currentMana -= cost;
        return true;
    }

    /**
     * Восстановить ману, не превышая максимум.
     * @return true, если значение действительно изменилось (нужно ли слать пакет клиенту).
     */
    public boolean regenerate(int amount) {
        int before = currentMana;
        currentMana = Math.min(maxMana, currentMana + amount);
        return currentMana != before;
    }

    /** Обновить значения (используется на клиенте при получении пакета синхронизации). */
    public void set(int currentMana, int maxMana) {
        this.maxMana = Math.max(1, maxMana);
        this.currentMana = Mth.clamp(currentMana, 0, this.maxMana);
    }
}
