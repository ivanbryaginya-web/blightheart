// Path: src/main/java/com/example/mysticor/registry/ModCreativeTabs.java
package com.example.mysticor.registry;

import com.example.mysticor.MysticorMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Собственная вкладка творческого режима. */
public final class ModCreativeTabs {

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MysticorMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MYSTICOR_TAB = CREATIVE_TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.mysticor"))
                    .withTabsBefore(CreativeModeTabs.COMBAT)
                    .icon(() -> ModItems.ARCHMAGE_WAND.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.BASE_WAND.get());
                        output.accept(ModItems.ARCHMAGE_WAND.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
