// Path: src/main/java/com/example/mysticor/spell/SpellCaster.java
package com.example.mysticor.spell;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.phys.Vec3;

/**
 * Эффекты заклинаний. Вызывается только на сервере.
 * Логика отделена от предмета, чтобы её можно было переиспользовать (свитки, посохи, мобы-маги).
 */
public final class SpellCaster {

    /**
     * Сотворить заклинание.
     * @param power множитель силы (у Посоха Архимага он больше 1)
     * @return true, если заклинание сработало (только тогда списывается мана)
     */
    public static boolean cast(SpellType spell, ServerLevel level, ServerPlayer player, float power) {
        return switch (spell) {
            case FIREBALL -> castFireball(level, player, power);
            case HEAL -> castHeal(level, player, power);
            case LEVITATION -> castLevitation(level, player, power);
        };
    }

    /** Огненный шар: малый огненный снаряд (как у всполоха), поджигает мобов и блоки. */
    private static boolean castFireball(ServerLevel level, ServerPlayer player, float power) {
        Vec3 look = player.getLookAngle();
        SmallFireball fireball = new SmallFireball(level, player, look);
        // Появляется перед глазами игрока, чтобы не задеть его самого
        fireball.setPos(player.getX() + look.x, player.getEyeY() - 0.1D + look.y, player.getZ() + look.z);
        fireball.setDeltaMovement(look.scale(1.2D * power));
        level.addFreshEntity(fireball);

        level.playSound(null, player.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0F, 1.0F);
        return true;
    }

    /** Исцеление: восстанавливает 3 сердца (× сила палочки). Не срабатывает при полном здоровье. */
    private static boolean castHeal(ServerLevel level, ServerPlayer player, float power) {
        if (player.getHealth() >= player.getMaxHealth()) {
            player.displayClientMessage(Component.translatable("message.mysticor.already_healthy")
                    .withStyle(ChatFormatting.GRAY), true);
            return false; // мана не тратится впустую
        }
        player.heal(6.0F * power);

        level.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.0D, player.getZ(),
                6, 0.4D, 0.5D, 0.4D, 0.0D);
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.2F);
        return true;
    }

    /** Левитация: подбрасывает игрока вверх и даёт плавное падение, чтобы не разбиться. */
    private static boolean castLevitation(ServerLevel level, ServerPlayer player, float power) {
        player.setDeltaMovement(player.getDeltaMovement().add(0.0D, 1.0D * power, 0.0D));
        player.hurtMarked = true; // заставляет сервер отправить новую скорость клиенту
        player.resetFallDistance();
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100));

        level.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY(), player.getZ(),
                15, 0.4D, 0.1D, 0.4D, 0.05D);
        level.playSound(null, player.blockPosition(), SoundEvents.PHANTOM_FLAP, SoundSource.PLAYERS, 1.0F, 1.4F);
        return true;
    }

    private SpellCaster() {}
}
