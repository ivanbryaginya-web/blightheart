// Path: src/main/java/com/example/mysticor/registry/ModAttachments.java
package com.example.mysticor.registry;

import com.example.mysticor.MysticorMod;
import com.example.mysticor.mana.ManaData;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/** Типы вложений данных (Attachment Types) — замена Capabilities в NeoForge 1.20.5+. */
public final class ModAttachments {

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, MysticorMod.MODID);

    /**
     * Мана игрока.
     * serialize(...) — сохранять вложение вместе с данными сущности;
     * copyOnDeath() — переносить ману на "нового" игрока после смерти
     * (при возвращении из Энда сериализуемые вложения копируются автоматически).
     */
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<ManaData>> MANA =
            ATTACHMENT_TYPES.register("mana", () -> AttachmentType.builder(() -> new ManaData())
                    .serialize(ManaData.CODEC)
                    .copyOnDeath()
                    .build());

    private ModAttachments() {}
}
