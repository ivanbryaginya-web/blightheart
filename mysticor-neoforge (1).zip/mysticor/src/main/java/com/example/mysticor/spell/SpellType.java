// Path: src/main/java/com/example/mysticor/spell/SpellType.java
package com.example.mysticor.spell;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.ByIdMap;
import net.minecraft.util.StringRepresentable;

import java.util.function.IntFunction;

/** Все заклинания мода и их стоимость в мане. */
public enum SpellType implements StringRepresentable {

    FIREBALL("fireball", 15, ChatFormatting.GOLD),
    HEAL("heal", 25, ChatFormatting.GREEN),
    LEVITATION("levitation", 10, ChatFormatting.AQUA);

    /** Кодек для сохранения (в данных предмета хранится строка "fireball", "heal" и т.д.). */
    public static final Codec<SpellType> CODEC = StringRepresentable.fromEnum(SpellType::values);

    private static final IntFunction<SpellType> BY_ID =
            ByIdMap.continuous(SpellType::ordinal, values(), ByIdMap.OutOfBoundsStrategy.ZERO);

    /** Кодек для сети: передаём компактный номер вместо строки. */
    public static final StreamCodec<ByteBuf, SpellType> STREAM_CODEC =
            ByteBufCodecs.idMapper(BY_ID, SpellType::ordinal);

    private final String name;
    private final int manaCost;
    private final ChatFormatting color;

    SpellType(String name, int manaCost, ChatFormatting color) {
        this.name = name;
        this.manaCost = manaCost;
        this.color = color;
    }

    /** Базовая стоимость заклинания в мане (палочка может её изменять). */
    public int getManaCost() { return manaCost; }

    /** Локализованное цветное название, например "Огненный шар". */
    public Component getDisplayName() {
        return Component.translatable("spell.mysticor." + name).withStyle(color);
    }

    /** Следующее заклинание по кругу: FIREBALL → HEAL → LEVITATION → FIREBALL. */
    public SpellType next() {
        SpellType[] all = values();
        return all[(ordinal() + 1) % all.length];
    }

    @Override
    public String getSerializedName() { return name; }
}
