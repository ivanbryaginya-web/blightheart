// Path: src/main/java/com/example/mysticor/MysticorMod.java
package com.example.mysticor;

import com.example.mysticor.network.ModNetwork;
import com.example.mysticor.registry.ModAttachments;
import com.example.mysticor.registry.ModCreativeTabs;
import com.example.mysticor.registry.ModDataComponents;
import com.example.mysticor.registry.ModItems;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;

/**
 * Главный класс мода Mysticor.
 * NeoForge сам передаёт в конструктор шину событий мода (IEventBus) и контейнер мода.
 */
@Mod(MysticorMod.MODID)
public class MysticorMod {

    public static final String MODID = "mysticor";
    public static final Logger LOGGER = LogUtils.getLogger();

    public MysticorMod(IEventBus modEventBus, ModContainer modContainer) {
        // Порядок регистрации DeferredRegister не важен: реестры заполняются в нужной очерёдности самим NeoForge
        ModDataComponents.DATA_COMPONENTS.register(modEventBus);
        ModAttachments.ATTACHMENT_TYPES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModCreativeTabs.CREATIVE_TABS.register(modEventBus);

        // Регистрация сетевых пакетов (событие RegisterPayloadHandlersEvent приходит на шину мода)
        modEventBus.addListener(ModNetwork::registerPayloads);
    }

    /** Короткий способ получить ResourceLocation вида mysticor:путь. */
    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
