// Path: src/main/java/com/example/mysticor/registry/ModItems.java
package com.example.mysticor.registry;

import com.example.mysticor.MysticorMod;
import com.example.mysticor.item.SpellWandItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Регистрация предметов. DeferredItem — это DeferredHolder, специализированный для предметов. */
public final class ModItems {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MysticorMod.MODID);

    /** Обычная палочка: 250 использований, стандартная сила и стоимость. */
    public static final DeferredItem<SpellWandItem> BASE_WAND = ITEMS.register("base_wand",
            () -> new SpellWandItem(new Item.Properties().durability(250).rarity(Rarity.UNCOMMON),
                    1.0F, 1.0F, false));

    /** Посох Архимага: 1000 использований, сила ×1.5, заклинания на 25% дешевле, светится. */
    public static final DeferredItem<SpellWandItem> ARCHMAGE_WAND = ITEMS.register("archmage_wand",
            () -> new SpellWandItem(new Item.Properties().durability(1000).rarity(Rarity.EPIC).fireResistant(),
                    1.5F, 0.75F, true));

    private ModItems() {}
}
