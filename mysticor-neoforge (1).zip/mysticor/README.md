# Mysticor (NeoForge 1.21.1)

Сборка (нужна JDK 21):  gradlew build   (Windows: gradlew.bat build)
Готовый мод: build/libs/mysticor-1.0.0.jar → папка mods профиля NeoForge 1.21.1.
Запуск из среды разработки: gradlew runClient

Управление: ПКМ — сотворить заклинание, Shift + ПКМ — сменить заклинание.
